# Moiz Job Manager

A private Chrome extension that stores job applications and their documents locally.

## Install

1. Extract the ZIP file.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted `moiz-job-manager` folder containing `manifest.json`.
6. Pin **Moiz Job Manager** from Chrome's extension menu.

Open `START_HERE.html` for the visual guide.

## Main features

- Paste a job link in the extension and continue in the full dashboard. Click **Fill automatically** there to capture the details without losing the link when Chrome asks permission.
- Captures job title, company, location, link, visible requirements and job description.
- Stores the exact CV, optional cover letter and other documents.
- Tracks Applied, Interview, Offer, Rejected and Withdrawn statuses.
- Searches and filters all applications in one dashboard.
- Exports a real Excel `.xlsx` workbook.
- Creates a ZIP backup containing application data, Excel export and documents.
- Imports its backup ZIP without deleting unrelated existing records.

## Privacy and safety

No information is sent to a server by this extension. The database and documents stay in the current Chrome profile. A job website can sometimes block automatic capture; all captured fields remain editable. Chrome asks for permission the first time the extension reads a particular job website. Pasted links continue in the full dashboard so the page stays open during this permission step. The extension only opens the pasted link briefly in a background tab and closes it after capture.

Back up your data before uninstalling the extension or clearing browser storage. Backup ZIP files contain CVs and personal information and should be kept private.

The extension is created by **Moiz Zaheer Malik**. Open **Privacy & help** inside the extension for a plain-language explanation of its data use and permissions.

## Limits

- This extension tracks applications; it does not submit them.
- It captures information visible on the current page. Sign-in walls, iframes and some protected sites may require manual copy and paste.
- Data does not automatically sync between computers or Chrome profiles.
