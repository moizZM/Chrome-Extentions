export const STATUS_OPTIONS = [
  { value: "applied", label: "Applied" },
  { value: "interview", label: "Interview" },
  { value: "offer", label: "Offer" },
  { value: "rejected", label: "Rejected" },
  { value: "withdrawn", label: "Withdrawn" }
];

export const STATUS_LABELS = Object.fromEntries(
  STATUS_OPTIONS.map((status) => [status.value, status.label])
);

export const MAX_PDF_BYTES = 25 * 1024 * 1024;
export const MAX_OTHER_FILE_BYTES = 50 * 1024 * 1024;

export function todayLocal() {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60_000;
  return new Date(now.getTime() - offset).toISOString().slice(0, 10);
}

export function formatDate(value) {
  if (!value) return "Not set";
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(date);
}

export function formatBytes(bytes = 0) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** index;
  return `${value.toFixed(index === 0 || value >= 10 ? 0 : 1)} ${units[index]}`;
}

export function safeFileName(value, fallback = "file") {
  const cleaned = String(value || "")
    .normalize("NFKD")
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return (cleaned || fallback).slice(0, 120);
}

export function createId(prefix = "item") {
  const id = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}-${id}`;
}

export function normalizeUrl(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  try {
    const url = new URL(text);
    if (!["http:", "https:"].includes(url.protocol)) return "";
    return url.href;
  } catch {
    return "";
  }
}

export function statusLabel(value) {
  return STATUS_LABELS[value] || "Applied";
}

export function validatePdfFile(file, label = "PDF") {
  if (!file) return;
  const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name || "");
  if (!isPdf) throw new Error(`${label} must be a PDF file.`);
  if (file.size > MAX_PDF_BYTES) throw new Error(`${label} must be smaller than 25 MB.`);
}

export function validateOtherFile(file) {
  if (file?.size > MAX_OTHER_FILE_BYTES) {
    throw new Error(`${file.name || "Document"} must be smaller than 50 MB.`);
  }
}

export function findLikelyDuplicate(applications, candidate) {
  const candidateUrl = normalizeUrl(candidate?.jobUrl);
  if (candidateUrl) {
    const exactUrl = applications.find((app) => normalizeUrl(app.jobUrl) === candidateUrl);
    if (exactUrl) return exactUrl;
  }

  const compact = (value) => String(value || "").trim().toLocaleLowerCase();
  const company = compact(candidate?.company);
  const title = compact(candidate?.jobTitle);
  if (!company || !title) return null;
  return applications.find((app) => (
    compact(app.company) === company
    && compact(app.jobTitle) === title
    && String(app.applicationDate || "") === String(candidate?.applicationDate || "")
  )) || null;
}
