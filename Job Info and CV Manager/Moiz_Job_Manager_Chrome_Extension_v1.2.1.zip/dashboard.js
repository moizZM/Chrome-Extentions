import {
  addFiles,
  createApplication,
  deleteApplication,
  deleteFile,
  deleteFilesByKind,
  getAllFiles,
  listApplications,
  mergeBackup,
  updateApplication
} from "./db.js";
import {
  createId,
  findLikelyDuplicate,
  formatBytes,
  formatDate,
  normalizeUrl,
  STATUS_OPTIONS,
  statusLabel,
  todayLocal,
  validateOtherFile,
  validatePdfFile
} from "./common.js";
import {
  buildApplicationsXlsx,
  buildBackupZip,
  downloadBlob,
  readBackupZip
} from "./export-utils.js";
import { captureJobPage } from "./page-capture.js";
import { readJobFromLink } from "./job-link-reader.js";

const state = {
  applications: [],
  files: []
};

const elements = {
  body: document.querySelector("#applications-body"),
  emptyState: document.querySelector("#empty-state"),
  emptyMessage: document.querySelector("#empty-message"),
  resultsCount: document.querySelector("#results-count"),
  storageNote: document.querySelector("#storage-note"),
  search: document.querySelector("#search"),
  statusFilter: document.querySelector("#status-filter"),
  sortOrder: document.querySelector("#sort-order"),
  dialog: document.querySelector("#application-dialog"),
  editForm: document.querySelector("#edit-form"),
  existingFiles: document.querySelector("#existing-files"),
  toast: document.querySelector("#toast")
};

const editFields = {
  id: document.querySelector("#edit-id"),
  company: document.querySelector("#edit-company"),
  jobTitle: document.querySelector("#edit-title"),
  location: document.querySelector("#edit-location"),
  applicationDate: document.querySelector("#edit-date"),
  status: document.querySelector("#edit-status"),
  jobUrl: document.querySelector("#edit-url"),
  referenceNumber: document.querySelector("#edit-reference"),
  requirements: document.querySelector("#edit-requirements"),
  jobDescription: document.querySelector("#edit-description"),
  notes: document.querySelector("#edit-notes"),
  cv: document.querySelector("#edit-cv"),
  coverLetter: document.querySelector("#edit-letter"),
  otherFiles: document.querySelector("#edit-other-files")
};

let toastTimer;

function showToast(message, isError = false) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.className = `toast show${isError ? " error" : ""}`;
  toastTimer = setTimeout(() => {
    elements.toast.className = "toast";
  }, 3_200);
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function filesFor(appId) {
  return state.files.filter((file) => file.appId === appId);
}

async function reloadData() {
  [state.applications, state.files] = await Promise.all([listApplications(), getAllFiles()]);
}

function renderCounts() {
  const counts = state.applications.reduce((result, app) => {
    result.total += 1;
    if (Object.hasOwn(result, app.status)) result[app.status] += 1;
    return result;
  }, { total: 0, applied: 0, interview: 0, offer: 0, rejected: 0, withdrawn: 0 });

  for (const key of ["total", "applied", "interview", "offer", "rejected"]) {
    document.querySelector(`#count-${key}`).textContent = counts[key] || 0;
  }
  document.querySelectorAll("[data-summary-status]").forEach((card) => {
    card.classList.toggle("active", card.dataset.summaryStatus === elements.statusFilter.value);
  });

  const storedBytes = state.files.reduce((sum, file) => sum + Number(file.size || file.blob?.size || 0), 0);
  elements.storageNote.textContent = `${state.files.length} stored document${state.files.length === 1 ? "" : "s"} · ${formatBytes(storedBytes)} · Local Chrome storage`;
}

function filteredApplications() {
  const query = elements.search.value.trim().toLocaleLowerCase();
  const status = elements.statusFilter.value;
  const matches = state.applications.filter((app) => {
    if (status !== "all" && app.status !== status) return false;
    if (!query) return true;
    return [
      app.company,
      app.jobTitle,
      app.location,
      app.referenceNumber,
      app.requirements,
      app.notes
    ].some((value) => String(value || "").toLocaleLowerCase().includes(query));
  });

  const sort = elements.sortOrder.value;
  return matches.sort((left, right) => {
    if (sort === "date-asc") return String(left.applicationDate || "").localeCompare(String(right.applicationDate || ""));
    if (sort === "company-asc") return String(left.company || "").localeCompare(String(right.company || ""), undefined, { sensitivity: "base" });
    return String(right.applicationDate || "").localeCompare(String(left.applicationDate || ""));
  });
}

function renderFileBadges(appId) {
  const container = element("div", "file-badges");
  const appFiles = filesFor(appId);
  const cvCount = appFiles.filter((file) => file.kind === "cv").length;
  const letterCount = appFiles.filter((file) => file.kind === "cover-letter").length;
  const otherCount = appFiles.length - cvCount - letterCount;
  if (cvCount) container.append(element("span", "file-badge cv", "CV"));
  if (letterCount) container.append(element("span", "file-badge", "Letter"));
  if (otherCount) container.append(element("span", "file-badge", `+${otherCount}`));
  if (!appFiles.length) container.append(element("span", "file-badge", "No files"));
  return container;
}

function makeStatusSelect(app) {
  const select = element("select", `row-status ${app.status || "applied"}`);
  select.setAttribute("aria-label", `Status for ${app.company} ${app.jobTitle}`);
  for (const option of STATUS_OPTIONS) {
    const node = document.createElement("option");
    node.value = option.value;
    node.textContent = option.label;
    node.selected = app.status === option.value;
    select.append(node);
  }
  select.addEventListener("change", async () => {
    const previous = app.status;
    select.disabled = true;
    try {
      app.status = select.value;
      app.updatedAt = new Date().toISOString();
      await updateApplication(app);
      select.className = `row-status ${app.status}`;
      await reloadData();
      renderAll();
      showToast(`Status changed to ${statusLabel(app.status)}.`);
    } catch (error) {
      console.error(error);
      app.status = previous;
      select.value = previous;
      showToast("The status could not be changed.", true);
    } finally {
      select.disabled = false;
    }
  });
  return select;
}

function renderTable() {
  const applications = filteredApplications();
  elements.body.replaceChildren();

  for (const app of applications) {
    const row = document.createElement("tr");
    const jobCell = element("td");
    const job = element("div", "job-cell");
    job.append(element("strong", "", app.company || "Unknown company"));
    const safeJobUrl = normalizeUrl(app.jobUrl);
    if (safeJobUrl) {
      const link = element("a", "job-link", app.jobTitle || "Untitled job");
      link.href = safeJobUrl;
      link.target = "_blank";
      link.rel = "noreferrer";
      job.append(link);
    } else {
      job.append(element("span", "", app.jobTitle || "Untitled job"));
    }
    if (app.referenceNumber) job.append(element("span", "", `Ref: ${app.referenceNumber}`));
    jobCell.append(job);

    const dateCell = element("td", "date-cell", formatDate(app.applicationDate));
    const locationCell = element("td", "location-cell", app.location || "Not set");
    locationCell.title = app.location || "";
    const filesCell = element("td");
    filesCell.append(renderFileBadges(app.id));
    const statusCell = element("td");
    statusCell.append(makeStatusSelect(app));
    const actionCell = element("td");
    const view = element("button", "view-button", "View / edit");
    view.type = "button";
    view.addEventListener("click", () => openDialog(app));
    actionCell.append(view);

    row.append(jobCell, dateCell, locationCell, filesCell, statusCell, actionCell);
    elements.body.append(row);
  }

  const isEmpty = applications.length === 0;
  elements.emptyState.hidden = !isEmpty;
  elements.emptyMessage.textContent = state.applications.length
    ? "No applications match the current search or status filter."
    : "Add an application manually or paste a job link to fill the details automatically.";
  elements.resultsCount.textContent = `${applications.length} application${applications.length === 1 ? "" : "s"}`;
}

function renderAll() {
  renderCounts();
  renderTable();
}

function openFile(file) {
  const url = URL.createObjectURL(file.blob);
  const link = document.createElement("a");
  link.href = url;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

function renderExistingFiles(appId) {
  elements.existingFiles.replaceChildren();
  const files = appId ? filesFor(appId) : [];
  document.querySelector("#cv-upload-label").textContent = files.some((file) => file.kind === "cv") ? "Replace CV" : "Add CV";
  document.querySelector("#letter-upload-label").textContent = files.some((file) => file.kind === "cover-letter") ? "Replace cover letter" : "Add cover letter";

  if (!files.length) {
    elements.existingFiles.append(element("div", "no-files", "No documents stored yet."));
    return;
  }

  const typeLabels = { cv: "CV", "cover-letter": "LETTER", other: "FILE" };
  for (const file of files) {
    const row = element("div", "stored-file");
    row.append(element("span", "file-type", typeLabels[file.kind] || "FILE"));
    const info = element("div", "file-info");
    info.append(element("strong", "", file.name), element("small", "", `${formatBytes(file.size || file.blob?.size)} · ${file.mimeType || "document"}`));
    const openButton = element("button", "file-action", "Open");
    openButton.type = "button";
    openButton.addEventListener("click", () => openFile(file));
    const deleteButton = element("button", "file-action delete", "Remove");
    deleteButton.type = "button";
    deleteButton.addEventListener("click", async () => {
      if (!confirm(`Remove “${file.name}” from this application?`)) return;
      try {
        await deleteFile(file.id);
        await reloadData();
        renderAll();
        renderExistingFiles(appId);
        showToast("Document removed.");
      } catch (error) {
        console.error(error);
        showToast("The document could not be removed.", true);
      }
    });
    row.append(info, openButton, deleteButton);
    elements.existingFiles.append(row);
  }
}

function resetFileInputs() {
  editFields.cv.value = "";
  editFields.coverLetter.value = "";
  editFields.otherFiles.value = "";
}

function openDialog(application = null) {
  elements.editForm.reset();
  resetFileInputs();
  const editing = Boolean(application);
  document.querySelector("#dialog-label").textContent = editing ? "APPLICATION DETAILS" : "NEW APPLICATION";
  document.querySelector("#dialog-title").textContent = editing ? `${application.company} · ${application.jobTitle}` : "Add application";
  document.querySelector("#delete-application").hidden = !editing;
  document.querySelector("#save-changes").textContent = editing ? "Save changes" : "Add application";
  const linkStatus = document.querySelector("#link-read-status");
  linkStatus.textContent = "";
  linkStatus.classList.remove("error");

  editFields.id.value = application?.id || "";
  editFields.company.value = application?.company || "";
  editFields.jobTitle.value = application?.jobTitle || "";
  editFields.location.value = application?.location || "";
  editFields.applicationDate.value = application?.applicationDate || todayLocal();
  editFields.status.value = application?.status || "applied";
  editFields.jobUrl.value = application?.jobUrl || "";
  editFields.referenceNumber.value = application?.referenceNumber || "";
  editFields.requirements.value = application?.requirements || "";
  editFields.jobDescription.value = application?.jobDescription || "";
  editFields.notes.value = application?.notes || "";
  renderExistingFiles(application?.id || "");
  elements.dialog.showModal();
}

async function fillFromJobLink() {
  const button = document.querySelector("#fill-from-link");
  const status = document.querySelector("#link-read-status");
  status.classList.remove("error");
  status.textContent = "Reading the job page…";
  button.disabled = true;
  button.textContent = "Reading…";

  try {
    const data = await readJobFromLink(editFields.jobUrl.value, captureJobPage);
    if (data.company) editFields.company.value = data.company;
    if (data.jobTitle) editFields.jobTitle.value = data.jobTitle;
    if (data.location) editFields.location.value = data.location;
    if (data.jobUrl) editFields.jobUrl.value = data.jobUrl;
    if (data.referenceNumber) editFields.referenceNumber.value = data.referenceNumber;
    if (data.requirements) editFields.requirements.value = data.requirements;
    if (data.jobDescription) editFields.jobDescription.value = data.jobDescription;

    const missing = [!data.company && "company", !data.jobTitle && "job title"].filter(Boolean);
    status.textContent = missing.length
      ? `Filled what was available. Please enter the ${missing.join(" and ")} yourself.`
      : "Done. Check the information, upload your documents, then save.";
    if (missing.length) status.classList.add("error");
  } catch (error) {
    console.error(error);
    status.textContent = error.message || "This link could not be read automatically.";
    status.classList.add("error");
  } finally {
    button.disabled = false;
    button.textContent = "Fill automatically";
  }
}

function closeDialog() {
  elements.dialog.close();
}

async function saveDialog(event) {
  event.preventDefault();
  if (!elements.editForm.reportValidity()) return;
  const saveButton = document.querySelector("#save-changes");
  saveButton.disabled = true;
  saveButton.textContent = "Saving…";

  try {
    const id = editFields.id.value || createId("app");
    const existing = state.applications.find((app) => app.id === id);
    const now = new Date().toISOString();
    const application = {
      ...(existing || {}),
      id,
      company: editFields.company.value.trim(),
      jobTitle: editFields.jobTitle.value.trim(),
      location: editFields.location.value.trim(),
      applicationDate: editFields.applicationDate.value || todayLocal(),
      status: editFields.status.value,
      jobUrl: normalizeUrl(editFields.jobUrl.value),
      referenceNumber: editFields.referenceNumber.value.trim(),
      requirements: editFields.requirements.value.trim(),
      jobDescription: editFields.jobDescription.value.trim(),
      notes: editFields.notes.value.trim(),
      createdAt: existing?.createdAt || now,
      updatedAt: now
    };

    const cv = editFields.cv.files[0];
    const coverLetter = editFields.coverLetter.files[0];
    const otherFiles = [...editFields.otherFiles.files];
    validatePdfFile(cv, "CV");
    validatePdfFile(coverLetter, "Cover letter");
    otherFiles.forEach(validateOtherFile);

    if (!existing) {
      const duplicate = findLikelyDuplicate(state.applications, application);
      if (duplicate && !confirm(`This job already appears to be saved for ${duplicate.company}. Add another copy anyway?`)) {
        showToast("Nothing was added. The existing application is unchanged.");
        return;
      }
    }

    if (existing) {
      await updateApplication(application);
      if (cv) {
        await deleteFilesByKind(id, "cv");
        await addFiles(id, [{ kind: "cv", file: cv }]);
      }
      if (coverLetter) {
        await deleteFilesByKind(id, "cover-letter");
        await addFiles(id, [{ kind: "cover-letter", file: coverLetter }]);
      }
      if (otherFiles.length) {
        await addFiles(id, otherFiles.map((file) => ({ kind: "other", file })));
      }
    } else {
      const attachments = [];
      if (cv) attachments.push({ kind: "cv", file: cv });
      if (coverLetter) attachments.push({ kind: "cover-letter", file: coverLetter });
      for (const file of otherFiles) attachments.push({ kind: "other", file });
      await createApplication(application, attachments);
    }

    closeDialog();
    await reloadData();
    renderAll();
    showToast(existing ? "Application updated." : "Application added.");
  } catch (error) {
    console.error(error);
    showToast(error.message || "The application could not be saved.", true);
  } finally {
    saveButton.disabled = false;
    saveButton.textContent = editFields.id.value ? "Save changes" : "Add application";
  }
}

async function removeCurrentApplication() {
  const id = editFields.id.value;
  const app = state.applications.find((item) => item.id === id);
  if (!app) return;
  if (!confirm(`Delete the application for “${app.company} · ${app.jobTitle}” and all stored documents?`)) return;
  try {
    await deleteApplication(id);
    closeDialog();
    await reloadData();
    renderAll();
    showToast("Application deleted.");
  } catch (error) {
    console.error(error);
    showToast("The application could not be deleted.", true);
  }
}

async function exportExcel() {
  if (!state.applications.length) {
    showToast("There are no applications to export.", true);
    return;
  }
  try {
    const workbook = await buildApplicationsXlsx(state.applications, state.files);
    downloadBlob(workbook, `Moiz_Job_Applications_${todayLocal()}.xlsx`);
    showToast("Excel file created.");
  } catch (error) {
    console.error(error);
    showToast("The Excel file could not be created.", true);
  }
}

async function exportBackup() {
  if (!state.applications.length) {
    showToast("There are no applications to back up.", true);
    return;
  }
  try {
    const button = document.querySelector("#backup-data");
    button.disabled = true;
    button.textContent = "Preparing…";
    const backup = await buildBackupZip(state.applications, state.files);
    downloadBlob(backup, `Moiz_Job_Manager_Backup_${todayLocal()}.zip`);
    showToast("Backup ZIP created. Keep it private and safe.");
    button.disabled = false;
    button.textContent = "Backup ZIP";
  } catch (error) {
    console.error(error);
    const button = document.querySelector("#backup-data");
    button.disabled = false;
    button.textContent = "Backup ZIP";
    showToast("The backup could not be created.", true);
  }
}

async function importBackup(file) {
  if (!file) return;
  try {
    const backup = await readBackupZip(file);
    const message = `Import ${backup.applications.length} applications and ${backup.files.length} documents? Existing records will stay. Matching records will be updated.`;
    if (!confirm(message)) return;
    await mergeBackup(backup.applications, backup.files);
    await reloadData();
    renderAll();
    showToast(`Imported ${backup.applications.length} applications.`);
  } catch (error) {
    console.error(error);
    showToast(error.message || "The backup could not be imported.", true);
  } finally {
    document.querySelector("#restore-file").value = "";
  }
}

document.querySelector("#add-application").addEventListener("click", () => openDialog());
document.querySelector("#empty-add").addEventListener("click", () => openDialog());
document.querySelector("#about-app").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("about.html") }));
document.querySelector("#footer-about-app").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("about.html") }));
document.querySelector("#close-dialog").addEventListener("click", closeDialog);
document.querySelector("#cancel-dialog").addEventListener("click", closeDialog);
document.querySelector("#delete-application").addEventListener("click", removeCurrentApplication);
document.querySelector("#fill-from-link").addEventListener("click", fillFromJobLink);
editFields.jobUrl.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    fillFromJobLink();
  }
});
elements.editForm.addEventListener("submit", saveDialog);
elements.search.addEventListener("input", renderAll);
elements.statusFilter.addEventListener("change", renderAll);
elements.sortOrder.addEventListener("change", renderAll);
document.querySelector("#export-excel").addEventListener("click", exportExcel);
document.querySelector("#backup-data").addEventListener("click", exportBackup);
document.querySelector("#restore-data").addEventListener("click", () => document.querySelector("#restore-file").click());
document.querySelector("#restore-file").addEventListener("change", (event) => importBackup(event.target.files[0]));

document.querySelectorAll("[data-summary-status]").forEach((card) => {
  card.addEventListener("click", () => {
    elements.statusFilter.value = card.dataset.summaryStatus;
    renderAll();
  });
});

elements.dialog.addEventListener("click", (event) => {
  if (event.target === elements.dialog) closeDialog();
});

try {
  await reloadData();
  renderAll();

  const pageUrl = new URL(window.location.href);
  const newJobUrl = pageUrl.searchParams.get("newJobUrl");
  if (newJobUrl) {
    openDialog();
    editFields.jobUrl.value = newJobUrl;
    const linkStatus = document.querySelector("#link-read-status");
    linkStatus.textContent = "Link ready. Click Fill automatically, then choose Allow. This page will stay open and continue reading.";
    document.querySelector("#fill-from-link").focus();
    window.history.replaceState({}, "", chrome.runtime.getURL("dashboard.html"));
  }
} catch (error) {
  console.error(error);
  showToast("The local application database could not be opened.", true);
}
