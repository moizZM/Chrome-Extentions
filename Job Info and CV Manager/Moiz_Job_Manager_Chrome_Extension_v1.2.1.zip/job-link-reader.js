export function validateJobUrl(value) {
  try {
    const url = new URL(String(value || "").trim());
    if (!["http:", "https:"].includes(url.protocol)) throw new Error();
    return url;
  } catch {
    throw new Error("Please paste a complete job link beginning with http:// or https://.");
  }
}

function waitForTab(tabId, timeoutMs = 30_000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      if (error) reject(error);
      else resolve();
    };
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === "complete") finish();
    };
    const timer = setTimeout(() => finish(new Error("The job page took too long to load.")), timeoutMs);
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab?.status === "complete") finish();
    }).catch(() => {});
  });
}

export async function readJobFromLink(value, captureFunction) {
  const url = validateJobUrl(value);
  const originPermission = `${url.origin}/*`;
  // Request is intentionally the first asynchronous Chrome call so it remains
  // connected to the user's button click. Chrome skips the prompt if allowed.
  const allowed = await chrome.permissions.request({ origins: [originPermission] });
  if (!allowed) throw new Error("Chrome permission was not allowed, so this page cannot be read automatically.");

  let tab;
  try {
    tab = await chrome.tabs.create({ url: url.href, active: false });
    await waitForTab(tab.id);
    await new Promise((resolve) => setTimeout(resolve, 900));
    let [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: captureFunction
    });
    if (!result?.jobTitle || String(result?.jobDescription || "").length < 300) {
      await new Promise((resolve) => setTimeout(resolve, 1_500));
      [{ result }] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: captureFunction
      });
    }
    if (!result) throw new Error("No job information was found on this page.");
    return result;
  } catch (error) {
    if (/Cannot access|permission|host/i.test(String(error?.message || ""))) {
      throw new Error("The job link redirected to a protected website. Open the link normally, then click the extension on that page.");
    }
    throw error;
  } finally {
    if (tab?.id) {
      try { await chrome.tabs.remove(tab.id); } catch { /* The tab may already be closed. */ }
    }
  }
}
