// This function is injected into a job tab. Keep every helper inside it so
// Chrome can safely serialize and run it without access to extension data.
export function captureJobPage() {
  const MAX_DESCRIPTION = 60_000;
  const MAX_REQUIREMENTS = 15_000;

  function cleanText(value, limit = MAX_DESCRIPTION) {
    return String(value || "")
      .replace(/\r/g, "")
      .replace(/[\t\u00a0]+/g, " ")
      .replace(/ +\n/g, "\n")
      .replace(/\n +/g, "\n")
      .replace(/[ ]{2,}/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .slice(0, limit);
  }

  function htmlToText(value) {
    if (!value) return "";
    const template = document.createElement("template");
    template.innerHTML = String(value);
    return cleanText(template.content.textContent || "");
  }

  function textFromSelectors(selectors, limit = 500) {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      const text = cleanText(element?.innerText || element?.textContent || "", limit);
      if (text) return text;
    }
    return "";
  }

  function collectJsonLd() {
    const values = [];
    for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        values.push(JSON.parse(script.textContent || "null"));
      } catch {
        // Ignore malformed structured data and continue with visible text.
      }
    }
    return values;
  }

  function flattenStructured(value, output = []) {
    if (!value) return output;
    if (Array.isArray(value)) {
      for (const child of value) flattenStructured(child, output);
      return output;
    }
    if (typeof value !== "object") return output;
    output.push(value);
    if (value["@graph"]) flattenStructured(value["@graph"], output);
    return output;
  }

  function isJobPosting(item) {
    const type = item?.["@type"];
    return Array.isArray(type) ? type.includes("JobPosting") : type === "JobPosting";
  }

  function locationText(job) {
    if (String(job?.jobLocationType || "").toUpperCase().includes("TELECOMMUTE")) return "Remote";
    const locations = Array.isArray(job?.jobLocation) ? job.jobLocation : [job?.jobLocation];
    const parts = [];
    for (const location of locations) {
      const address = location?.address || location;
      const text = [address?.addressLocality, address?.addressRegion, address?.addressCountry]
        .filter(Boolean)
        .map((part) => (typeof part === "object" ? part.name : part))
        .join(", ");
      if (text && !parts.includes(text)) parts.push(text);
    }
    return parts.join(" / ");
  }

  function structuredText(value) {
    if (!value) return "";
    if (Array.isArray(value)) return cleanText(value.map(structuredText).filter(Boolean).join("\n"));
    if (typeof value === "object") return cleanText(value.name || value.value || JSON.stringify(value));
    return htmlToText(value);
  }

  function extractRequirements(text) {
    const cleaned = cleanText(text);
    if (!cleaned) return "";
    const lines = cleaned.split("\n").map((line) => line.trim()).filter(Boolean);
    const starts = [
      /^(requirements?|qualifications?|your profile|candidate profile|what you bring|what you need|what we are looking for|must have|skills(?: and experience)?|experience)\b/i,
      /^(anforderungen|ihr profil|dein profil|qualifikationen|das bringen sie mit|was sie mitbringen|was du mitbringst|kenntnisse und erfahrungen)\b/i
    ];
    const otherHeading = /^(responsibilities|your tasks|what you will do|about (us|the role)|benefits|what we offer|our offer|apply|aufgaben|ihre aufgaben|deine aufgaben|wir bieten|was wir bieten|über uns|bewerbung)\b/i;
    const startIndex = lines.findIndex((line) => line.length < 130 && starts.some((pattern) => pattern.test(line.replace(/[:：]$/, ""))));
    if (startIndex === -1) return "";

    let endIndex = Math.min(lines.length, startIndex + 45);
    for (let index = startIndex + 2; index < Math.min(lines.length, startIndex + 80); index += 1) {
      const line = lines[index].replace(/[:：]$/, "");
      if (line.length < 100 && otherHeading.test(line)) {
        endIndex = index;
        break;
      }
    }
    return cleanText(lines.slice(startIndex, endIndex).join("\n"), MAX_REQUIREMENTS);
  }

  function findReferenceNumber(text) {
    const match = String(text || "").match(/(?:job\s*(?:id|reference|ref\.?|number|nr\.?|kennziffer)|reference\s*(?:id|number)?|stellen(?:nummer|kennziffer))\s*[:#-]?\s*([A-Z0-9][A-Z0-9._/-]{2,30})/i);
    return match?.[1] || "";
  }

  const structured = flattenStructured(collectJsonLd());
  const job = structured.find(isJobPosting) || {};
  const structuredDescription = structuredText(job.description);
  const visibleDescription = textFromSelectors([
    "#jobDescriptionText",
    '[data-testid="jobsearch-JobComponent-description"]',
    '[data-testid*="job-description"]',
    '[class*="jobDescription"]',
    '[class*="job-description"]',
    '[id*="job-description"]',
    '[class*="description__text"]',
    "main article",
    "main"
  ], MAX_DESCRIPTION);
  const bodyText = cleanText(document.body?.innerText || "");
  const description = structuredDescription || visibleDescription || bodyText;

  const qualifications = [
    structuredText(job.qualifications),
    structuredText(job.skills),
    structuredText(job.experienceRequirements),
    structuredText(job.educationRequirements)
  ].filter(Boolean).join("\n");

  const pageTitle = cleanText(document.title, 300);
  const fallbackTitle = pageTitle.split(/\s(?:\||–|—|-|·)\s/)[0] || pageTitle;
  const companyFromStructured = typeof job.hiringOrganization === "string"
    ? job.hiringOrganization
    : job.hiringOrganization?.name;

  return {
    company: cleanText(companyFromStructured || textFromSelectors([
      '[data-testid="inlineHeader-companyName"]',
      '[data-testid*="company-name"]',
      '[class*="companyName"]',
      '[class*="company-name"]',
      '[itemprop="hiringOrganization"]',
      'header [class*="company"]'
    ]), 300),
    jobTitle: cleanText(job.title || textFromSelectors([
      '[data-testid="job-title"]',
      '[data-testid*="job-title"]',
      '[class*="jobTitle"]',
      '[class*="job-title"]',
      '[itemprop="title"]',
      "main h1",
      "h1"
    ]) || fallbackTitle, 300),
    location: cleanText(locationText(job) || textFromSelectors([
      '[data-testid*="location"]',
      '[class*="jobLocation"]',
      '[class*="job-location"]',
      '[itemprop="jobLocation"]'
    ]), 300),
    jobUrl: location.href,
    requirements: cleanText(qualifications || extractRequirements(description), MAX_REQUIREMENTS),
    jobDescription: cleanText(description, MAX_DESCRIPTION),
    referenceNumber: findReferenceNumber(`${pageTitle}\n${description}`)
  };
}
