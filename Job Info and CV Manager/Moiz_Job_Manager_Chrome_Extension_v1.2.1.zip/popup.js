import { createApplication, listApplications } from "./db.js";
import {
  createId,
  findLikelyDuplicate,
  normalizeUrl,
  todayLocal,
  validatePdfFile
} from "./common.js";
import { validateJobUrl } from "./job-link-reader.js";

const form = document.querySelector("#application-form");
const captureMessage = document.querySelector("#capture-message");
const saveMessage = document.querySelector("#save-message");
const saveButton = document.querySelector("#save-button");

const fields = {
  company: document.querySelector("#company"),
  jobTitle: document.querySelector("#job-title"),
  location: document.querySelector("#location"),
  applicationDate: document.querySelector("#application-date"),
  jobUrl: document.querySelector("#job-url"),
  requirements: document.querySelector("#requirements"),
  jobDescription: document.querySelector("#job-description"),
  status: document.querySelector("#status"),
  referenceNumber: document.querySelector("#reference-number"),
  notes: document.querySelector("#notes"),
  cvFile: document.querySelector("#cv-file"),
  coverLetterFile: document.querySelector("#cover-letter-file")
};

fields.applicationDate.value = todayLocal();

function setCaptureMessage(message, type = "success") {
  captureMessage.textContent = message;
  captureMessage.className = `notice ${type}`;
}

function setSaveMessage(message, isError = false) {
  saveMessage.textContent = message;
  saveMessage.classList.toggle("error", isError);
}

function fillField(field, value, replace = false) {
  if (value && (replace || !field.value.trim())) field.value = value;
}

function applyCapturedData(data, replace = false) {
  fillField(fields.company, data.company, replace);
  fillField(fields.jobTitle, data.jobTitle, replace);
  fillField(fields.location, data.location, replace);
  fillField(fields.jobUrl, data.jobUrl, replace);
  fillField(fields.requirements, data.requirements, replace);
  fillField(fields.jobDescription, data.jobDescription, replace);
  fillField(fields.referenceNumber, data.referenceNumber, replace);
}

function captureJobPage() {
  const MAX_DESCRIPTION = 60_000;
  const MAX_REQUIREMENTS = 15_000;

  function cleanText(value, limit = MAX_DESCRIPTION) {
    return String(value || "")
      .replace(/\r/g, "")
      .replace(/[\t\u00a0]+/g, " ")
      .replace(/ +\n/g, "\n")
      .replace(/\n +/g, "\n")
      .replace(/[ ]{2,}/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .slice(0, limit);
  }

  function htmlToText(value) {
    if (!value) return "";
    const template = document.createElement("template");
    template.innerHTML = String(value);
    return cleanText(template.content.textContent || "");
  }

  function textFromSelectors(selectors, limit = 500) {
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      const text = cleanText(element?.innerText || element?.textContent || "", limit);
      if (text) return text;
    }
    return "";
  }

  function collectJsonLd() {
    const values = [];
    for (const script of document.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        values.push(JSON.parse(script.textContent || "null"));
      } catch {
        // Ignore malformed structured data and continue with visible page text.
      }
    }
    return values;
  }

  function flattenStructured(value, output = []) {
    if (!value) return output;
    if (Array.isArray(value)) {
      for (const child of value) flattenStructured(child, output);
      return output;
    }
    if (typeof value !== "object") return output;
    output.push(value);
    if (value["@graph"]) flattenStructured(value["@graph"], output);
    return output;
  }

  function isJobPosting(item) {
    const type = item?.["@type"];
    return Array.isArray(type) ? type.includes("JobPosting") : type === "JobPosting";
  }

  function locationText(job) {
    if (String(job?.jobLocationType || "").toUpperCase().includes("TELECOMMUTE")) return "Remote";
    const locations = Array.isArray(job?.jobLocation) ? job.jobLocation : [job?.jobLocation];
    const parts = [];
    for (const location of locations) {
      const address = location?.address || location;
      const text = [address?.addressLocality, address?.addressRegion, address?.addressCountry]
        .filter(Boolean)
        .map((part) => (typeof part === "object" ? part.name : part))
        .join(", ");
      if (text && !parts.includes(text)) parts.push(text);
    }
    return parts.join(" / ");
  }

  function structuredText(value) {
    if (!value) return "";
    if (Array.isArray(value)) return cleanText(value.map(structuredText).filter(Boolean).join("\n"));
    if (typeof value === "object") return cleanText(value.name || value.value || JSON.stringify(value));
    return htmlToText(value);
  }

  function extractRequirements(text) {
    const cleaned = cleanText(text);
    if (!cleaned) return "";
    const lines = cleaned.split("\n").map((line) => line.trim()).filter(Boolean);
    const starts = [
      /^(requirements?|qualifications?|your profile|candidate profile|what you bring|what you need|what we are looking for|must have|skills(?: and experience)?|experience)\b/i,
      /^(anforderungen|ihr profil|dein profil|qualifikationen|das bringen sie mit|was sie mitbringen|was du mitbringst|kenntnisse und erfahrungen)\b/i
    ];
    const otherHeading = /^(responsibilities|your tasks|what you will do|about (us|the role)|benefits|what we offer|our offer|apply|aufgaben|ihre aufgaben|deine aufgaben|wir bieten|was wir bieten|über uns|bewerbung)\b/i;
    const startIndex = lines.findIndex((line) => line.length < 130 && starts.some((pattern) => pattern.test(line.replace(/[:：]$/, ""))));
    if (startIndex === -1) return "";

    let endIndex = Math.min(lines.length, startIndex + 45);
    for (let index = startIndex + 2; index < Math.min(lines.length, startIndex + 80); index += 1) {
      const line = lines[index].replace(/[:：]$/, "");
      if (line.length < 100 && otherHeading.test(line)) {
        endIndex = index;
        break;
      }
    }
    return cleanText(lines.slice(startIndex, endIndex).join("\n"), MAX_REQUIREMENTS);
  }

  function findReferenceNumber(text) {
    const matches = String(text || "").match(/(?:job\s*(?:id|reference|ref\.?|number|nr\.?|kennziffer)|reference\s*(?:id|number)?|stellen(?:nummer|kennziffer))\s*[:#-]?\s*([A-Z0-9][A-Z0-9._/-]{2,30})/i);
    return matches?.[1] || "";
  }

  const structured = flattenStructured(collectJsonLd());
  const job = structured.find(isJobPosting) || {};
  const structuredDescription = structuredText(job.description);
  const visibleDescription = textFromSelectors([
    "#jobDescriptionText",
    '[data-testid="jobsearch-JobComponent-description"]',
    '[data-testid*="job-description"]',
    '[class*="jobDescription"]',
    '[class*="job-description"]',
    '[id*="job-description"]',
    '[class*="description__text"]',
    "main article",
    "main"
  ], MAX_DESCRIPTION);
  const bodyText = cleanText(document.body?.innerText || "");
  const description = structuredDescription || visibleDescription || bodyText;

  const qualifications = [
    structuredText(job.qualifications),
    structuredText(job.skills),
    structuredText(job.experienceRequirements),
    structuredText(job.educationRequirements)
  ].filter(Boolean).join("\n");

  const pageTitle = cleanText(document.title, 300);
  const fallbackTitle = pageTitle.split(/\s(?:\||–|—|-|·)\s/)[0] || pageTitle;
  const companyFromStructured = typeof job.hiringOrganization === "string"
    ? job.hiringOrganization
    : job.hiringOrganization?.name;

  const data = {
    company: cleanText(companyFromStructured || textFromSelectors([
      '[data-testid="inlineHeader-companyName"]',
      '[data-testid*="company-name"]',
      '[class*="companyName"]',
      '[class*="company-name"]',
      '[itemprop="hiringOrganization"]',
      'header [class*="company"]'
    ]), 300),
    jobTitle: cleanText(job.title || textFromSelectors([
      '[data-testid="job-title"]',
      '[data-testid*="job-title"]',
      '[class*="jobTitle"]',
      '[class*="job-title"]',
      '[itemprop="title"]',
      "main h1",
      "h1"
    ]) || fallbackTitle, 300),
    location: cleanText(locationText(job) || textFromSelectors([
      '[data-testid*="location"]',
      '[class*="jobLocation"]',
      '[class*="job-location"]',
      '[itemprop="jobLocation"]'
    ]), 300),
    jobUrl: location.href,
    requirements: cleanText(qualifications || extractRequirements(description), MAX_REQUIREMENTS),
    jobDescription: cleanText(description, MAX_DESCRIPTION),
    referenceNumber: findReferenceNumber(`${pageTitle}\n${description}`)
  };

  return data;
}

async function readActivePage(force = false) {
  setCaptureMessage(force ? "Reading this page again…" : "Reading this job page…", "loading");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab found.");
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: captureJobPage
    });
    applyCapturedData(result || {});

    const missing = [!result?.company && "company", !result?.jobTitle && "job title"].filter(Boolean);
    if (missing.length) {
      setCaptureMessage(`Page saved partly. Please enter the ${missing.join(" and ")} yourself.`, "warning");
    } else {
      setCaptureMessage("Job details found. Check them, choose your CV, then save.", "success");
    }
  } catch (error) {
    setCaptureMessage("This website blocked automatic reading. Fill the fields or paste the job description manually.", "warning");
    console.warn("Could not capture page", error);
  }
}

async function fillFromPastedLink() {
  const input = document.querySelector("#paste-job-link");
  const button = document.querySelector("#fill-link");
  const status = document.querySelector("#paste-link-status");
  button.disabled = true;
  button.textContent = "Opening…";
  status.className = "";
  status.textContent = "Opening the full dashboard…";

  try {
    const url = validateJobUrl(input.value);
    const dashboardUrl = new URL(chrome.runtime.getURL("dashboard.html"));
    dashboardUrl.searchParams.set("newJobUrl", url.href);
    await chrome.tabs.create({ url: dashboardUrl.href });
    status.textContent = "Continue in the dashboard. It will stay open when Chrome asks permission.";
    status.className = "success";
  } catch (error) {
    console.error(error);
    status.textContent = error.message || "The dashboard could not be opened.";
    status.className = "error";
    button.disabled = false;
    button.textContent = "Continue";
  }
}

document.querySelector("#recapture").addEventListener("click", () => readActivePage(true));
document.querySelector("#fill-link").addEventListener("click", fillFromPastedLink);
document.querySelector("#paste-job-link").addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    fillFromPastedLink();
  }
});
document.querySelector("#open-dashboard").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
});
document.querySelector("#open-about").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("about.html") });
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  setSaveMessage("");

  if (!form.reportValidity()) return;
  const cv = fields.cvFile.files[0];
  if (!cv) {
    setSaveMessage("Please choose the CV PDF used for this job.", true);
    return;
  }

  saveButton.disabled = true;
  saveButton.textContent = "Saving…";

  try {
    validatePdfFile(cv, "CV");
    validatePdfFile(fields.coverLetterFile.files[0], "Cover letter");
    const now = new Date().toISOString();
    const application = {
      id: createId("app"),
      company: fields.company.value.trim(),
      jobTitle: fields.jobTitle.value.trim(),
      location: fields.location.value.trim(),
      jobUrl: normalizeUrl(fields.jobUrl.value),
      applicationDate: fields.applicationDate.value || todayLocal(),
      status: fields.status.value,
      referenceNumber: fields.referenceNumber.value.trim(),
      requirements: fields.requirements.value.trim(),
      jobDescription: fields.jobDescription.value.trim(),
      notes: fields.notes.value.trim(),
      createdAt: now,
      updatedAt: now
    };

    const duplicate = findLikelyDuplicate(await listApplications(), application);
    if (duplicate && !confirm(`This job already appears to be saved for ${duplicate.company}. Save another copy anyway?`)) {
      setSaveMessage("Nothing was saved. The existing application is still in your dashboard.");
      saveButton.disabled = false;
      saveButton.textContent = "Save application";
      return;
    }

    const attachments = [{ kind: "cv", file: cv }];
    const coverLetter = fields.coverLetterFile.files[0];
    if (coverLetter) attachments.push({ kind: "cover-letter", file: coverLetter });

    await createApplication(application, attachments);
    setSaveMessage("Saved. Your CV and job details are now in the dashboard.");
    fields.cvFile.value = "";
    fields.coverLetterFile.value = "";
    saveButton.textContent = "Saved ✓";
    setTimeout(() => {
      saveButton.textContent = "Save another application";
      saveButton.disabled = false;
    }, 900);
  } catch (error) {
    console.error(error);
    setSaveMessage(error.message || "Could not save this application. Please try again.", true);
    saveButton.disabled = false;
    saveButton.textContent = "Save application";
  }
});

readActivePage();
