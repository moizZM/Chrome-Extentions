# My Job Manager

A private Chrome extension for tracking job applications, the exact documents used, follow-ups, deadlines, recruiter contacts, interview preparation and manually chosen job scores.

## Install

1. Extract the ZIP file.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the extracted folder containing `manifest.json`.
6. Pin **My Job Manager** from Chrome's extension menu.

Open the extension and choose **How to use** for the complete visual guide.

## Update without losing data

1. Create a **Backup ZIP** from your current dashboard.
2. Extract this version.
3. Replace the files inside the same extension folder Chrome already uses.
4. Open `chrome://extensions` and click **Reload**.

Do not remove the installed extension or load the update from a different folder if you want Chrome to keep its current local database.

## Privacy change retained in version 1.9

Version 1.9 continues to delete background-profile documents uploaded in version 1.4. Automatic document-based scoring and the old public-feed job search remain removed. Per-application CVs, cover letters and other job documents are stored separately and remain available.

## Main features

- Captures company, title, location, link and full job description from many job pages.
- Stores and opens the exact CV, cover letter and other documents used for each application.
- Gives every application a stable number.
- Separates applications into Full-time and Working Student categories, with automatic classification and a manual selector.
- Keeps the compact navigation header visible while you scroll.
- Uses your own optional score from 0.0 to 10.0, including decimals such as 8.3.
- Suggests a follow-up 14 days after applying, automatically shows captured reference numbers and deadlines, and hides those automatic fields when no reliable value exists.
- Records every status change.
- Saves recruiter name, email, telephone number and contact link.
- Keeps interview questions and prepared answers with the correct application.
- Tracks HR document requests, deadlines, sent dates and HR messages with optional attachments.
- Shows a company page containing all positions, contacts, messages, interviews and company notes.
- Archives closed applications without deleting them.
- Keeps deleted applications recoverable for 30 days before permanent removal.
- Supports bulk archive, status changes, Excel export and deletion.
- Exports one complete application as a PDF report.
- Returns an accidentally applied job to Job Finder while keeping its documents attached.
- Reminds you to make a Backup ZIP every 7, 14 or 30 days.
- Warns before saving a likely duplicate.
- Deletes from the main dashboard with confirmation and Undo.
- Exports a real Excel workbook.
- Creates a complete Backup ZIP containing application records and their documents.
- Imports either the original Backup ZIP or its complete extracted folder.
- Provides a separate Job Finder sheet with explicit job links, platform and location choices, a To Apply list and ChatGPT JSON or CSV import.
- Sorts Job Finder results from the highest score to the lowest score.
- Imports dated application outcomes from JSON produced by a Gmail-connected ChatGPT chat, with a preview before any application is updated.
- Shows response rates, time to rejection/interview, company rejection counts and rates, longest-waiting applications and only explicitly stated rejection reasons.
- Includes a visual How to Use page inside the extension.
- Can copy public job details to a ChatGPT analysis chat you choose, then import the result you paste back. It never reads the chat automatically or sends application documents.

## Job Finder and ChatGPT

The extension cannot read or synchronize another ChatGPT conversation by itself. You can save the URL of your scheduled ChatGPT job-search chat and a separate job-fit analysis chat, choose platforms and locations, copy a structured request, and paste the resulting JSON or CSV into the Job Finder sheet. ChatGPT links open in a new browser tab so the extension page stays open. The extension stores only the results you import.

## Email Outcomes and Insights

The extension does not connect to Gmail. A Gmail-connected ChatGPT chat can summarize job-related emails into the accepted JSON format. You paste that JSON into **Email Insights**, review exact, possible and new matches, then confirm the changes. The JSON is parsed only as data and is never executed as a script. Imported email metadata stays in the same local Chrome database as the applications.

## Backups

Use **Backup ZIP** to transfer or restore everything, including CVs and cover letters. Excel contains application details and document names, but it does not contain the original document bytes.

Older backup versions are supported. When a v1.4 backup contains background-profile documents, version 1.9 intentionally skips them while restoring the applications and their application documents.

My Job Manager is created by **Moiz Zaheer Malik**. See `LICENSE.txt` and **Privacy & help** inside the extension.
