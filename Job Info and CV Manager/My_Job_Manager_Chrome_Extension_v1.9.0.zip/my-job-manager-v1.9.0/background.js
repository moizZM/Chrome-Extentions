import { listApplications, openDatabase } from "./db.js";

const TASK_CHECK_ALARM = "my-job-manager-task-check";
const LEGACY_STORAGE_KEYS = [
  "moizJobManagerCareerProfile",
  "moizJobManagerJobSuggestions",
  "moizJobManagerJobScanMeta",
  "moizJobManagerDismissedJobs"
];

function localDate(value) {
  if (!value) return "";
  return String(value).slice(0, 10);
}

function setTaskBadge(applications = []) {
  const today = new Date();
  const offset = today.getTimezoneOffset() * 60_000;
  const dateKey = new Date(today.getTime() - offset).toISOString().slice(0, 10);
  const count = applications.filter((app) => {
    if (app.archivedAt || app.deletedAt || app.returnedToFinderAt) return false;
    const followUpDue = app.followUpDate && !app.followUpCompletedAt && localDate(app.followUpDate) <= dateKey;
    const deadlineDue = app.applicationDeadline && localDate(app.applicationDeadline) <= dateKey && !["rejected", "withdrawn", "offer"].includes(app.status);
    const interviewDue = app.interviewDateTime && localDate(app.interviewDateTime) <= dateKey && app.status === "interview";
    const documentsDue = (app.documentRequests || []).some((request) => !request.sentDate && request.deadline && localDate(request.deadline) <= dateKey);
    return followUpDue || deadlineDue || interviewDue || documentsDue;
  }).length;
  chrome.action.setBadgeBackgroundColor({ color: "#2457d6" });
  chrome.action.setBadgeText({ text: count ? String(Math.min(99, count)) : "" });
}

async function ensureAlarm() {
  await chrome.alarms.create(TASK_CHECK_ALARM, {
    delayInMinutes: 1,
    periodInMinutes: 60
  });
}

async function refreshTaskBadge() {
  try {
    setTaskBadge(await listApplications());
  } catch {
    chrome.action.setBadgeText({ text: "" });
  }
}

async function removeLegacyBackgroundData() {
  // Opening database v3 deletes the old profileDocuments object store.
  await openDatabase();
  await chrome.storage.local.remove(LEGACY_STORAGE_KEYS);
  try {
    await chrome.permissions.remove({ origins: ["https://www.arbeitnow.com/*"] });
  } catch {
    // It is fine if that old optional permission was never granted.
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  await removeLegacyBackgroundData();
  ensureAlarm();
  refreshTaskBadge();
});

chrome.runtime.onStartup.addListener(() => {
  removeLegacyBackgroundData();
  ensureAlarm();
  refreshTaskBadge();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TASK_CHECK_ALARM) refreshTaskBadge();
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "refresh-task-badge") refreshTaskBadge();
});

removeLegacyBackgroundData();
ensureAlarm();
refreshTaskBadge();
