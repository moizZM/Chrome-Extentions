export const STATUS_OPTIONS = [
  { value: "applied", label: "Applied" },
  { value: "documents-requested", label: "Documents requested" },
  { value: "documents-sent", label: "Documents sent" },
  { value: "interview", label: "Interview" },
  { value: "offer", label: "Offer" },
  { value: "rejected", label: "Rejected" },
  { value: "withdrawn", label: "Withdrawn" }
];

export const STATUS_LABELS = Object.fromEntries(
  STATUS_OPTIONS.map((status) => [status.value, status.label])
);

export const EMPLOYMENT_CATEGORY_OPTIONS = [
  { value: "full-time", label: "Full-time" },
  { value: "working-student", label: "Working Student" }
];

export const EMPLOYMENT_CATEGORY_LABELS = Object.fromEntries(
  EMPLOYMENT_CATEGORY_OPTIONS.map((category) => [category.value, category.label])
);

export const MAX_PDF_BYTES = 25 * 1024 * 1024;
export const MAX_OTHER_FILE_BYTES = 50 * 1024 * 1024;

export function todayLocal() {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60_000;
  return new Date(now.getTime() - offset).toISOString().slice(0, 10);
}

export function addCalendarDays(dateValue, days) {
  const match = String(dateValue || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match || !Number.isFinite(Number(days))) return "";
  const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
  date.setUTCDate(date.getUTCDate() + Number(days));
  return date.toISOString().slice(0, 10);
}

export function formatDate(value) {
  if (!value) return "Not set";
  const date = new Date(`${value}T12:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric"
  }).format(date);
}

export function formatBytes(bytes = 0) {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** index;
  return `${value.toFixed(index === 0 || value >= 10 ? 0 : 1)} ${units[index]}`;
}

export function safeFileName(value, fallback = "file") {
  const cleaned = String(value || "")
    .normalize("NFKD")
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return (cleaned || fallback).slice(0, 120);
}

export function createId(prefix = "item") {
  const id = globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}-${id}`;
}

export function normalizeUrl(value) {
  const text = String(value || "").trim();
  if (!text) return "";
  try {
    const url = new URL(text);
    if (!["http:", "https:"].includes(url.protocol)) return "";
    return url.href;
  } catch {
    return "";
  }
}

export function statusLabel(value) {
  if (value === "saved") return "Saved for later";
  return STATUS_LABELS[value] || "Applied";
}

export function normalizeCompanyKey(value) {
  return String(value || "").trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

export function applicationAgeLabel(value, referenceDate = new Date()) {
  if (!value) return "Application date not set";
  const match = String(value).slice(0, 10).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return "Application date not set";
  const dateDay = Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  if (Number.isNaN(dateDay)) return "Application date not set";
  const today = new Date(referenceDate);
  const todayDay = Date.UTC(today.getFullYear(), today.getMonth(), today.getDate());
  const days = Math.max(0, Math.floor((todayDay - dateDay) / 86_400_000));
  if (days === 0) return "Applied today";
  if (days === 1) return "Applied yesterday";
  return `Applied ${days} days ago`;
}

export function recordState(application = {}) {
  if (application.deletedAt) return "deleted";
  if (application.archivedAt) return "archived";
  if (application.returnedToFinderAt) return "returned";
  return "active";
}

export function employmentCategory(record = {}) {
  if (["full-time", "working-student"].includes(record.employmentCategory)) {
    return record.employmentCategory;
  }
  const suppliedCategory = String(record.employmentCategory || "").trim().toLocaleLowerCase();
  if (/^(working[ -]?student|werkstudent(?:in)?)$/.test(suppliedCategory)) return "working-student";
  if (/^(full[ -]?time|vollzeit)$/.test(suppliedCategory)) return "full-time";
  const text = [
    suppliedCategory,
    record.jobTitle,
    record.employmentType,
    record.jobType,
    record.contractType,
    record.notes,
    record.jobDescription
  ].filter(Boolean).join(" ").toLocaleLowerCase();
  return /\b(werkstudent[a-zäöüß]*|working[ -]?student|student assistant|studentische hilfskraft|studentische aushilfe|student helper|student employee|working student job)\b/i.test(text)
    ? "working-student"
    : "full-time";
}

export function employmentCategoryLabel(record = {}) {
  return EMPLOYMENT_CATEGORY_LABELS[employmentCategory(record)] || "Full-time";
}

export function normalizeManualScore(value) {
  if (value === "" || value === null || value === undefined) return null;
  const score = Number(value);
  if (!Number.isFinite(score)) return null;
  return Math.round(Math.max(0, Math.min(10, score)) * 10) / 10;
}

export function applicationScore(application) {
  const direct = normalizeManualScore(application?.manualScore);
  if (direct !== null) return direct;

  // v1.3 used a personal 1–5 star rating. Preserve that personal choice during
  // the upgrade, but never reuse the removed automatic background-profile score.
  const legacyManual = Number(application?.manualRating);
  if (Number.isFinite(legacyManual) && legacyManual >= 1) {
    return Math.round(Math.min(5, legacyManual) * 20) / 10;
  }
  return null;
}

// Kept as a compatibility alias for older exports/tests.
export function applicationRating(application) {
  const score = applicationScore(application);
  return score === null ? 0 : score;
}

export function validatePdfFile(file, label = "PDF") {
  if (!file) return;
  const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name || "");
  if (!isPdf) throw new Error(`${label} must be a PDF file.`);
  if (file.size > MAX_PDF_BYTES) throw new Error(`${label} must be smaller than 25 MB.`);
}

export function validateOtherFile(file) {
  if (file?.size > MAX_OTHER_FILE_BYTES) {
    throw new Error(`${file.name || "Document"} must be smaller than 50 MB.`);
  }
}

function canonicalJobUrl(value) {
  const normalized = normalizeUrl(value);
  if (!normalized) return "";
  const url = new URL(normalized);
  url.hash = "";
  url.hostname = url.hostname.toLocaleLowerCase();
  url.pathname = url.pathname.replace(/\/+$/, "") || "/";

  const removableParameters = new Set([
    "campaign",
    "campaignid",
    "ref",
    "referrer",
    "sorting",
    "sortingtype",
    "sort",
    "source",
    "src",
    "tracking",
    "trackingid",
    "tracking_id"
  ]);
  for (const key of [...url.searchParams.keys()]) {
    const lowerKey = key.toLocaleLowerCase();
    if (lowerKey.startsWith("utm_") || removableParameters.has(lowerKey)) {
      url.searchParams.delete(key);
    }
  }
  url.searchParams.sort();
  return url.href;
}

export function findLikelyDuplicate(applications, candidate) {
  const candidateUrl = canonicalJobUrl(candidate?.jobUrl);
  if (candidateUrl) {
    const exactUrl = applications.find((app) => canonicalJobUrl(app.jobUrl) === candidateUrl);
    if (exactUrl) return exactUrl;
  }

  const compact = (value) => String(value || "").trim().toLocaleLowerCase();
  const company = compact(candidate?.company);
  const title = compact(candidate?.jobTitle);
  const location = compact(candidate?.location);
  if (!company || !title) return null;
  return applications.find((app) => (
    compact(app.company) === company
    && compact(app.jobTitle) === title
    && (!location || !compact(app.location) || compact(app.location) === location)
  )) || null;
}
