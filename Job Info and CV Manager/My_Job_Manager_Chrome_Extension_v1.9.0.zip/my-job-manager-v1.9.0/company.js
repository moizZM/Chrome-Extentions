import { listApplications } from "./db.js";
import { applicationAgeLabel, employmentCategoryLabel, formatDate, normalizeCompanyKey, recordState, statusLabel } from "./common.js";

const COMPANY_PROFILES_KEY = "myJobManagerCompanyProfiles";
const JOB_FINDER_SETTINGS_KEY = "myJobManagerJobFinder";
const $ = (selector) => document.querySelector(selector);
const companyName = new URLSearchParams(location.search).get("name")?.trim() || "Unknown company";
const companyKey = normalizeCompanyKey(companyName);
let applications = [];
let profiles = {};
let saveTimer;

function element(tag, className = "", text = "") {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== "") node.textContent = text;
  return node;
}

function showToast(message) {
  const toast = $("#company-toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 4200);
}

async function copyText(value) {
  try { await navigator.clipboard.writeText(value); }
  catch {
    const textarea = document.createElement("textarea");
    textarea.value = value;
    document.body.append(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }
}

function companyApplications() {
  return applications
    .filter((app) => normalizeCompanyKey(app.company) === companyKey && recordState(app) !== "returned")
    .sort((left, right) => String(right.applicationDate || right.createdAt || "").localeCompare(String(left.applicationDate || left.createdAt || "")));
}

function likelyWebsite(apps) {
  for (const app of apps) {
    try {
      const url = new URL(app.jobUrl);
      if (/linkedin|indeed|stepstone|xing|glassdoor|arbeitsagentur|greenhouse|lever\.co/i.test(url.hostname)) continue;
      return url.origin;
    } catch { /* Keep looking. */ }
  }
  return "";
}

function appendEmpty(container, text) {
  container.append(element("p", "company-empty", text));
}

function renderContacts(apps) {
  const contacts = [];
  const seen = new Set();
  for (const app of apps) {
    if (![app.recruiterName, app.recruiterEmail, app.recruiterPhone, app.recruiterLinkedIn].some(Boolean)) continue;
    const key = [app.recruiterEmail, app.recruiterPhone, app.recruiterName].join("|").toLocaleLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    contacts.push(app);
  }
  $("#contact-count").textContent = contacts.length;
  const list = $("#contact-list");
  list.replaceChildren();
  if (!contacts.length) { appendEmpty(list, "No recruiter contacts saved."); return; }
  for (const app of contacts) {
    const row = element("div", "company-list-item");
    row.append(element("strong", "", app.recruiterName || "Recruiter"));
    if (app.recruiterEmail) {
      const link = element("a", "", app.recruiterEmail);
      link.href = `mailto:${app.recruiterEmail}`;
      row.append(link);
    }
    if (app.recruiterPhone) row.append(element("span", "", app.recruiterPhone));
    if (app.recruiterLinkedIn) {
      const link = element("a", "", "Open contact link");
      link.href = app.recruiterLinkedIn;
      link.target = "_blank";
      link.rel = "noreferrer";
      row.append(link);
    }
    row.append(element("small", "", app.jobTitle || "Application"));
    list.append(row);
  }
}

function renderInterviews(apps) {
  const interviews = apps.filter((app) => app.interviewDateTime || (app.statusHistory || []).some((entry) => entry.status === "interview"));
  $("#interview-count").textContent = interviews.length;
  const list = $("#interview-list");
  list.replaceChildren();
  if (!interviews.length) { appendEmpty(list, "No interview history saved."); return; }
  for (const app of interviews) {
    const row = element("div", "company-list-item");
    row.append(element("strong", "", app.jobTitle || "Interview"));
    const entered = [...(app.statusHistory || [])].reverse().find((entry) => entry.status === "interview");
    row.append(element("span", "", app.interviewDateTime ? new Date(app.interviewDateTime).toLocaleString() : `Interview status added ${entered?.changedAt ? new Date(entered.changedAt).toLocaleDateString() : ""}`));
    if (app.interviewNotes) row.append(element("small", "", app.interviewNotes));
    list.append(row);
  }
}

function renderMessages(apps) {
  const messages = apps.flatMap((app) => (app.hrMessages || []).map((message) => ({ ...message, jobTitle: app.jobTitle })))
    .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
  $("#message-count").textContent = messages.length;
  const list = $("#message-list");
  list.replaceChildren();
  if (!messages.length) { appendEmpty(list, "No HR messages saved."); return; }
  for (const message of messages) {
    const row = element("div", "company-list-item");
    row.append(
      element("strong", "", `${message.direction === "sent" ? "Sent" : "Received"}: ${message.subject || "HR message"}`),
      element("span", "", message.message || "No message text"),
      element("small", "", `${message.date ? formatDate(message.date) : "Date not set"} · ${message.jobTitle || "Application"}`)
    );
    list.append(row);
  }
}

function renderApplications(apps) {
  const list = $("#company-applications");
  list.replaceChildren();
  if (!apps.length) { appendEmpty(list, "No applications found for this company."); return; }
  for (const app of apps) {
    const row = element("div", "company-application");
    const copy = element("div", "company-application-copy");
    copy.append(
      element("strong", "", app.jobTitle || "Untitled job"),
      element("span", "", `${employmentCategoryLabel(app)} · ${app.applicationDate ? `${formatDate(app.applicationDate)} (${applicationAgeLabel(app.applicationDate)})` : "Not applied"}`)
    );
    const folder = recordState(app);
    const status = element("span", `company-status ${folder === "active" ? "" : folder}`, folder === "active" ? statusLabel(app.status) : folder === "archived" ? "Archived" : "Recently Deleted");
    const open = element("button", "company-open", "Open application");
    open.type = "button";
    open.addEventListener("click", () => { location.href = `${chrome.runtime.getURL("dashboard.html")}?edit=${encodeURIComponent(app.id)}`; });
    row.append(copy, status, open);
    list.append(row);
  }
}

function render() {
  const apps = companyApplications();
  $("#company-name").textContent = companyName;
  document.title = `${companyName} · My Job Manager`;
  $("#company-summary").textContent = apps.length ? `Your complete saved history with ${companyName}.` : "No matching applications were found.";
  $("#company-job-count").textContent = apps.length;
  $("#company-active-count").textContent = apps.filter((app) => recordState(app) === "active").length;
  $("#company-interview-count").textContent = apps.filter((app) => app.status === "interview" || (app.statusHistory || []).some((entry) => entry.status === "interview")).length;
  renderContacts(apps);
  renderInterviews(apps);
  renderMessages(apps);
  renderApplications(apps);
  const profile = profiles[companyKey] || {};
  $("#company-website").value = profile.website || likelyWebsite(apps);
  $("#company-notes").value = profile.notes || "";
}

async function saveProfile() {
  clearTimeout(saveTimer);
  profiles[companyKey] = {
    companyName,
    website: $("#company-website").value.trim(),
    notes: $("#company-notes").value,
    updatedAt: new Date().toISOString()
  };
  await chrome.storage.local.set({ [COMPANY_PROFILES_KEY]: profiles });
  $("#company-save-status").textContent = "Saved locally";
}

function scheduleSave() {
  clearTimeout(saveTimer);
  $("#company-save-status").textContent = "Saving…";
  saveTimer = setTimeout(saveProfile, 450);
}

async function researchCompany() {
  const prompt = `Research ${companyName} for a job candidate. Use current, reliable public sources. Summarize what the company does, its main products or services, recent important news, work culture signals, interview themes, and useful questions to ask. Do not assume any private information about me.`;
  await copyText(prompt);
  const stored = await chrome.storage.local.get(JOB_FINDER_SETTINGS_KEY);
  let url = String(stored[JOB_FINDER_SETTINGS_KEY]?.analysisChatUrl || "").trim();
  if (!/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//i.test(url)) url = "https://chatgpt.com/";
  showToast("Company-only research request copied. Paste it in the new ChatGPT tab.");
  setTimeout(() => chrome.tabs.create({ url }), 350);
}

async function initialize() {
  const [allApplications, stored] = await Promise.all([listApplications(), chrome.storage.local.get(COMPANY_PROFILES_KEY)]);
  applications = allApplications;
  profiles = stored[COMPANY_PROFILES_KEY] && typeof stored[COMPANY_PROFILES_KEY] === "object" ? stored[COMPANY_PROFILES_KEY] : {};
  render();
}

$("#back-applications").addEventListener("click", () => { location.href = chrome.runtime.getURL("dashboard.html"); });
$("#research-company").addEventListener("click", researchCompany);
$("#company-website").addEventListener("input", scheduleSave);
$("#company-notes").addEventListener("input", scheduleSave);
$("#open-company-website").addEventListener("click", () => {
  const value = $("#company-website").value.trim();
  if (!value) { showToast("Add the company website first."); return; }
  try { chrome.tabs.create({ url: new URL(value).href }); }
  catch { showToast("Enter a complete website address, such as https://company.com."); }
});

initialize().catch((error) => {
  console.error(error);
  showToast("The company page could not be loaded.");
});
