import {
  addFiles,
  createApplication,
  deleteApplication as removeApplication,
  deleteFile,
  deleteFilesByKind,
  getAllFiles,
  getApplication,
  getFilesForApplication,
  listApplications,
  listJobLeads,
  mergeBackup,
  putJobLead,
  updateApplication
} from "./db.js";
import {
  addCalendarDays,
  applicationScore,
  applicationAgeLabel,
  createId,
  employmentCategory,
  employmentCategoryLabel,
  findLikelyDuplicate,
  formatBytes,
  formatDate,
  normalizeManualScore,
  normalizeUrl,
  recordState,
  safeFileName,
  STATUS_OPTIONS,
  statusLabel,
  todayLocal,
  validateOtherFile,
  validatePdfFile
} from "./common.js";
import {
  buildApplicationsXlsx,
  buildApplicationPdf,
  buildBackupZip,
  downloadBlob,
  readBackupFolder,
  readBackupZip
} from "./export-utils.js";
import { captureJobPage } from "./page-capture.js";
import { readJobFromLink } from "./job-link-reader.js";
import {
  buildAnalysisRequest,
  applicationToLead,
  normalizeLead,
  parseStructuredResult
} from "./lead-utils.js";

const GLOBAL_NOTES_KEY = "moizJobManagerGlobalNotes";
const JOB_FINDER_SETTINGS_KEY = "myJobManagerJobFinder";
const PREFERENCES_KEY = "myJobManagerPreferences";
const COMPANY_PROFILES_KEY = "myJobManagerCompanyProfiles";
const LEGACY_PRIVATE_KEYS = [
  "moizJobManagerCareerProfile",
  "moizJobManagerJobSuggestions",
  "moizJobManagerJobScanMeta",
  "moizJobManagerDismissedJobs"
];

const state = {
  applications: [],
  files: [],
  jobLeads: [],
  globalNotes: "",
  summaryStatus: "all",
  applicationCategory: "all",
  recordView: "active",
  selectedIds: new Set(),
  editingFiles: [],
  editingDocumentRequests: [],
  editingHrMessages: [],
  pendingHrMessageFiles: [],
  preferences: { backupReminderDays: 14, lastBackupAt: "" },
  pendingAnalysis: null,
  duplicateResolver: null,
  deleteResolver: null,
  pendingDeleteId: "",
  followUpAuto: true,
  toastTimer: null,
  notesTimer: null
};

const $ = (selector) => document.querySelector(selector);
const elements = {
  body: $("#applications-body"),
  empty: $("#empty-state"),
  emptyMessage: $("#empty-message"),
  resultsCount: $("#results-count"),
  search: $("#search"),
  statusFilter: $("#status-filter"),
  scoreFilter: $("#score-filter"),
  sortOrder: $("#sort-order"),
  notes: $("#global-notes"),
  notesStatus: $("#global-notes-status"),
  applicationDialog: $("#application-dialog"),
  form: $("#edit-form"),
  existingFiles: $("#existing-files"),
  history: $("#status-history"),
  linkStatus: $("#link-read-status"),
  duplicateDialog: $("#duplicate-dialog"),
  deleteDialog: $("#delete-dialog"),
  restoreDialog: $("#restore-dialog"),
  restoreStatus: $("#restore-status"),
  analysisDialog: $("#application-analysis-dialog"),
  analysisText: $("#application-analysis-text"),
  analysisStatus: $("#application-analysis-status"),
  toast: $("#toast"),
  toastMessage: $("#toast-message"),
  toastAction: $("#toast-action")
};

const fields = {
  id: $("#edit-id"),
  url: $("#edit-url"),
  company: $("#edit-company"),
  title: $("#edit-title"),
  location: $("#edit-location"),
  date: $("#edit-date"),
  status: $("#edit-status"),
  employmentCategory: $("#edit-employment-category"),
  score: $("#edit-score"),
  reference: $("#edit-reference"),
  followUp: $("#edit-follow-up"),
  followUpDone: $("#edit-follow-up-done"),
  deadline: $("#edit-deadline"),
  interviewDate: $("#edit-interview-date"),
  recruiterName: $("#edit-recruiter-name"),
  recruiterEmail: $("#edit-recruiter-email"),
  recruiterPhone: $("#edit-recruiter-phone"),
  recruiterLink: $("#edit-recruiter-link"),
  interviewQuestions: $("#edit-interview-questions"),
  interviewNotes: $("#edit-interview-notes"),
  description: $("#edit-description"),
  notes: $("#edit-notes"),
  requestDocuments: $("#request-documents"),
  requestDate: $("#request-date"),
  requestDeadline: $("#request-deadline"),
  hrMessageDirection: $("#hr-message-direction"),
  hrMessageDate: $("#hr-message-date"),
  hrMessageSubject: $("#hr-message-subject"),
  hrMessageText: $("#hr-message-text"),
  hrMessageFile: $("#hr-message-file"),
  cv: $("#edit-cv"),
  letter: $("#edit-letter"),
  others: $("#edit-other-files")
};

function element(tag, className = "", text = "") {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== "") node.textContent = text;
  return node;
}

function dateTimeLabel(value) {
  if (!value) return "Not set";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat(undefined, {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(date);
}

function localDateKey(value) {
  if (!value) return "";
  return String(value).slice(0, 10);
}

function cleanApplication(raw) {
  const app = { ...raw };
  app.id ||= createId("app");
  app.company = String(app.company || "").trim();
  app.jobTitle = String(app.jobTitle || "").trim();
  app.status ||= app.returnedToFinderAt ? "saved" : "applied";
  if (!app.returnedToFinderAt) app.applicationDate ||= todayLocal();
  else app.applicationDate ||= "";
  app.createdAt ||= new Date().toISOString();
  app.updatedAt ||= app.createdAt;
  app.manualScore = applicationScore(app);
  app.employmentCategory = employmentCategory(app);
  app.archivedAt = String(app.archivedAt || "");
  app.deletedAt = String(app.deletedAt || "");
  app.returnedToFinderAt = String(app.returnedToFinderAt || "");
  app.documentRequests = Array.isArray(app.documentRequests) ? app.documentRequests.filter((item) => item?.id && item.documents) : [];
  app.hrMessages = Array.isArray(app.hrMessages) ? app.hrMessages.filter((item) => item?.id) : [];
  app.statusHistory = Array.isArray(app.statusHistory) && app.statusHistory.length
    ? app.statusHistory.filter((entry) => entry && entry.status)
    : [{ status: app.status, changedAt: app.createdAt }];

  for (const key of [
    "manualRating", "priority", "matchScore", "matchStars", "matchLabel",
    "matchedSkills", "missingSkills", "matchLanguageNote", "matchSeniorityNote",
    "matchExplanation", "matchUpdatedAt"
  ]) delete app[key];
  return app;
}

function applicationChanged(left, right) {
  return JSON.stringify(left) !== JSON.stringify(right);
}

async function migrateApplications(applications) {
  const cleaned = [];
  for (const raw of applications) {
    const app = cleanApplication(raw);
    cleaned.push(app);
    if (applicationChanged(raw, app)) await updateApplication(app);
  }
  return cleaned;
}

async function loadState() {
  await chrome.storage.local.remove(LEGACY_PRIVATE_KEYS);
  try { await chrome.permissions.remove({ origins: ["https://www.arbeitnow.com/*"] }); } catch { /* Not previously granted. */ }
  const [applications, files, jobLeads, stored] = await Promise.all([
    listApplications(),
    getAllFiles(),
    listJobLeads(),
    chrome.storage.local.get([GLOBAL_NOTES_KEY, PREFERENCES_KEY])
  ]);
  const cutoff = Date.now() - 30 * 86_400_000;
  const expired = applications.filter((app) => app.deletedAt && new Date(app.deletedAt).getTime() <= cutoff);
  for (const app of expired) await removeApplication(app.id);
  const remaining = applications.filter((app) => !expired.some((deleted) => deleted.id === app.id));
  state.applications = await migrateApplications(remaining);
  state.files = files.filter((file) => !expired.some((app) => app.id === file.appId));
  state.jobLeads = jobLeads.map((lead) => normalizeLead({}, lead));
  state.globalNotes = String(stored[GLOBAL_NOTES_KEY] || "");
  state.preferences = { ...state.preferences, ...(stored[PREFERENCES_KEY] || {}) };
  elements.notes.value = state.globalNotes;
}

function showToast(message, { error = false, actionLabel = "", action } = {}) {
  clearTimeout(state.toastTimer);
  elements.toastMessage.textContent = message;
  elements.toast.classList.toggle("error", error);
  elements.toastAction.hidden = !actionLabel;
  elements.toastAction.textContent = actionLabel;
  elements.toastAction.onclick = action || null;
  elements.toast.classList.add("show");
  state.toastTimer = setTimeout(() => elements.toast.classList.remove("show"), actionLabel ? 9_000 : 4_500);
}

function refreshBadge() {
  chrome.runtime.sendMessage({ type: "refresh-task-badge" }).catch(() => {});
}

function orderedNumbers() {
  const ordered = [...state.applications].sort((left, right) => {
    const a = left.createdAt || `${left.applicationDate}-${left.id}`;
    const b = right.createdAt || `${right.applicationDate}-${right.id}`;
    return String(a).localeCompare(String(b));
  });
  return new Map(ordered.map((app, index) => [app.id, index + 1]));
}

function filesFor(appId) {
  return state.files.filter((file) => file.appId === appId);
}

function activeApplications() {
  return state.applications.filter((app) => recordState(app) === "active");
}

function visibleApplications() {
  const query = elements.search.value.trim().toLocaleLowerCase();
  const status = elements.statusFilter.value;
  const scoreFilter = elements.scoreFilter.value;
  const visible = state.applications.filter((app) => {
    if (recordState(app) !== state.recordView) return false;
    if (state.summaryStatus !== "all" && app.status !== state.summaryStatus) return false;
    if (state.applicationCategory !== "all" && employmentCategory(app) !== state.applicationCategory) return false;
    if (status !== "all" && app.status !== status) return false;
    const score = applicationScore(app);
    if (scoreFilter === "unrated" && score !== null) return false;
    if (!["all", "unrated"].includes(scoreFilter) && (score === null || score < Number(scoreFilter))) return false;
    if (!query) return true;
    return [
      app.company, app.jobTitle, app.location, app.notes, app.recruiterName, app.recruiterEmail, app.jobDescription,
      ...(app.documentRequests || []).map((item) => item.documents),
      ...(app.hrMessages || []).flatMap((item) => [item.subject, item.message]),
      ...(app.emailEvents || []).flatMap((item) => [item.emailSubject, item.reasonStated, item.notes]),
      ...(app.gmailImportNotes || [])
    ]
      .join(" ").toLocaleLowerCase().includes(query);
  });

  const sort = elements.sortOrder.value;
  visible.sort((left, right) => {
    if (sort === "date-asc") return String(left.applicationDate || "").localeCompare(String(right.applicationDate || ""));
    if (sort === "company-asc") return String(left.company || "").localeCompare(String(right.company || ""));
    if (sort === "score-desc") return (applicationScore(right) ?? -1) - (applicationScore(left) ?? -1);
    if (sort === "score-asc") return (applicationScore(left) ?? 99) - (applicationScore(right) ?? 99);
    return String(right.applicationDate || "").localeCompare(String(left.applicationDate || ""));
  });
  return visible;
}

function renderSummary() {
  const active = activeApplications();
  const count = (status) => active.filter((app) => app.status === status).length;
  $("#count-total").textContent = active.length;
  for (const status of ["applied", "interview", "offer", "rejected"]) {
    $(`#count-${status}`).textContent = count(status);
  }
  const inFolder = state.applications.filter((app) => recordState(app) === state.recordView);
  $("#category-count-all").textContent = inFolder.length;
  $("#category-count-full-time").textContent = inFolder.filter((app) => employmentCategory(app) === "full-time").length;
  $("#category-count-working-student").textContent = inFolder.filter((app) => employmentCategory(app) === "working-student").length;
  $("#record-count-active").textContent = active.length;
  $("#record-count-archived").textContent = state.applications.filter((app) => recordState(app) === "archived").length;
  $("#record-count-deleted").textContent = state.applications.filter((app) => recordState(app) === "deleted").length;
}

function openStoredFile(file) {
  if (!(file?.blob instanceof Blob)) {
    showToast("This stored document could not be opened.", { error: true });
    return;
  }
  const url = URL.createObjectURL(file.blob);
  chrome.tabs.create({ url }).catch(() => downloadBlob(file.blob, file.name || "document"));
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

function fileBadges(app) {
  const wrapper = element("div", "file-badges");
  const files = filesFor(app.id);
  const chosen = [files.find((file) => file.kind === "cv"), files.find((file) => file.kind === "cover-letter")].filter(Boolean);
  for (const file of chosen) {
    const label = file.kind === "cv" ? "CV" : "Letter";
    const button = element("button", `file-badge file-badge-button ${file.kind === "cv" ? "cv" : ""}`, label);
    button.type = "button";
    button.title = `Open ${file.name}`;
    button.addEventListener("click", () => openStoredFile(file));
    wrapper.append(button);
  }
  const otherCount = files.filter((file) => !["cv", "cover-letter"].includes(file.kind)).length;
  if (otherCount) {
    const button = element("button", "file-badge file-badge-button", `${otherCount} file${otherCount === 1 ? "" : "s"}`);
    button.type = "button";
    button.addEventListener("click", () => openApplicationDialog(app.id));
    wrapper.append(button);
  }
  if (!files.length) wrapper.append(element("span", "file-badge file-badge-empty", "No files"));
  return wrapper;
}

function nextDateFor(app) {
  const dates = [];
  if (app.followUpDate && !app.followUpCompletedAt) dates.push({ label: "Follow-up", value: app.followUpDate });
  if (app.applicationDeadline) dates.push({ label: "Deadline", value: app.applicationDeadline });
  if (app.interviewDateTime) dates.push({ label: "Interview", value: app.interviewDateTime });
  return dates.sort((a, b) => String(a.value).localeCompare(String(b.value)))[0] || null;
}

async function saveInlineScore(app, input) {
  if (input.value !== "" && (Number(input.value) < 0 || Number(input.value) > 10)) {
    input.setCustomValidity("Enter a score from 0 to 10.");
    input.reportValidity();
    return;
  }
  input.setCustomValidity("");
  app.manualScore = normalizeManualScore(input.value);
  app.updatedAt = new Date().toISOString();
  await updateApplication(app);
  showToast(app.manualScore === null ? "Score cleared." : `Score saved as ${app.manualScore.toFixed(1)}/10.`);
  renderAll();
}

async function saveInlineStatus(app, select) {
  if (select.value === app.status) return;
  const changedAt = new Date().toISOString();
  app.status = select.value;
  app.statusHistory = [...(app.statusHistory || []), { status: app.status, changedAt }];
  app.updatedAt = changedAt;
  await updateApplication(app);
  renderAll();
  refreshBadge();
  showToast(`Status changed to ${statusLabel(app.status)}.`);
}

function openCompanyPage(company) {
  const url = new URL(chrome.runtime.getURL("company.html"));
  url.searchParams.set("name", company || "Unknown company");
  chrome.tabs.create({ url: url.href });
}

function renderBulkActions() {
  const count = state.selectedIds.size;
  $("#bulk-actions").hidden = count === 0;
  $("#bulk-count").textContent = `${count} selected`;
  $("#bulk-archive").hidden = state.recordView === "deleted";
  $("#bulk-archive").textContent = state.recordView === "archived" ? "Restore from Archive" : "Archive";
  $("#bulk-status").closest("label").hidden = state.recordView !== "active";
  $("#bulk-apply-status").hidden = state.recordView !== "active";
  $("#bulk-delete").hidden = state.recordView === "deleted";
  const visible = visibleApplications();
  $("#select-all-visible").checked = visible.length > 0 && visible.every((app) => state.selectedIds.has(app.id));
  $("#select-all-visible").indeterminate = visible.some((app) => state.selectedIds.has(app.id)) && !$("#select-all-visible").checked;
}

function toggleSelected(id, selected) {
  if (selected) state.selectedIds.add(id);
  else state.selectedIds.delete(id);
  renderBulkActions();
}

function renderApplications() {
  const apps = visibleApplications();
  const numbers = orderedNumbers();
  elements.body.replaceChildren();

  for (const app of apps) {
    const row = document.createElement("tr");
    row.dataset.id = app.id;
    const selectTd = element("td", "select-cell");
    const rowCheck = document.createElement("input");
    rowCheck.type = "checkbox";
    rowCheck.checked = state.selectedIds.has(app.id);
    rowCheck.setAttribute("aria-label", `Select ${app.company} ${app.jobTitle}`);
    rowCheck.addEventListener("change", () => toggleSelected(app.id, rowCheck.checked));
    selectTd.append(rowCheck);
    row.append(selectTd);
    row.append(element("td", "number-cell", `#${String(numbers.get(app.id) || 0).padStart(3, "0")}`));

    const jobTd = document.createElement("td");
    const job = element("div", "job-cell");
    const heading = element("div", "job-heading");
    const company = element("button", "company-link", app.company || "Unknown company");
    company.type = "button";
    company.title = "Open company page";
    company.addEventListener("click", () => openCompanyPage(app.company));
    heading.append(company);
    const title = app.jobUrl ? element("a", "job-link", app.jobTitle || "Untitled job") : element("span", "", app.jobTitle || "Untitled job");
    if (title instanceof HTMLAnchorElement) {
      title.href = app.jobUrl;
      title.target = "_blank";
      title.rel = "noreferrer";
    }
    const category = element("span", `employment-category ${employmentCategory(app)}`, employmentCategoryLabel(app));
    job.append(heading, title, category);
    if (app.recruiterName) job.append(element("span", "", `Recruiter: ${app.recruiterName}`));
    jobTd.append(job);
    row.append(jobTd);
    const appliedTd = element("td", "date-cell");
    appliedTd.append(element("span", "", app.applicationDate ? formatDate(app.applicationDate) : "Not applied"));
    if (app.applicationDate) appliedTd.append(element("small", "application-age", applicationAgeLabel(app.applicationDate)));
    row.append(appliedTd);

    const next = nextDateFor(app);
    const nextTd = element("td", "next-date-cell");
    if (next) nextTd.append(element("span", "", next.label), element("small", "", next.label === "Interview" ? dateTimeLabel(next.value) : formatDate(next.value)));
    else nextTd.textContent = "—";
    row.append(nextTd);

    const fileTd = document.createElement("td");
    fileTd.append(fileBadges(app));
    row.append(fileTd);

    const scoreTd = element("td", "score-cell");
    const score = element("input", "score-input");
    score.type = "number";
    score.min = "0";
    score.max = "10";
    score.step = "0.1";
    score.placeholder = "—";
    score.value = applicationScore(app) ?? "";
    score.title = "Your manual score from 0 to 10";
    score.addEventListener("change", () => saveInlineScore(app, score));
    scoreTd.append(score);
    row.append(scoreTd);

    const statusTd = document.createElement("td");
    const select = element("select", `row-status ${app.status}`);
    for (const option of STATUS_OPTIONS) {
      const node = document.createElement("option");
      node.value = option.value;
      node.textContent = option.label;
      node.selected = option.value === app.status;
      select.append(node);
    }
    select.disabled = recordState(app) !== "active";
    select.addEventListener("change", () => saveInlineStatus(app, select));
    statusTd.append(select);
    row.append(statusTd);

    const actionsTd = document.createElement("td");
    const actions = element("div", "row-actions");
    const view = element("button", "view-button", "View/Edit");
    view.type = "button";
    view.addEventListener("click", () => openApplicationDialog(app.id));
    actions.append(view);
    if (recordState(app) === "active") {
      const archive = element("button", "view-button", "Archive");
      archive.type = "button";
      archive.addEventListener("click", () => archiveApplication(app.id));
      const remove = element("button", "row-delete-button", "×");
      remove.type = "button";
      remove.title = "Move to Recently Deleted";
      remove.setAttribute("aria-label", `Move ${app.company} ${app.jobTitle} to Recently Deleted`);
      remove.addEventListener("click", () => requestDelete(app.id));
      actions.append(archive, remove);
    } else if (recordState(app) === "archived") {
      const restore = element("button", "view-button", "Restore");
      restore.type = "button";
      restore.addEventListener("click", () => restoreArchivedApplication(app.id));
      const remove = element("button", "row-delete-button", "×");
      remove.type = "button";
      remove.title = "Move to Recently Deleted";
      remove.addEventListener("click", () => requestDelete(app.id));
      actions.append(restore, remove);
    } else {
      const restore = element("button", "view-button", "Restore");
      restore.type = "button";
      restore.addEventListener("click", () => restoreDeletedApplication(app.id));
      const permanent = element("button", "row-delete-button", "×");
      permanent.type = "button";
      permanent.title = "Delete permanently";
      permanent.addEventListener("click", () => permanentlyDeleteApplication(app.id));
      actions.append(restore, permanent);
    }
    actionsTd.append(actions);
    row.append(actionsTd);
    elements.body.append(row);
  }

  elements.empty.hidden = apps.length > 0;
  const folderCount = state.applications.filter((app) => recordState(app) === state.recordView).length;
  elements.emptyMessage.textContent = folderCount
    ? "No applications match the current filters."
    : state.recordView === "archived" ? "No archived applications yet."
      : state.recordView === "deleted" ? "Recently Deleted is empty."
        : "Open a job page, click the extension, upload your CV and save it.";
  elements.resultsCount.textContent = `${apps.length} application${apps.length === 1 ? "" : "s"}`;
  renderBulkActions();
}

async function markAllDocumentRequestsSent(app) {
  const now = new Date().toISOString();
  app.documentRequests = (app.documentRequests || []).map((request) => request.sentDate ? request : { ...request, sentDate: todayLocal() });
  app.status = "documents-sent";
  app.statusHistory = [...(app.statusHistory || []), { status: "documents-sent", changedAt: now }];
  app.updatedAt = now;
  await updateApplication(app);
  await refreshData();
  showToast("Document request marked as sent.");
}

function renderDocumentsRequested() {
  const waiting = activeApplications().filter((app) => (
    app.status === "documents-requested"
    || (app.documentRequests || []).some((request) => !request.sentDate)
  ));
  const panel = $("#documents-requested-panel");
  panel.classList.toggle("empty", waiting.length === 0);
  $("#documents-requested-title").textContent = waiting.length ? "Waiting for you to send" : "No document requests waiting";
  $("#documents-requested-copy").textContent = waiting.length
    ? "Applications where HR requested a transcript, certificate or another document."
    : "This panel expands when HR requests a document.";
  $("#documents-requested-count").textContent = `${waiting.length} job${waiting.length === 1 ? "" : "s"}`;
  const list = $("#documents-requested-list");
  list.replaceChildren();
  if (!waiting.length) {
    list.append(element("p", "empty-task", "No document requests are waiting."));
    return;
  }
  for (const app of waiting.slice(0, 8)) {
    const pending = (app.documentRequests || []).filter((request) => !request.sentDate);
    const row = element("div", "to-apply-row");
    const copy = element("div", "to-apply-copy");
    copy.append(
      element("strong", "", `${app.company || "Unknown company"} · ${app.jobTitle || "Untitled job"}`),
      element("span", "", pending.map((request) => request.documents).filter(Boolean).join(", ") || "HR documents requested")
    );
    const actions = element("div", "to-apply-actions");
    const open = element("button", "", "Open application");
    open.type = "button";
    open.addEventListener("click", () => openApplicationDialog(app.id));
    const sent = element("button", "primary", "Mark sent");
    sent.type = "button";
    sent.addEventListener("click", () => markAllDocumentRequestsSent(app));
    actions.append(open, sent);
    row.append(copy, actions);
    list.append(row);
  }
}

function backupReminderDays() {
  const value = Number(state.preferences.backupReminderDays);
  return [0, 7, 14, 30].includes(value) ? value : 14;
}

function renderBackupReminder() {
  const days = backupReminderDays();
  const reminder = $("#backup-reminder");
  $("#backup-reminder-days").value = String(days);
  if (!days) {
    reminder.hidden = true;
    return;
  }
  const last = state.preferences.lastBackupAt ? new Date(state.preferences.lastBackupAt) : null;
  const elapsed = last && !Number.isNaN(last.getTime())
    ? Math.floor((Date.now() - last.getTime()) / 86_400_000)
    : Number.POSITIVE_INFINITY;
  reminder.hidden = elapsed < days;
  $("#backup-reminder-title").textContent = last
    ? "It is time to create a private Backup ZIP."
    : "Create your first private Backup ZIP.";
  $("#backup-reminder-copy").textContent = last
    ? `Your last backup was ${elapsed} day${elapsed === 1 ? "" : "s"} ago.`
    : `No backup is recorded yet. The reminder repeats every ${days} days.`;
}

async function saveBackupReminderPreference() {
  state.preferences.backupReminderDays = Number($("#backup-reminder-days").value);
  await chrome.storage.local.set({ [PREFERENCES_KEY]: state.preferences });
  renderBackupReminder();
  showToast(state.preferences.backupReminderDays ? "Backup reminder updated." : "Backup reminder turned off.");
}

function renderAll() {
  renderSummary();
  renderDocumentsRequested();
  renderApplications();
  renderBackupReminder();
}

function setDialogValue(field, value = "") {
  field.value = value ?? "";
}

const FOLLOW_UP_CLOSED_STATUSES = new Set(["offer", "rejected", "withdrawn", "saved"]);

function followUpIsActive(status = fields.status.value) {
  return !FOLLOW_UP_CLOSED_STATUSES.has(status);
}

function renderAutomaticFields() {
  $("#reference-field").hidden = !fields.reference.value.trim();
  $("#deadline-field").hidden = !fields.deadline.value;
  const showFollowUp = Boolean(fields.followUp.value) || followUpIsActive();
  $("#follow-up-field").hidden = !showFollowUp;
  $("#follow-up-done-field").hidden = !showFollowUp;
}

function setSuggestedFollowUp() {
  if (state.followUpAuto && followUpIsActive()) {
    fields.followUp.value = addCalendarDays(fields.date.value || todayLocal(), 14);
  }
  renderAutomaticFields();
}

function renderHistory(history = []) {
  elements.history.replaceChildren();
  if (!history.length) {
    elements.history.append(element("li", "", "No status changes recorded yet."));
    return;
  }
  for (const entry of [...history].reverse()) {
    const item = document.createElement("li");
    item.append(`${statusLabel(entry.status)} `);
    const time = element("time", "", dateTimeLabel(entry.changedAt));
    item.append(time);
    elements.history.append(item);
  }
}

function renderImportedOutcomes(app = {}) {
  const section = $("#imported-outcomes-section");
  const list = $("#imported-outcomes-list");
  const meta = $("#imported-outcomes-meta");
  const events = Array.isArray(app.emailEvents) ? app.emailEvents : [];
  const metadata = [
    app.recruitingSystem ? `System: ${app.recruitingSystem}` : "",
    app.applicationSource ? `Source: ${app.applicationSource}` : "",
    app.senderDomain ? `Sender: ${app.senderDomain}` : ""
  ].filter(Boolean);
  section.hidden = !events.length && !metadata.length;
  list.replaceChildren();
  meta.replaceChildren(...metadata.map((item) => element("span", "", item)));
  for (const event of [...events].sort((a, b) => String(b.date).localeCompare(String(a.date)))) {
    const item = document.createElement("li");
    item.append(`${statusLabel(event.type)} `, element("time", "", formatDate(event.date)));
    const detail = [event.emailSubject, event.reasonStated ? `Reason: ${event.reasonStated}` : "", event.notes].filter(Boolean).join(" · ");
    if (detail) item.append(element("span", "outcome-detail", detail));
    list.append(item);
  }
}

function renderDocumentRequests() {
  const list = $("#document-request-list");
  list.replaceChildren();
  if (!state.editingDocumentRequests.length) {
    list.append(element("p", "tracker-empty", "No HR document requests saved."));
    return;
  }
  for (const request of state.editingDocumentRequests) {
    const row = element("div", "tracker-row");
    const copy = element("div", "tracker-copy");
    copy.append(
      element("strong", "", request.documents),
      element("span", "", `Requested ${request.requestedDate ? formatDate(request.requestedDate) : "date not set"}${request.deadline ? ` · Due ${formatDate(request.deadline)}` : ""}`),
      element("small", request.sentDate ? "tracker-sent" : "tracker-pending", request.sentDate ? `Sent ${formatDate(request.sentDate)}` : "Waiting to be sent")
    );
    const actions = element("div", "tracker-actions");
    if (!request.sentDate) {
      const sent = element("button", "file-action", "Mark sent");
      sent.type = "button";
      sent.addEventListener("click", () => {
        request.sentDate = todayLocal();
        if (state.editingDocumentRequests.every((item) => item.sentDate)) fields.status.value = "documents-sent";
        renderDocumentRequests();
      });
      actions.append(sent);
    }
    const remove = element("button", "file-action delete", "Remove");
    remove.type = "button";
    remove.addEventListener("click", () => {
      state.editingDocumentRequests = state.editingDocumentRequests.filter((item) => item.id !== request.id);
      renderDocumentRequests();
    });
    actions.append(remove);
    row.append(copy, actions);
    list.append(row);
  }
}

function addDocumentRequest() {
  const documents = fields.requestDocuments.value.trim();
  if (!documents) {
    fields.requestDocuments.focus();
    showToast("Write which documents HR requested.", { error: true });
    return;
  }
  state.editingDocumentRequests.push({
    id: createId("request"),
    documents,
    requestedDate: fields.requestDate.value || todayLocal(),
    deadline: fields.requestDeadline.value,
    sentDate: ""
  });
  fields.requestDocuments.value = "";
  fields.requestDate.value = todayLocal();
  fields.requestDeadline.value = "";
  fields.status.value = "documents-requested";
  renderDocumentRequests();
}

function messageFile(messageId) {
  return state.editingFiles.find((file) => file.kind === "hr-message" && file.messageId === messageId)
    || state.pendingHrMessageFiles.find((entry) => entry.messageId === messageId)?.file;
}

function renderHrMessages() {
  const list = $("#hr-message-list");
  list.replaceChildren();
  if (!state.editingHrMessages.length) {
    list.append(element("p", "tracker-empty", "No HR messages saved."));
    return;
  }
  for (const message of [...state.editingHrMessages].sort((a, b) => String(b.date).localeCompare(String(a.date)))) {
    const row = element("div", "tracker-row message-row");
    const copy = element("div", "tracker-copy");
    copy.append(
      element("strong", "", `${message.direction === "sent" ? "Sent" : "Received"} · ${message.subject || "No subject"}`),
      element("span", "", message.date ? formatDate(message.date) : "Date not set"),
      element("p", "", message.message || "No message text")
    );
    const actions = element("div", "tracker-actions");
    const attached = messageFile(message.id);
    if (attached) {
      const open = element("button", "file-action", "Open file");
      open.type = "button";
      open.addEventListener("click", () => {
        if (attached instanceof File) openStoredFile({ blob: attached, name: attached.name });
        else openStoredFile(attached);
      });
      actions.append(open);
    }
    const remove = element("button", "file-action delete", "Remove");
    remove.type = "button";
    remove.addEventListener("click", async () => {
      const stored = state.editingFiles.find((file) => file.kind === "hr-message" && file.messageId === message.id);
      if (stored) {
        await deleteFile(stored.id);
        state.editingFiles = state.editingFiles.filter((file) => file.id !== stored.id);
        state.files = state.files.filter((file) => file.id !== stored.id);
      }
      state.pendingHrMessageFiles = state.pendingHrMessageFiles.filter((entry) => entry.messageId !== message.id);
      state.editingHrMessages = state.editingHrMessages.filter((item) => item.id !== message.id);
      renderHrMessages();
    });
    actions.append(remove);
    row.append(copy, actions);
    list.append(row);
  }
}

function addHrMessage() {
  const messageText = fields.hrMessageText.value.trim();
  const subject = fields.hrMessageSubject.value.trim();
  if (!messageText && !subject) {
    fields.hrMessageText.focus();
    showToast("Paste the HR message or add its subject first.", { error: true });
    return;
  }
  const file = fields.hrMessageFile.files[0];
  try { if (file) validateOtherFile(file); }
  catch (error) { showToast(error.message, { error: true }); return; }
  const id = createId("message");
  state.editingHrMessages.push({
    id,
    direction: fields.hrMessageDirection.value === "sent" ? "sent" : "received",
    date: fields.hrMessageDate.value || todayLocal(),
    subject,
    message: messageText
  });
  if (file) {
    state.pendingHrMessageFiles.push({ kind: "hr-message", file, messageId: id });
  }
  fields.hrMessageDirection.value = "received";
  fields.hrMessageDate.value = todayLocal();
  fields.hrMessageSubject.value = "";
  fields.hrMessageText.value = "";
  fields.hrMessageFile.value = "";
  renderHrMessages();
}

function renderExistingFiles() {
  elements.existingFiles.replaceChildren();
  if (!state.editingFiles.length) {
    elements.existingFiles.append(element("div", "no-files", "No application documents stored yet."));
    return;
  }
  for (const file of state.editingFiles) {
    const row = element("div", "stored-file");
    const type = file.kind === "cv" ? "CV" : file.kind === "cover-letter" ? "LETTER" : "FILE";
    const info = element("div", "file-info");
    info.append(element("strong", "", file.name || "Document"), element("small", "", formatBytes(file.size)));
    const open = element("button", "file-action", "Open");
    open.type = "button";
    open.addEventListener("click", () => openStoredFile(file));
    const remove = element("button", "file-action delete", "Remove");
    remove.type = "button";
    remove.addEventListener("click", async () => {
      if (!confirm(`Remove ${file.name}?`)) return;
      await deleteFile(file.id);
      state.editingFiles = state.editingFiles.filter((item) => item.id !== file.id);
      state.files = state.files.filter((item) => item.id !== file.id);
      renderExistingFiles();
      renderApplications();
      showToast("Document removed.");
    });
    row.append(element("span", "file-type", type), info, open, remove);
    elements.existingFiles.append(row);
  }
}

function renderApplicationAnalysis(app = {}) {
  const hasAnalysis = Boolean(
    app.analysisUpdatedAt || app.decision || app.actualWork || app.strongestMatches
    || app.technicalGaps || app.languageRequirement || app.cvEffort
  );
  $("#application-analysis-empty").hidden = hasAnalysis;
  $("#application-analysis-details").hidden = !hasAnalysis;
  const score = applicationScore(app);
  $("#analysis-score").textContent = score === null ? "—" : `${score.toFixed(1)}/10`;
  $("#analysis-decision").textContent = app.decision || "No decision provided";
  $("#analysis-actual-work").textContent = app.actualWork || "—";
  $("#analysis-matches").textContent = app.strongestMatches || "—";
  $("#analysis-gaps").textContent = app.technicalGaps || "—";
  $("#analysis-seniority").textContent = app.seniorityGap || "—";
  $("#analysis-language").textContent = app.languageRequirement || "—";
  $("#analysis-degree").textContent = app.degreeRequirement || "—";
  $("#analysis-mandatory").textContent = app.mandatoryRequirements || "—";
  $("#analysis-cv-effort").textContent = app.cvEffort || "—";
}

function applicationAnalysis(app = {}) {
  return {
    decision: app.decision || "",
    actualWork: app.actualWork || "",
    strongestMatches: app.strongestMatches || "",
    technicalGaps: app.technicalGaps || "",
    seniorityGap: app.seniorityGap || "",
    languageRequirement: app.languageRequirement || "",
    degreeRequirement: app.degreeRequirement || "",
    mandatoryRequirements: app.mandatoryRequirements || "",
    cvEffort: app.cvEffort || "",
    analysisUpdatedAt: app.analysisUpdatedAt || ""
  };
}

async function openApplicationDialog(id = "") {
  elements.form.reset();
  elements.linkStatus.textContent = "";
  elements.linkStatus.className = "";
  fields.id.value = id;
  fields.date.value = todayLocal();
  fields.status.value = "applied";
  fields.followUp.value = addCalendarDays(fields.date.value, 14);
  state.followUpAuto = true;
  fields.employmentCategory.value = "full-time";
  fields.requestDate.value = todayLocal();
  fields.hrMessageDate.value = todayLocal();
  state.editingFiles = [];
  state.editingDocumentRequests = [];
  state.editingHrMessages = [];
  state.pendingHrMessageFiles = [];
  state.pendingAnalysis = null;
  let app = null;
  if (id) {
    app = await getApplication(id);
    if (!app) return;
    app = cleanApplication(app);
    state.editingFiles = await getFilesForApplication(id);
    $("#dialog-title").textContent = "View or edit application";
    $("#dialog-label").textContent = "SAVED APPLICATION";
    $("#delete-application").hidden = recordState(app) === "deleted";
    $("#return-to-finder").hidden = recordState(app) !== "active";
    $("#archive-application").hidden = recordState(app) === "deleted";
    $("#archive-application").textContent = recordState(app) === "archived" ? "Restore from Archive" : "Archive";
    $("#export-application-pdf").hidden = false;
    setDialogValue(fields.url, app.jobUrl);
    setDialogValue(fields.company, app.company);
    setDialogValue(fields.title, app.jobTitle);
    setDialogValue(fields.location, app.location);
    setDialogValue(fields.date, app.applicationDate);
    setDialogValue(fields.status, app.status);
    setDialogValue(fields.employmentCategory, employmentCategory(app));
    setDialogValue(fields.score, applicationScore(app));
    setDialogValue(fields.reference, app.referenceNumber);
    state.followUpAuto = !app.followUpDate;
    setDialogValue(fields.followUp, app.followUpDate || (followUpIsActive(app.status) ? addCalendarDays(app.applicationDate, 14) : ""));
    fields.followUpDone.checked = Boolean(app.followUpCompletedAt);
    setDialogValue(fields.deadline, app.applicationDeadline);
    setDialogValue(fields.interviewDate, app.interviewDateTime);
    setDialogValue(fields.recruiterName, app.recruiterName);
    setDialogValue(fields.recruiterEmail, app.recruiterEmail);
    setDialogValue(fields.recruiterPhone, app.recruiterPhone);
    setDialogValue(fields.recruiterLink, app.recruiterLinkedIn);
    setDialogValue(fields.interviewQuestions, app.interviewQuestions);
    setDialogValue(fields.interviewNotes, app.interviewNotes);
    setDialogValue(fields.description, app.jobDescription);
    setDialogValue(fields.notes, app.notes);
    state.editingDocumentRequests = structuredClone(app.documentRequests || []);
    state.editingHrMessages = structuredClone(app.hrMessages || []);
    state.pendingAnalysis = applicationAnalysis(app);
    renderHistory(app.statusHistory);
    renderImportedOutcomes(app);
    renderApplicationAnalysis(app);
  } else {
    $("#dialog-title").textContent = "Add application";
    $("#dialog-label").textContent = "NEW APPLICATION";
    $("#delete-application").hidden = true;
    $("#return-to-finder").hidden = true;
    $("#archive-application").hidden = true;
    $("#export-application-pdf").hidden = true;
    renderHistory([]);
    renderImportedOutcomes({});
    renderApplicationAnalysis({});
  }
  renderExistingFiles();
  renderDocumentRequests();
  renderHrMessages();
  renderAutomaticFields();
  elements.applicationDialog.showModal();
  if (!id) fields.company.focus();
}

function closeApplicationDialog() {
  elements.applicationDialog.close();
}

function fillCapturedData(data = {}) {
  const fill = (field, value) => { if (value) field.value = value; };
  fill(fields.company, data.company);
  fill(fields.title, data.jobTitle);
  fill(fields.location, data.location);
  fill(fields.url, data.jobUrl);
  fill(fields.reference, data.referenceNumber);
  fill(fields.deadline, data.applicationDeadline);
  fill(fields.description, data.jobDescription);
  fill(fields.recruiterName, data.recruiterName);
  fill(fields.recruiterEmail, data.recruiterEmail);
  fill(fields.recruiterPhone, data.recruiterPhone);
  fill(fields.recruiterLink, data.recruiterLinkedIn);
  fields.employmentCategory.value = employmentCategory({
    ...data,
    jobTitle: data.jobTitle || fields.title.value,
    jobDescription: data.jobDescription || fields.description.value
  });
  renderAutomaticFields();
}

async function fillFromLink() {
  const button = $("#fill-from-link");
  button.disabled = true;
  button.textContent = "Reading…";
  elements.linkStatus.textContent = "Chrome may ask permission for this job website once.";
  elements.linkStatus.className = "";
  try {
    const data = await readJobFromLink(fields.url.value, captureJobPage);
    fillCapturedData(data);
    elements.linkStatus.textContent = "Job details filled. Please check them before saving.";
  } catch (error) {
    elements.linkStatus.textContent = error.message || "This job page could not be read automatically.";
    elements.linkStatus.className = "error";
  } finally {
    button.disabled = false;
    button.textContent = "Fill automatically";
  }
}

async function copyText(value) {
  try {
    await navigator.clipboard.writeText(value);
  } catch {
    const textarea = document.createElement("textarea");
    textarea.value = value;
    document.body.append(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
  }
}

function analysisJobFromForm() {
  return {
    company: fields.company.value.trim(),
    jobTitle: fields.title.value.trim(),
    location: fields.location.value.trim(),
    jobUrl: normalizeUrl(fields.url.value),
    employmentCategory: fields.employmentCategory.value,
    jobDescription: fields.description.value.trim(),
    notes: fields.notes.value.trim()
  };
}

async function analyzeApplicationInChatGPT() {
  const stored = await chrome.storage.local.get(JOB_FINDER_SETTINGS_KEY);
  const analysisChatUrl = String(stored[JOB_FINDER_SETTINGS_KEY]?.analysisChatUrl || "").trim();
  if (!analysisChatUrl) {
    showToast("Set your Job analysis ChatGPT link in Job Finder first.", {
      actionLabel: "Open Job Finder",
      action: openJobFinder
    });
    return;
  }
  let url;
  try { url = new URL(analysisChatUrl); }
  catch { showToast("The saved job-analysis chat link is not valid.", { error: true }); return; }
  if (url.protocol !== "https:" || !["chatgpt.com", "chat.openai.com"].includes(url.hostname)) {
    showToast("For safety, the analysis link must be a ChatGPT link.", { error: true });
    return;
  }
  await copyText(buildAnalysisRequest(analysisJobFromForm()));
  showToast("Job-analysis request copied. Paste it into ChatGPT.");
  setTimeout(() => chrome.tabs.create({ url: url.href }), 450);
}

function openApplicationAnalysisImport() {
  elements.analysisText.value = "";
  elements.analysisStatus.textContent = "";
  elements.analysisStatus.className = "inline-status";
  elements.analysisDialog.showModal();
}

function applyAnalysisToForm(result) {
  const analysis = normalizeLead(result, { ...analysisJobFromForm(), ...(state.pendingAnalysis || {}) });
  state.pendingAnalysis = {
    decision: analysis.decision,
    actualWork: analysis.actualWork,
    strongestMatches: analysis.strongestMatches,
    technicalGaps: analysis.technicalGaps,
    seniorityGap: analysis.seniorityGap,
    languageRequirement: analysis.languageRequirement,
    degreeRequirement: analysis.degreeRequirement,
    mandatoryRequirements: analysis.mandatoryRequirements,
    cvEffort: analysis.cvEffort,
    analysisUpdatedAt: analysis.analysisUpdatedAt || new Date().toISOString()
  };
  if (analysis.manualScore !== null) fields.score.value = analysis.manualScore;
  if (analysis.recruiterName) fields.recruiterName.value = analysis.recruiterName;
  if (analysis.recruiterEmail) fields.recruiterEmail.value = analysis.recruiterEmail;
  if (analysis.recruiterPhone) fields.recruiterPhone.value = analysis.recruiterPhone;
  if (analysis.recruiterLinkedIn) fields.recruiterLink.value = analysis.recruiterLinkedIn;
  if (analysis.interviewQuestions) fields.interviewQuestions.value = analysis.interviewQuestions;
  renderApplicationAnalysis({ ...analysisJobFromForm(), ...state.pendingAnalysis, manualScore: analysis.manualScore });
}

function importApplicationAnalysis() {
  try {
    applyAnalysisToForm(parseStructuredResult(elements.analysisText.value));
    elements.analysisDialog.close();
    showToast("Analysis filled. Click Save changes to keep it.");
  } catch (error) {
    elements.analysisStatus.textContent = error.message || "The analysis could not be imported.";
    elements.analysisStatus.className = "inline-status error";
  }
}

function resolveDuplicate(action) {
  if (!state.duplicateResolver) return;
  const resolver = state.duplicateResolver;
  state.duplicateResolver = null;
  elements.duplicateDialog.close();
  resolver(action);
}

function askDuplicate(duplicate) {
  $("#duplicate-message").textContent = `${duplicate.company || "This company"} · ${duplicate.jobTitle || "This job"} is already in your dashboard.`;
  elements.duplicateDialog.showModal();
  return new Promise((resolve) => { state.duplicateResolver = resolve; });
}

function formApplication(existing = null) {
  const now = new Date().toISOString();
  const status = fields.status.value || "applied";
  const previousHistory = Array.isArray(existing?.statusHistory) ? existing.statusHistory : [];
  const statusHistory = previousHistory.length ? [...previousHistory] : [{ status, changedAt: existing?.createdAt || now }];
  if (existing && existing.status !== status) statusHistory.push({ status, changedAt: now });
  return cleanApplication({
    ...(existing || {}),
    ...(state.pendingAnalysis || {}),
    id: existing?.id || createId("app"),
    company: fields.company.value.trim(),
    jobTitle: fields.title.value.trim(),
    location: fields.location.value.trim(),
    jobUrl: normalizeUrl(fields.url.value),
    applicationDate: fields.date.value || todayLocal(),
    status,
    employmentCategory: fields.employmentCategory.value,
    manualScore: normalizeManualScore(fields.score.value),
    referenceNumber: fields.reference.value.trim(),
    followUpDate: fields.followUp.value,
    followUpCompletedAt: fields.followUpDone.checked ? (existing?.followUpCompletedAt || now) : "",
    applicationDeadline: fields.deadline.value,
    interviewDateTime: fields.interviewDate.value,
    recruiterName: fields.recruiterName.value.trim(),
    recruiterEmail: fields.recruiterEmail.value.trim(),
    recruiterPhone: fields.recruiterPhone.value.trim(),
    recruiterLinkedIn: normalizeUrl(fields.recruiterLink.value),
    interviewQuestions: fields.interviewQuestions.value.trim(),
    interviewNotes: fields.interviewNotes.value.trim(),
    jobDescription: fields.description.value.trim(),
    notes: fields.notes.value.trim(),
    documentRequests: structuredClone(state.editingDocumentRequests),
    hrMessages: structuredClone(state.editingHrMessages),
    statusHistory,
    createdAt: existing?.createdAt || now,
    updatedAt: now
  });
}

async function saveApplicationFromDialog(event) {
  event.preventDefault();
  if (!elements.form.reportValidity()) return;
  if (fields.score.value !== "" && (Number(fields.score.value) < 0 || Number(fields.score.value) > 10)) {
    fields.score.setCustomValidity("Enter a score from 0 to 10.");
    fields.score.reportValidity();
    return;
  }
  fields.score.setCustomValidity("");
  const save = $("#save-changes");
  save.disabled = true;
  save.textContent = "Saving…";
  try {
    const existing = fields.id.value ? await getApplication(fields.id.value) : null;
    const app = formApplication(existing);
    if (!existing) {
      const duplicate = findLikelyDuplicate(state.applications, app);
      if (duplicate) {
        const decision = await askDuplicate(duplicate);
        if (decision === "open") {
          closeApplicationDialog();
          await openApplicationDialog(duplicate.id);
          return;
        }
        if (decision !== "save") return;
      }
    }

    const cv = fields.cv.files[0];
    const letter = fields.letter.files[0];
    validatePdfFile(cv, "CV");
    validatePdfFile(letter, "Cover letter");
    for (const file of fields.others.files) validateOtherFile(file);

    if (existing) await updateApplication(app);
    else await createApplication(app);

    if (cv) {
      await deleteFilesByKind(app.id, "cv");
      await addFiles(app.id, [{ kind: "cv", file: cv }]);
    }
    if (letter) {
      await deleteFilesByKind(app.id, "cover-letter");
      await addFiles(app.id, [{ kind: "cover-letter", file: letter }]);
    }
    if (fields.others.files.length) {
      await addFiles(app.id, [...fields.others.files].map((file) => ({ kind: "other", file })));
    }
    if (state.pendingHrMessageFiles.length) await addFiles(app.id, state.pendingHrMessageFiles);

    await refreshData();
    closeApplicationDialog();
    showToast(existing ? "Application updated." : "Application saved.");
    refreshBadge();
  } catch (error) {
    console.error(error);
    showToast(error.message || "The application could not be saved.", { error: true });
  } finally {
    save.disabled = false;
    save.textContent = "Save changes";
  }
}

function resolveDelete(confirmed) {
  if (!state.deleteResolver) return;
  const resolver = state.deleteResolver;
  state.deleteResolver = null;
  elements.deleteDialog.close();
  resolver(confirmed);
}

async function askDelete(app) {
  $("#delete-message").textContent = `${app.company || "This company"} · ${app.jobTitle || "This job"} and its stored documents can be restored for 30 days.`;
  elements.deleteDialog.showModal();
  return new Promise((resolve) => { state.deleteResolver = resolve; });
}

async function requestDelete(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app || !await askDelete(app)) return;
  const now = new Date().toISOString();
  app.deletedAt = now;
  app.returnedToFinderAt = "";
  app.updatedAt = now;
  await updateApplication(app);
  state.selectedIds.delete(id);
  if (elements.applicationDialog.open) closeApplicationDialog();
  await refreshData();
  refreshBadge();
  showToast("Moved to Recently Deleted.", {
    actionLabel: "Restore",
    action: () => restoreDeletedApplication(id)
  });
}

async function archiveApplication(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app) return;
  app.archivedAt = new Date().toISOString();
  app.deletedAt = "";
  app.updatedAt = app.archivedAt;
  await updateApplication(app);
  state.selectedIds.delete(id);
  if (elements.applicationDialog.open) closeApplicationDialog();
  await refreshData();
  showToast("Application moved to Archive.");
}

async function restoreArchivedApplication(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app) return;
  app.archivedAt = "";
  app.updatedAt = new Date().toISOString();
  await updateApplication(app);
  state.selectedIds.delete(id);
  if (elements.applicationDialog.open) closeApplicationDialog();
  await refreshData();
  showToast("Application restored from Archive.");
}

async function restoreDeletedApplication(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app) return;
  app.deletedAt = "";
  if (!app.archivedAt && app.status === "saved") {
    app.status = "applied";
    app.applicationDate ||= todayLocal();
    app.statusHistory = [...(app.statusHistory || []), { status: "applied", changedAt: new Date().toISOString() }];
  }
  app.updatedAt = new Date().toISOString();
  await updateApplication(app);
  state.selectedIds.delete(id);
  await refreshData();
  showToast(app.archivedAt ? "Restored to Archive." : "Application restored.");
}

async function permanentlyDeleteApplication(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app || !confirm(`Delete ${app.company} · ${app.jobTitle} permanently? This cannot be undone.`)) return;
  await removeApplication(id);
  state.selectedIds.delete(id);
  await refreshData();
  showToast("Application and its documents were permanently deleted.");
}

async function returnApplicationToFinder(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app || !confirm(`Return ${app.company} · ${app.jobTitle} to Job Finder? Its documents will stay stored.`)) return;
  const now = new Date().toISOString();
  const lead = applicationToLead(app);
  await putJobLead(lead);
  await updateApplication({
    ...app,
    returnedToFinderAt: now,
    archivedAt: "",
    deletedAt: "",
    applicationDate: "",
    status: "saved",
    statusHistory: [...(app.statusHistory || []), { status: "saved", changedAt: now }],
    updatedAt: now
  });
  closeApplicationDialog();
  await refreshData();
  showToast("Job returned to Job Finder with its documents kept safely.", { actionLabel: "Open Job Finder", action: openJobFinder });
}

async function exportApplicationReport(id) {
  const app = state.applications.find((item) => item.id === id);
  if (!app) return;
  const report = buildApplicationPdf(app, filesFor(id));
  const name = safeFileName(`${app.company}_${app.jobTitle}_Application_Report`, "Application_Report");
  downloadBlob(report, `${name}.pdf`);
  showToast("Application PDF report created.");
}

async function bulkArchive() {
  const now = new Date().toISOString();
  const restoring = state.recordView === "archived";
  const selected = state.applications.filter((app) => state.selectedIds.has(app.id) && recordState(app) === (restoring ? "archived" : "active"));
  for (const app of selected) await updateApplication({ ...app, archivedAt: restoring ? "" : now, updatedAt: now });
  state.selectedIds.clear();
  await refreshData();
  showToast(`${selected.length} application${selected.length === 1 ? "" : "s"} ${restoring ? "restored" : "archived"}.`);
}

async function bulkMoveToDeleted() {
  if (!state.selectedIds.size || !confirm(`Move ${state.selectedIds.size} selected application${state.selectedIds.size === 1 ? "" : "s"} to Recently Deleted?`)) return;
  const now = new Date().toISOString();
  const selected = state.applications.filter((app) => state.selectedIds.has(app.id));
  for (const app of selected) await updateApplication({ ...app, returnedToFinderAt: "", deletedAt: now, updatedAt: now });
  state.selectedIds.clear();
  await refreshData();
  showToast(`${selected.length} application${selected.length === 1 ? "" : "s"} moved to Recently Deleted.`);
}

async function bulkChangeStatus() {
  const status = $("#bulk-status").value;
  if (!status) { showToast("Choose a status first.", { error: true }); return; }
  const now = new Date().toISOString();
  const selected = state.applications.filter((app) => state.selectedIds.has(app.id) && recordState(app) === "active");
  for (const app of selected) {
    if (app.status === status) continue;
    await updateApplication({ ...app, status, statusHistory: [...(app.statusHistory || []), { status, changedAt: now }], updatedAt: now });
  }
  state.selectedIds.clear();
  $("#bulk-status").value = "";
  await refreshData();
  showToast(`Status updated for ${selected.length} application${selected.length === 1 ? "" : "s"}.`);
}

async function bulkExport() {
  const selected = state.applications.filter((app) => state.selectedIds.has(app.id));
  if (!selected.length) return;
  const ids = new Set(selected.map((app) => app.id));
  const workbook = await buildApplicationsXlsx(selected, state.files.filter((file) => ids.has(file.appId)));
  downloadBlob(workbook, `My_Job_Manager_Selected_${todayLocal()}.xlsx`);
  showToast("Selected applications exported to Excel.");
}

async function refreshData() {
  const [applications, files, jobLeads] = await Promise.all([listApplications(), getAllFiles(), listJobLeads()]);
  state.applications = await migrateApplications(applications);
  state.files = files;
  state.jobLeads = jobLeads.map((lead) => normalizeLead({}, lead));
  renderAll();
}

function scheduleNotesSave() {
  clearTimeout(state.notesTimer);
  elements.notesStatus.textContent = "Saving…";
  elements.notesStatus.className = "notes-save-status saving";
  state.notesTimer = setTimeout(saveNotes, 400);
}

async function saveNotes() {
  clearTimeout(state.notesTimer);
  state.globalNotes = elements.notes.value;
  try {
    await chrome.storage.local.set({ [GLOBAL_NOTES_KEY]: state.globalNotes });
    elements.notesStatus.textContent = "Saved locally";
    elements.notesStatus.className = "notes-save-status";
  } catch {
    elements.notesStatus.textContent = "Could not save";
    elements.notesStatus.className = "notes-save-status error";
  }
}

async function exportExcel() {
  const button = $("#export-excel");
  button.disabled = true;
  button.textContent = "Preparing…";
  try {
    const workbook = await buildApplicationsXlsx(state.applications, state.files);
    downloadBlob(workbook, `My_Job_Manager_${todayLocal()}.xlsx`);
    showToast("Excel export created.");
  } catch (error) {
    showToast(error.message || "Excel export failed.", { error: true });
  } finally {
    button.disabled = false;
    button.textContent = "Export Excel";
  }
}

async function exportBackup() {
  const button = $("#backup-data");
  button.disabled = true;
  button.textContent = "Preparing…";
  try {
    const [jobLeads, settings] = await Promise.all([
      listJobLeads(),
      chrome.storage.local.get([JOB_FINDER_SETTINGS_KEY, COMPANY_PROFILES_KEY])
    ]);
    const backup = await buildBackupZip(state.applications, state.files, {
      globalNotes: state.globalNotes,
      jobFinder: settings[JOB_FINDER_SETTINGS_KEY] || {},
      preferences: state.preferences,
      companyProfiles: settings[COMPANY_PROFILES_KEY] || {}
    }, jobLeads);
    downloadBlob(backup, `My_Job_Manager_Backup_${todayLocal()}.zip`);
    state.preferences.lastBackupAt = new Date().toISOString();
    await chrome.storage.local.set({ [PREFERENCES_KEY]: state.preferences });
    renderBackupReminder();
    showToast("Complete Backup ZIP created, including application documents.");
  } catch (error) {
    showToast(error.message || "Backup could not be created.", { error: true });
  } finally {
    button.disabled = false;
    button.textContent = "Backup ZIP";
  }
}

async function importBackupData(reader) {
  elements.restoreStatus.textContent = "Reading and checking the backup…";
  elements.restoreStatus.className = "inline-status";
  try {
    const backup = await reader();
    const applications = backup.applications.map(cleanApplication);
    await mergeBackup(applications, backup.files, backup.jobLeads || []);
    const settings = {};
    if (Object.hasOwn(backup.settings || {}, "globalNotes")) {
      state.globalNotes = String(backup.settings.globalNotes || "");
      elements.notes.value = state.globalNotes;
      settings[GLOBAL_NOTES_KEY] = state.globalNotes;
    }
    if (backup.settings?.jobFinder && typeof backup.settings.jobFinder === "object") {
      settings[JOB_FINDER_SETTINGS_KEY] = backup.settings.jobFinder;
    }
    if (backup.settings?.preferences && typeof backup.settings.preferences === "object") {
      state.preferences = { ...state.preferences, ...backup.settings.preferences };
      settings[PREFERENCES_KEY] = state.preferences;
    }
    if (backup.settings?.companyProfiles && typeof backup.settings.companyProfiles === "object") {
      settings[COMPANY_PROFILES_KEY] = backup.settings.companyProfiles;
    }
    if (Object.keys(settings).length) await chrome.storage.local.set(settings);
    await refreshData();
    const skipped = backup.skippedBackgroundDocuments || 0;
    elements.restoreStatus.textContent = `Imported ${applications.length} applications and ${backup.files.length} application documents.${skipped ? ` ${skipped} old background document${skipped === 1 ? " was" : "s were"} intentionally skipped for privacy.` : ""}`;
    elements.restoreStatus.className = "inline-status success";
    showToast("Backup imported successfully.");
    refreshBadge();
  } catch (error) {
    console.error(error);
    elements.restoreStatus.textContent = error.message || "The backup could not be imported.";
    elements.restoreStatus.className = "inline-status error";
    showToast("Backup import failed. The message in the import window explains why.", { error: true });
  }
}

function openJobFinder() {
  location.href = chrome.runtime.getURL("job-finder.html");
}

function openInsights() {
  location.href = chrome.runtime.getURL("insights.html");
}

function openAbout() {
  chrome.tabs.create({ url: chrome.runtime.getURL("about.html") });
}

function openGuide() {
  chrome.tabs.create({ url: chrome.runtime.getURL("guide.html") });
}

document.querySelectorAll("[data-summary-status]").forEach((button) => {
  button.addEventListener("click", () => {
    state.summaryStatus = button.dataset.summaryStatus;
    state.recordView = "active";
    state.selectedIds.clear();
    document.querySelectorAll("[data-summary-status]").forEach((item) => item.classList.toggle("active", item === button));
    document.querySelectorAll("[data-record-view]").forEach((item) => {
      const active = item.dataset.recordView === "active";
      item.classList.toggle("active", active);
      item.setAttribute("aria-selected", String(active));
    });
    renderAll();
  });
});
document.querySelectorAll("[data-application-category]").forEach((button) => {
  button.addEventListener("click", () => {
    state.applicationCategory = button.dataset.applicationCategory;
    state.selectedIds.clear();
    document.querySelectorAll("[data-application-category]").forEach((item) => {
      const active = item === button;
      item.classList.toggle("active", active);
      item.setAttribute("aria-selected", String(active));
    });
    renderApplications();
  });
});
document.querySelectorAll("[data-record-view]").forEach((button) => {
  button.addEventListener("click", () => {
    state.recordView = button.dataset.recordView;
    state.summaryStatus = "all";
    state.selectedIds.clear();
    document.querySelectorAll("[data-record-view]").forEach((item) => {
      const active = item === button;
      item.classList.toggle("active", active);
      item.setAttribute("aria-selected", String(active));
    });
    document.querySelectorAll("[data-summary-status]").forEach((item) => item.classList.toggle("active", item.dataset.summaryStatus === "all"));
    renderAll();
  });
});
for (const node of [elements.search, elements.statusFilter, elements.scoreFilter, elements.sortOrder]) {
  node.addEventListener("input", () => { state.selectedIds.clear(); renderApplications(); });
}
elements.notes.addEventListener("input", scheduleNotesSave);
elements.notes.addEventListener("change", saveNotes);
$("#add-application").addEventListener("click", () => openApplicationDialog());
$("#empty-add").addEventListener("click", () => openApplicationDialog());
$("#close-dialog").addEventListener("click", closeApplicationDialog);
$("#cancel-dialog").addEventListener("click", closeApplicationDialog);
$("#fill-from-link").addEventListener("click", fillFromLink);
$("#analyze-application").addEventListener("click", analyzeApplicationInChatGPT);
$("#paste-application-analysis").addEventListener("click", openApplicationAnalysisImport);
$("#cancel-application-analysis").addEventListener("click", () => elements.analysisDialog.close());
$("#save-application-analysis").addEventListener("click", importApplicationAnalysis);
elements.form.addEventListener("submit", saveApplicationFromDialog);
$("#delete-application").addEventListener("click", () => requestDelete(fields.id.value));
$("#return-to-finder").addEventListener("click", () => returnApplicationToFinder(fields.id.value));
$("#archive-application").addEventListener("click", () => {
  const app = state.applications.find((item) => item.id === fields.id.value);
  if (app && recordState(app) === "archived") restoreArchivedApplication(app.id);
  else if (app) archiveApplication(app.id);
});
$("#export-application-pdf").addEventListener("click", () => exportApplicationReport(fields.id.value));
$("#add-document-request").addEventListener("click", addDocumentRequest);
$("#add-hr-message").addEventListener("click", addHrMessage);
$("#duplicate-cancel").addEventListener("click", () => resolveDuplicate("cancel"));
$("#duplicate-open").addEventListener("click", () => resolveDuplicate("open"));
$("#duplicate-save").addEventListener("click", () => resolveDuplicate("save"));
$("#delete-cancel").addEventListener("click", () => resolveDelete(false));
$("#delete-confirm").addEventListener("click", () => resolveDelete(true));
$("#export-excel").addEventListener("click", exportExcel);
$("#backup-data").addEventListener("click", exportBackup);
$("#backup-now").addEventListener("click", exportBackup);
$("#backup-reminder-days").addEventListener("change", saveBackupReminderPreference);
$("#restore-data").addEventListener("click", () => {
  elements.restoreStatus.textContent = "";
  elements.restoreDialog.showModal();
});
$("#choose-backup-zip").addEventListener("click", () => $("#restore-file").click());
$("#choose-backup-folder").addEventListener("click", () => $("#restore-folder").click());
$("#close-restore").addEventListener("click", () => elements.restoreDialog.close());
$("#restore-file").addEventListener("change", (event) => {
  const file = event.target.files[0];
  if (file) importBackupData(() => readBackupZip(file));
  event.target.value = "";
});
$("#restore-folder").addEventListener("change", (event) => {
  const files = [...event.target.files];
  if (files.length) importBackupData(() => readBackupFolder(files));
  event.target.value = "";
});
$("#open-job-finder").addEventListener("click", openJobFinder);
$("#open-insights").addEventListener("click", openInsights);
for (const selector of ["#about-app", "#footer-about-app"]) $(selector).addEventListener("click", openAbout);
$("#open-guide").addEventListener("click", openGuide);
fields.date.addEventListener("change", setSuggestedFollowUp);
fields.status.addEventListener("change", () => {
  if (!followUpIsActive() && state.followUpAuto) {
    fields.followUp.value = "";
    fields.followUpDone.checked = false;
    renderAutomaticFields();
  } else if (followUpIsActive() && !fields.followUp.value) {
    state.followUpAuto = true;
    setSuggestedFollowUp();
  } else {
    renderAutomaticFields();
  }
});
fields.followUp.addEventListener("input", () => {
  state.followUpAuto = false;
  renderAutomaticFields();
});
$("#select-all-visible").addEventListener("change", (event) => {
  for (const app of visibleApplications()) {
    if (event.target.checked) state.selectedIds.add(app.id);
    else state.selectedIds.delete(app.id);
  }
  renderApplications();
});
$("#bulk-archive").addEventListener("click", bulkArchive);
$("#bulk-export").addEventListener("click", bulkExport);
$("#bulk-apply-status").addEventListener("click", bulkChangeStatus);
$("#bulk-delete").addEventListener("click", bulkMoveToDeleted);
$("#bulk-clear").addEventListener("click", () => { state.selectedIds.clear(); renderApplications(); });

const header = document.querySelector(".app-header");
function updateCompactHeader() {
  header.classList.toggle("compact", window.scrollY > 70);
}
window.addEventListener("scroll", updateCompactHeader, { passive: true });
updateCompactHeader();

elements.applicationDialog.addEventListener("cancel", (event) => { event.preventDefault(); closeApplicationDialog(); });
elements.duplicateDialog.addEventListener("cancel", (event) => { event.preventDefault(); resolveDuplicate("cancel"); });
elements.deleteDialog.addEventListener("cancel", (event) => { event.preventDefault(); resolveDelete(false); });
elements.restoreDialog.addEventListener("cancel", (event) => { event.preventDefault(); elements.restoreDialog.close(); });
elements.analysisDialog.addEventListener("cancel", (event) => { event.preventDefault(); elements.analysisDialog.close(); });

async function initialize() {
  try {
    await loadState();
    renderAll();
    refreshBadge();
    const params = new URLSearchParams(location.search);
    const editId = params.get("edit");
    const newJobUrl = params.get("newJobUrl");
    if (editId) await openApplicationDialog(editId);
    else if (newJobUrl) {
      await openApplicationDialog();
      fields.url.value = newJobUrl;
      elements.linkStatus.textContent = "Your link is ready. Click Fill automatically, then allow this website if Chrome asks.";
    }
  } catch (error) {
    console.error(error);
    showToast(error.message || "My Job Manager could not load.", { error: true });
  }
}

initialize();
