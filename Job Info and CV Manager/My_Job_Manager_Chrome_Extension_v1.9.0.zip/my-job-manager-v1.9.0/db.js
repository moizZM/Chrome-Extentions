import { createId } from "./common.js";

const DATABASE_NAME = "moiz-job-application-manager";
const DATABASE_VERSION = 3;
const APPLICATIONS_STORE = "applications";
const FILES_STORE = "files";
const JOB_LEADS_STORE = "jobLeads";
const LEGACY_PROFILE_DOCUMENTS_STORE = "profileDocuments";

let databasePromise;

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.addEventListener("success", () => resolve(request.result), { once: true });
    request.addEventListener("error", () => reject(request.error), { once: true });
  });
}

function transactionComplete(transaction) {
  return new Promise((resolve, reject) => {
    transaction.addEventListener("complete", () => resolve(), { once: true });
    transaction.addEventListener("abort", () => reject(transaction.error || new Error("Database transaction stopped.")), { once: true });
    transaction.addEventListener("error", () => reject(transaction.error || new Error("Database transaction failed.")), { once: true });
  });
}

export function openDatabase() {
  if (databasePromise) return databasePromise;

  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);

    request.addEventListener("upgradeneeded", () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(APPLICATIONS_STORE)) {
        const store = database.createObjectStore(APPLICATIONS_STORE, { keyPath: "id" });
        store.createIndex("applicationDate", "applicationDate", { unique: false });
        store.createIndex("status", "status", { unique: false });
      }
      if (!database.objectStoreNames.contains(FILES_STORE)) {
        const store = database.createObjectStore(FILES_STORE, { keyPath: "id" });
        store.createIndex("appId", "appId", { unique: false });
        store.createIndex("appIdKind", ["appId", "kind"], { unique: false });
      }
      if (database.objectStoreNames.contains(LEGACY_PROFILE_DOCUMENTS_STORE)) {
        database.deleteObjectStore(LEGACY_PROFILE_DOCUMENTS_STORE);
      }
      if (!database.objectStoreNames.contains(JOB_LEADS_STORE)) {
        const store = database.createObjectStore(JOB_LEADS_STORE, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt", { unique: false });
        store.createIndex("source", "source", { unique: false });
      }
    });

    request.addEventListener("success", () => resolve(request.result), { once: true });
    request.addEventListener("error", () => reject(request.error), { once: true });
  });

  return databasePromise;
}

function fileRecord(appId, kind, file, metadata = {}) {
  return {
    id: createId("file"),
    appId,
    kind,
    name: file.name || `${kind}.pdf`,
    mimeType: file.type || "application/octet-stream",
    size: file.size || 0,
    createdAt: new Date().toISOString(),
    messageId: String(metadata.messageId || ""),
    blob: file instanceof Blob ? file : new Blob([file])
  };
}

export async function createApplication(application, attachments = []) {
  const database = await openDatabase();
  const transaction = database.transaction([APPLICATIONS_STORE, FILES_STORE], "readwrite");
  const applications = transaction.objectStore(APPLICATIONS_STORE);
  const files = transaction.objectStore(FILES_STORE);

  applications.add(application);
  for (const attachment of attachments) {
    if (!attachment?.file) continue;
    files.add(fileRecord(application.id, attachment.kind || "other", attachment.file, attachment));
  }

  await transactionComplete(transaction);
  return application;
}

export async function listApplications() {
  const database = await openDatabase();
  const transaction = database.transaction(APPLICATIONS_STORE, "readonly");
  const request = transaction.objectStore(APPLICATIONS_STORE).getAll();
  const result = await requestResult(request);
  await transactionComplete(transaction);
  return result;
}

export async function getApplication(id) {
  const database = await openDatabase();
  const transaction = database.transaction(APPLICATIONS_STORE, "readonly");
  const request = transaction.objectStore(APPLICATIONS_STORE).get(id);
  const result = await requestResult(request);
  await transactionComplete(transaction);
  return result;
}

export async function updateApplication(application) {
  const database = await openDatabase();
  const transaction = database.transaction(APPLICATIONS_STORE, "readwrite");
  transaction.objectStore(APPLICATIONS_STORE).put(application);
  await transactionComplete(transaction);
  return application;
}

export async function addFiles(appId, attachments = []) {
  if (!attachments.some((attachment) => attachment?.file)) return [];
  const database = await openDatabase();
  const transaction = database.transaction(FILES_STORE, "readwrite");
  const store = transaction.objectStore(FILES_STORE);
  const records = [];

  for (const attachment of attachments) {
    if (!attachment?.file) continue;
    const record = fileRecord(appId, attachment.kind || "other", attachment.file, attachment);
    records.push(record);
    store.add(record);
  }

  await transactionComplete(transaction);
  return records;
}

export async function getFilesForApplication(appId) {
  const database = await openDatabase();
  const transaction = database.transaction(FILES_STORE, "readonly");
  const request = transaction.objectStore(FILES_STORE).index("appId").getAll(appId);
  const result = await requestResult(request);
  await transactionComplete(transaction);
  return result;
}

export async function getAllFiles() {
  const database = await openDatabase();
  const transaction = database.transaction(FILES_STORE, "readonly");
  const request = transaction.objectStore(FILES_STORE).getAll();
  const result = await requestResult(request);
  await transactionComplete(transaction);
  return result;
}

export async function deleteFile(id) {
  const database = await openDatabase();
  const transaction = database.transaction(FILES_STORE, "readwrite");
  transaction.objectStore(FILES_STORE).delete(id);
  await transactionComplete(transaction);
}

export async function deleteFilesByKind(appId, kind) {
  const files = await getFilesForApplication(appId);
  const matching = files.filter((file) => file.kind === kind);
  if (!matching.length) return;

  const database = await openDatabase();
  const transaction = database.transaction(FILES_STORE, "readwrite");
  const store = transaction.objectStore(FILES_STORE);
  for (const file of matching) store.delete(file.id);
  await transactionComplete(transaction);
}

export async function deleteApplication(id) {
  const files = await getFilesForApplication(id);
  const database = await openDatabase();
  const transaction = database.transaction([APPLICATIONS_STORE, FILES_STORE], "readwrite");
  transaction.objectStore(APPLICATIONS_STORE).delete(id);
  const fileStore = transaction.objectStore(FILES_STORE);
  for (const file of files) fileStore.delete(file.id);
  await transactionComplete(transaction);
}

export async function listJobLeads() {
  const database = await openDatabase();
  const transaction = database.transaction(JOB_LEADS_STORE, "readonly");
  const request = transaction.objectStore(JOB_LEADS_STORE).getAll();
  const result = await requestResult(request);
  await transactionComplete(transaction);
  return result;
}

export async function putJobLead(lead) {
  const database = await openDatabase();
  const transaction = database.transaction(JOB_LEADS_STORE, "readwrite");
  transaction.objectStore(JOB_LEADS_STORE).put(lead);
  await transactionComplete(transaction);
  return lead;
}

export async function putJobLeads(leads = []) {
  if (!leads.length) return [];
  const database = await openDatabase();
  const transaction = database.transaction(JOB_LEADS_STORE, "readwrite");
  const store = transaction.objectStore(JOB_LEADS_STORE);
  for (const lead of leads) store.put(lead);
  await transactionComplete(transaction);
  return leads;
}

export async function deleteJobLead(id) {
  const database = await openDatabase();
  const transaction = database.transaction(JOB_LEADS_STORE, "readwrite");
  transaction.objectStore(JOB_LEADS_STORE).delete(id);
  await transactionComplete(transaction);
}

export async function mergeBackup(applications = [], files = [], jobLeads = []) {
  const database = await openDatabase();
  const transaction = database.transaction([APPLICATIONS_STORE, FILES_STORE, JOB_LEADS_STORE], "readwrite");
  const applicationStore = transaction.objectStore(APPLICATIONS_STORE);
  const fileStore = transaction.objectStore(FILES_STORE);
  const leadStore = transaction.objectStore(JOB_LEADS_STORE);

  for (const application of applications) applicationStore.put(application);
  for (const file of files) fileStore.put(file);
  for (const lead of jobLeads) leadStore.put(lead);
  await transactionComplete(transaction);
}
