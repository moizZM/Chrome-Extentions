import { applicationScore, employmentCategoryLabel, formatDate, recordState, safeFileName, statusLabel } from "./common.js";

const encoder = new TextEncoder();
const decoder = new TextDecoder();

function makeCrcTable() {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
    }
    table[index] = value >>> 0;
  }
  return table;
}

const CRC_TABLE = makeCrcTable();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

async function bytesFrom(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (value instanceof Blob) return new Uint8Array(await value.arrayBuffer());
  return encoder.encode(String(value ?? ""));
}

function dosDateTime(date = new Date()) {
  const year = Math.max(1980, date.getFullYear());
  return {
    time: ((date.getHours() & 31) << 11) | ((date.getMinutes() & 63) << 5) | ((Math.floor(date.getSeconds() / 2)) & 31),
    date: (((year - 1980) & 127) << 9) | (((date.getMonth() + 1) & 15) << 5) | (date.getDate() & 31)
  };
}

function setUint16(view, offset, value) {
  view.setUint16(offset, value, true);
}

function setUint32(view, offset, value) {
  view.setUint32(offset, value >>> 0, true);
}

export async function createStoredZip(entries, mimeType = "application/zip") {
  const files = [];
  for (const entry of entries) {
    files.push({
      name: String(entry.name).replace(/^\/+/, ""),
      bytes: await bytesFrom(entry.data),
      date: entry.date || new Date()
    });
  }

  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const checksum = crc32(file.bytes);
    const stamp = dosDateTime(file.date);
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    setUint32(localView, 0, 0x04034b50);
    setUint16(localView, 4, 20);
    setUint16(localView, 6, 0x0800);
    setUint16(localView, 8, 0);
    setUint16(localView, 10, stamp.time);
    setUint16(localView, 12, stamp.date);
    setUint32(localView, 14, checksum);
    setUint32(localView, 18, file.bytes.length);
    setUint32(localView, 22, file.bytes.length);
    setUint16(localView, 26, nameBytes.length);
    setUint16(localView, 28, 0);
    localHeader.set(nameBytes, 30);
    localParts.push(localHeader, file.bytes);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    setUint32(centralView, 0, 0x02014b50);
    setUint16(centralView, 4, 20);
    setUint16(centralView, 6, 20);
    setUint16(centralView, 8, 0x0800);
    setUint16(centralView, 10, 0);
    setUint16(centralView, 12, stamp.time);
    setUint16(centralView, 14, stamp.date);
    setUint32(centralView, 16, checksum);
    setUint32(centralView, 20, file.bytes.length);
    setUint32(centralView, 24, file.bytes.length);
    setUint16(centralView, 28, nameBytes.length);
    setUint16(centralView, 30, 0);
    setUint16(centralView, 32, 0);
    setUint16(centralView, 34, 0);
    setUint16(centralView, 36, 0);
    setUint32(centralView, 38, 0);
    setUint32(centralView, 42, offset);
    centralHeader.set(nameBytes, 46);
    centralParts.push(centralHeader);

    offset += localHeader.length + file.bytes.length;
  }

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const end = new Uint8Array(22);
  const endView = new DataView(end.buffer);
  setUint32(endView, 0, 0x06054b50);
  setUint16(endView, 4, 0);
  setUint16(endView, 6, 0);
  setUint16(endView, 8, files.length);
  setUint16(endView, 10, files.length);
  setUint32(endView, 12, centralSize);
  setUint32(endView, 16, offset);
  setUint16(endView, 20, 0);

  return new Blob([...localParts, ...centralParts, end], { type: mimeType });
}

export function parseStoredZip(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const entries = new Map();
  let offset = 0;

  while (offset + 4 <= bytes.length && view.getUint32(offset, true) === 0x04034b50) {
    if (offset + 30 > bytes.length) throw new Error("Backup ZIP is incomplete.");
    const flags = view.getUint16(offset + 6, true);
    const method = view.getUint16(offset + 8, true);
    const compressedSize = view.getUint32(offset + 18, true);
    const nameLength = view.getUint16(offset + 26, true);
    const extraLength = view.getUint16(offset + 28, true);
    if (flags & 0x0008) throw new Error("This backup uses an unsupported ZIP data format.");
    if (method !== 0) throw new Error("This is not a Job Manager backup ZIP.");

    const nameStart = offset + 30;
    const dataStart = nameStart + nameLength + extraLength;
    const dataEnd = dataStart + compressedSize;
    if (dataEnd > bytes.length) throw new Error("Backup ZIP is incomplete.");
    const name = decoder.decode(bytes.slice(nameStart, nameStart + nameLength));
    entries.set(name, bytes.slice(dataStart, dataEnd));
    offset = dataEnd;
  }

  return entries;
}

function cleanXml(value) {
  return String(value ?? "")
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function columnName(index) {
  let number = index + 1;
  let name = "";
  while (number > 0) {
    const remainder = (number - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    number = Math.floor((number - 1) / 26);
  }
  return name;
}

function inlineCell(reference, value, style = 0) {
  const styleAttribute = style ? ` s="${style}"` : "";
  const text = cleanXml(String(value ?? "").slice(0, 32_767));
  return `<c r="${reference}" t="inlineStr"${styleAttribute}><is><t xml:space="preserve">${text}</t></is></c>`;
}

export async function buildApplicationsXlsx(applications, files = []) {
  const headers = [
    "Application Number",
    "Application Date",
    "Company",
    "Job Title",
    "Job Category",
    "Location",
    "Status",
    "My Score (0-10)",
    "ChatGPT Decision",
    "What the Work Involves",
    "Strongest Matches",
    "Technical Gaps",
    "Seniority",
    "Language Requirement",
    "Degree Requirement",
    "Mandatory Requirements",
    "CV / Application Effort",
    "Follow-up Date",
    "Application Deadline",
    "Interview Date and Time",
    "Recruiter Name",
    "Recruiter Email",
    "Recruiter Phone",
    "Recruiter LinkedIn",
    "Reference Number",
    "Job Link",
    "CV File",
    "Cover Letter",
    "Notes",
    "Interview Questions",
    "Interview Preparation Notes",
    "Status History",
    "Full Job Description",
    "Record State",
    "HR Document Requests",
    "HR Messages"
  ];
  const filesByApp = new Map();
  for (const file of files) {
    if (!filesByApp.has(file.appId)) filesByApp.set(file.appId, []);
    filesByApp.get(file.appId).push(file);
  }

  const numbered = [...applications].sort((left, right) => {
    const leftKey = left.createdAt || `${left.applicationDate || ""}-${left.id || ""}`;
    const rightKey = right.createdAt || `${right.applicationDate || ""}-${right.id || ""}`;
    return String(leftKey).localeCompare(String(rightKey));
  });
  const numbers = new Map(numbered.map((application, index) => [application.id, index + 1]));
  const sorted = [...applications].sort((a, b) => String(b.applicationDate || "").localeCompare(String(a.applicationDate || "")));
  const rows = [headers];
  for (const app of sorted) {
    const appFiles = filesByApp.get(app.id) || [];
    const cv = appFiles.find((file) => file.kind === "cv");
    const letter = appFiles.find((file) => file.kind === "cover-letter");
    rows.push([
      numbers.get(app.id) || "",
      app.applicationDate || "",
      app.company || "",
      app.jobTitle || "",
      employmentCategoryLabel(app),
      app.location || "",
      statusLabel(app.status),
      applicationScore(app) ?? "",
      app.decision || "",
      app.actualWork || "",
      app.strongestMatches || "",
      app.technicalGaps || "",
      app.seniorityGap || "",
      app.languageRequirement || "",
      app.degreeRequirement || "",
      app.mandatoryRequirements || "",
      app.cvEffort || "",
      app.followUpDate || "",
      app.applicationDeadline || "",
      app.interviewDateTime || "",
      app.recruiterName || "",
      app.recruiterEmail || "",
      app.recruiterPhone || "",
      app.recruiterLinkedIn || "",
      app.referenceNumber || "",
      app.jobUrl || "",
      cv?.name || "",
      letter?.name || "",
      app.notes || "",
      app.interviewQuestions || "",
      app.interviewNotes || "",
      (Array.isArray(app.statusHistory) ? app.statusHistory : [])
        .map((entry) => `${entry.changedAt || ""}: ${statusLabel(entry.status)}`)
        .join("\n"),
      app.jobDescription || "",
      recordState(app),
      (Array.isArray(app.documentRequests) ? app.documentRequests : [])
        .map((request) => `${request.documents || "Documents"} | requested ${request.requestedDate || ""} | deadline ${request.deadline || ""} | sent ${request.sentDate || "not sent"}`)
        .join("\n"),
      (Array.isArray(app.hrMessages) ? app.hrMessages : [])
        .map((message) => `${message.direction || "received"} ${message.date || ""} | ${message.subject || "No subject"}: ${message.message || ""}`)
        .join("\n")
    ]);
  }

  const rowXml = [];
  const hyperlinks = [];
  const hyperlinkRelations = [];
  rows.forEach((row, rowIndex) => {
    const cells = row.map((value, columnIndex) => {
      const reference = `${columnName(columnIndex)}${rowIndex + 1}`;
      const style = rowIndex === 0 ? 1 : ((columnIndex >= 8 && columnIndex <= 16) || columnIndex >= 28 ? 2 : 3);
      if (rowIndex > 0 && columnIndex === 25 && value) {
        const relationId = `rId${hyperlinkRelations.length + 1}`;
        hyperlinks.push(`<hyperlink ref="${reference}" r:id="${relationId}"/>`);
        hyperlinkRelations.push(`<Relationship Id="${relationId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="${cleanXml(value)}" TargetMode="External"/>`);
      }
      return inlineCell(reference, value, style);
    }).join("");
    const height = rowIndex === 0 ? 27 : 34;
    rowXml.push(`<row r="${rowIndex + 1}" ht="${height}" customHeight="1">${cells}</row>`);
  });

  const lastRow = Math.max(1, rows.length);
  const hyperlinksXml = hyperlinks.length ? `<hyperlinks>${hyperlinks.join("")}</hyperlinks>` : "";
  const worksheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <dimension ref="A1:AJ${lastRow}"/>
  <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
  <sheetFormatPr defaultRowHeight="18"/>
  <cols>
    <col min="1" max="1" width="15" customWidth="1"/><col min="2" max="2" width="15" customWidth="1"/>
    <col min="3" max="3" width="24" customWidth="1"/><col min="4" max="4" width="34" customWidth="1"/>
    <col min="5" max="5" width="18" customWidth="1"/><col min="6" max="6" width="23" customWidth="1"/>
    <col min="7" max="7" width="15" customWidth="1"/><col min="8" max="8" width="18" customWidth="1"/>
    <col min="9" max="17" width="34" customWidth="1"/><col min="18" max="24" width="20" customWidth="1"/>
    <col min="25" max="25" width="17" customWidth="1"/><col min="26" max="26" width="38" customWidth="1"/>
    <col min="27" max="28" width="28" customWidth="1"/><col min="29" max="32" width="36" customWidth="1"/>
    <col min="33" max="33" width="55" customWidth="1"/><col min="34" max="34" width="16" customWidth="1"/>
    <col min="35" max="36" width="45" customWidth="1"/>
  </cols>
  <sheetData>${rowXml.join("")}</sheetData>
  <autoFilter ref="A1:AJ${lastRow}"/>
  ${hyperlinksXml}
</worksheet>`;

  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2"><font><sz val="11"/><name val="Aptos"/><family val="2"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos Display"/><family val="2"/></font></fonts>
  <fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF2457D6"/><bgColor indexed="64"/></patternFill></fill></fills>
  <borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left/><right/><top/><bottom style="thin"><color rgb="FFE2E6ED"/></bottom><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="4">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment vertical="center"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="top" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"><alignment vertical="center"/></xf>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`;

  const timestamp = new Date().toISOString();
  const entries = [
    { name: "[Content_Types].xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>` },
    { name: "_rels/.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>` },
    { name: "docProps/core.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>My Job Applications</dc:title><dc:creator>My Job Manager</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">${timestamp}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${timestamp}</dcterms:modified></cp:coreProperties>` },
    { name: "docProps/app.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>My Job Manager</Application><HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>1</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size="1" baseType="lpstr"><vt:lpstr>Applications</vt:lpstr></vt:vector></TitlesOfParts></Properties>` },
    { name: "xl/workbook.xml", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView xWindow="0" yWindow="0" windowWidth="24000" windowHeight="14000"/></bookViews><sheets><sheet name="Applications" sheetId="1" r:id="rId1"/></sheets></workbook>` },
    { name: "xl/_rels/workbook.xml.rels", data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: "xl/styles.xml", data: styles },
    { name: "xl/worksheets/sheet1.xml", data: worksheet }
  ];

  if (hyperlinkRelations.length) {
    entries.push({
      name: "xl/worksheets/_rels/sheet1.xml.rels",
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${hyperlinkRelations.join("")}</Relationships>`
    });
  }

  return createStoredZip(entries, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
}

export async function buildBackupZip(applications, files, settings = {}, jobLeads = []) {
  const appsById = new Map(applications.map((app) => [app.id, app]));
  const fileMetadata = [];
  const entries = [];

  for (const file of files) {
    const app = appsById.get(file.appId) || {};
    const company = safeFileName(app.company || "Unknown company");
    const date = app.applicationDate || "No date";
    const type = safeFileName(file.kind || "document");
    const name = safeFileName(file.name || "document");
    const path = `Documents/${company}/${date}_${type}_${String(file.id).slice(-8)}_${name}`;
    fileMetadata.push({
      id: file.id,
      appId: file.appId,
      kind: file.kind,
      name: file.name,
      mimeType: file.mimeType,
      size: file.size,
      createdAt: file.createdAt,
      messageId: file.messageId || "",
      path
    });
    entries.push({ name: path, data: file.blob });
  }

  const manifest = {
    format: "moiz-job-manager-backup",
    version: 4,
    exportedAt: new Date().toISOString(),
    applications,
    files: fileMetadata,
    jobLeads: Array.isArray(jobLeads) ? jobLeads : [],
    settings: {
      globalNotes: String(settings.globalNotes || ""),
      jobFinder: settings.jobFinder && typeof settings.jobFinder === "object" ? settings.jobFinder : {},
      preferences: settings.preferences && typeof settings.preferences === "object" ? settings.preferences : {},
      companyProfiles: settings.companyProfiles && typeof settings.companyProfiles === "object" ? settings.companyProfiles : {}
    }
  };

  const xlsx = await buildApplicationsXlsx(applications, files);
  entries.unshift(
    { name: "applications.json", data: JSON.stringify(manifest, null, 2) },
    { name: "Job_Applications.xlsx", data: xlsx },
    { name: "README.txt", data: "My Job Manager complete backup\n\nThis ZIP contains your active, archived, recently deleted and returned jobs; Excel export; per-job CVs and documents; HR messages; job leads; tracking details; company notes; and general notes. It never contains background-profile documents. Import the original ZIP, or its extracted folder, from the dashboard. Keep it private because it contains personal information.\n" }
  );

  return createStoredZip(entries);
}

function normalizedEntryName(value) {
  return String(value || "").replace(/\\/g, "/").replace(/^\.\//, "").replace(/^\/+/, "");
}

function findManifestEntry(entries) {
  const candidates = [...entries.keys()]
    .map(normalizedEntryName)
    .filter((name) => name === "applications.json" || name.endsWith("/applications.json"))
    .sort((left, right) => left.length - right.length);
  if (!candidates.length) return null;
  const path = candidates[0];
  return {
    path,
    root: path.slice(0, -"applications.json".length)
  };
}

function getEntry(entries, root, path) {
  return entries.get(normalizedEntryName(`${root}${path}`)) || entries.get(normalizedEntryName(path));
}

async function readBackupEntries(entries) {
  const manifestEntry = findManifestEntry(entries);
  const manifestBytes = manifestEntry ? entries.get(manifestEntry.path) : null;
  if (!manifestBytes) throw new Error("applications.json is missing. This is not a Job Manager backup.");

  let manifest;
  try {
    manifest = JSON.parse(decoder.decode(manifestBytes));
  } catch {
    throw new Error("The backup information cannot be read.");
  }
  if (manifest?.format !== "moiz-job-manager-backup" || ![1, 2, 3, 4].includes(manifest?.version)) {
    throw new Error("This backup version is not supported.");
  }
  if (!Array.isArray(manifest.applications) || !Array.isArray(manifest.files)) {
    throw new Error("The backup information is incomplete.");
  }

  const restoredFiles = manifest.files.map((metadata) => {
    const bytes = getEntry(entries, manifestEntry.root, metadata.path);
    if (!bytes) throw new Error(`A stored document is missing: ${metadata.name || metadata.path}`);
    return {
      id: metadata.id,
      appId: metadata.appId,
      kind: metadata.kind || "other",
      name: metadata.name || "document",
      mimeType: metadata.mimeType || "application/octet-stream",
      size: metadata.size || bytes.length,
      createdAt: metadata.createdAt || new Date().toISOString(),
      messageId: metadata.messageId || "",
      blob: new Blob([bytes], { type: metadata.mimeType || "application/octet-stream" })
    };
  });

  return {
    applications: manifest.applications,
    files: restoredFiles,
    jobLeads: Array.isArray(manifest.jobLeads) ? manifest.jobLeads : [],
    skippedBackgroundDocuments: Array.isArray(manifest.profileDocuments) ? manifest.profileDocuments.length : 0,
    settings: manifest.settings && typeof manifest.settings === "object" ? manifest.settings : {},
    exportedAt: manifest.exportedAt
  };
}

async function readWithJsZip(file) {
  if (!globalThis.JSZip) throw new Error("This ZIP uses compression that cannot be opened here.");
  const input = file instanceof Uint8Array ? file : new Uint8Array(await file.arrayBuffer());
  const zip = await globalThis.JSZip.loadAsync(input);
  const entries = new Map();
  for (const [name, item] of Object.entries(zip.files)) {
    if (item.dir) continue;
    entries.set(normalizedEntryName(name), await item.async("uint8array"));
  }
  return entries;
}

export async function readBackupZip(file) {
  let entries;
  try {
    entries = parseStoredZip(await file.arrayBuffer());
  } catch (error) {
    if (!globalThis.JSZip) throw error;
    entries = await readWithJsZip(file);
  }
  return readBackupEntries(entries);
}

export async function readBackupFolder(fileList) {
  const files = [...(fileList || [])];
  if (!files.length) throw new Error("No backup folder was selected.");
  const entries = new Map();
  for (const file of files) {
    const name = normalizedEntryName(file.webkitRelativePath || file.name);
    entries.set(name, new Uint8Array(await file.arrayBuffer()));
  }
  return readBackupEntries(entries);
}

export function downloadBlob(blob, fileName) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2_000);
}

function pdfPlain(value) {
  return String(value ?? "")
    .replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue")
    .replace(/Ä/g, "Ae").replace(/Ö/g, "Oe").replace(/Ü/g, "Ue").replace(/ß/g, "ss")
    .replace(/[–—]/g, "-").replace(/[“”]/g, '"').replace(/[‘’]/g, "'")
    .replace(/[^\x20-\x7e\n]/g, "?");
}

function pdfEscape(value) {
  return pdfPlain(value).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function wrapPdfText(value, width = 88) {
  const lines = [];
  for (const paragraph of pdfPlain(value).split(/\r?\n/)) {
    const words = paragraph.trim().split(/\s+/).filter(Boolean);
    if (!words.length) { lines.push(""); continue; }
    let line = "";
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (next.length > width && line) { lines.push(line); line = word; }
      else line = next;
    }
    if (line) lines.push(line);
  }
  return lines;
}

export function buildApplicationPdf(application, files = []) {
  const app = application || {};
  const lines = [];
  const add = (text = "", bold = false, size = 10) => lines.push({ text: pdfPlain(text), bold, size });
  const section = (title) => { add(""); add(title.toUpperCase(), true, 12); };
  const field = (label, value) => {
    if (value === "" || value === null || value === undefined) return;
    add(label, true, 10);
    for (const line of wrapPdfText(value)) add(line, false, 10);
  };

  add("MY JOB MANAGER", true, 18);
  add("Single application report", false, 11);
  add(`Created ${formatDate(new Date().toISOString().slice(0, 10))}`, false, 9);
  section("Application");
  field("Company", app.company || "Unknown company");
  field("Job title", app.jobTitle || "Untitled job");
  field("Location", app.location);
  field("Category", employmentCategoryLabel(app));
  field("Status", statusLabel(app.status));
  field("Record state", recordState(app));
  field("Application date", app.applicationDate ? formatDate(app.applicationDate) : "Not set");
  field("Score", applicationScore(app) === null ? "Not scored" : `${applicationScore(app).toFixed(1)}/10`);
  field("Reference number", app.referenceNumber);
  field("Job link", app.jobUrl);

  section("Important dates");
  field("Follow-up", app.followUpDate ? formatDate(app.followUpDate) : "Not set");
  field("Application deadline", app.applicationDeadline ? formatDate(app.applicationDeadline) : "Not set");
  field("Interview", app.interviewDateTime || "Not set");

  section("Recruiter");
  field("Name", app.recruiterName);
  field("Email", app.recruiterEmail);
  field("Phone", app.recruiterPhone);
  field("Contact link", app.recruiterLinkedIn);

  const requests = Array.isArray(app.documentRequests) ? app.documentRequests : [];
  if (requests.length) {
    section("HR document requests");
    for (const request of requests) {
      field(request.sentDate ? "Documents sent" : "Documents requested", request.documents || "Documents");
      field("Requested", request.requestedDate || "");
      field("Deadline", request.deadline || "");
      field("Sent", request.sentDate || "Not sent yet");
    }
  }

  const messages = Array.isArray(app.hrMessages) ? app.hrMessages : [];
  if (messages.length) {
    section("HR messages");
    for (const message of messages) {
      field(`${message.direction === "sent" ? "Sent" : "Received"} ${message.date || ""} - ${message.subject || "No subject"}`, message.message || "");
    }
  }

  section("Application documents");
  if (files.length) for (const file of files) field(file.kind || "Document", file.name || "Document");
  else add("No documents stored.");

  section("Notes and preparation");
  field("Job notes", app.notes);
  field("Interview questions", app.interviewQuestions);
  field("Interview preparation notes", app.interviewNotes);

  const history = Array.isArray(app.statusHistory) ? app.statusHistory : [];
  if (history.length) {
    section("Status history");
    for (const entry of history) add(`${entry.changedAt || ""} - ${statusLabel(entry.status)}`);
  }
  if (app.jobDescription) {
    section("Saved job description");
    for (const line of wrapPdfText(app.jobDescription)) add(line);
  }

  const perPage = 48;
  const pages = [];
  for (let index = 0; index < lines.length; index += perPage) pages.push(lines.slice(index, index + perPage));
  if (!pages.length) pages.push([{ text: "No application information available.", bold: false, size: 10 }]);

  const objects = new Map();
  const pageObjectNumbers = [];
  pages.forEach((_, index) => pageObjectNumbers.push(5 + index * 2));
  objects.set(1, `<< /Type /Catalog /Pages 2 0 R >>`);
  objects.set(2, `<< /Type /Pages /Count ${pages.length} /Kids [${pageObjectNumbers.map((number) => `${number} 0 R`).join(" ")}] >>`);
  objects.set(3, `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>`);
  objects.set(4, `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>`);

  pages.forEach((page, index) => {
    const pageNumber = 5 + index * 2;
    const contentNumber = pageNumber + 1;
    let y = 800;
    const commands = [];
    for (const item of page) {
      const font = item.bold ? "F2" : "F1";
      commands.push(`BT /${font} ${item.size || 10} Tf 48 ${y} Td (${pdfEscape(item.text)}) Tj ET`);
      y -= item.text ? Math.max(13, (item.size || 10) + 4) : 8;
    }
    commands.push(`BT /F1 8 Tf 48 28 Td (My Job Manager - Page ${index + 1} of ${pages.length}) Tj ET`);
    const stream = commands.join("\n");
    objects.set(pageNumber, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentNumber} 0 R >>`);
    objects.set(contentNumber, `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
  });

  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  const maxObject = Math.max(...objects.keys());
  for (let number = 1; number <= maxObject; number += 1) {
    offsets[number] = pdf.length;
    pdf += `${number} 0 obj\n${objects.get(number)}\nendobj\n`;
  }
  const xref = pdf.length;
  pdf += `xref\n0 ${maxObject + 1}\n0000000000 65535 f \n`;
  for (let number = 1; number <= maxObject; number += 1) pdf += `${String(offsets[number]).padStart(10, "0")} 00000 n \n`;
  pdf += `trailer\n<< /Size ${maxObject + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new Blob([encoder.encode(pdf)], { type: "application/pdf" });
}
