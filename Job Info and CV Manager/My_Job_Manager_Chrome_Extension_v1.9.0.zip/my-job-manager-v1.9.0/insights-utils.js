import { createId, recordState, todayLocal } from "./common.js";

const CLOSED_STATUSES = new Set(["offer", "rejected", "withdrawn"]);

function value(value) {
  return String(value ?? "").trim();
}

function key(valueToNormalize) {
  return value(valueToNormalize)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function companyKey(company) {
  return key(company).replace(/\s+(gmbh|ag|se|kg|ug|ltd|limited|inc|corp|corporation)$/i, "").trim();
}

export function normalizeImportDate(input) {
  const raw = value(input);
  if (!raw) return "";
  const validParts = (year, month, day) => {
    const date = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
    return date.getUTCFullYear() === Number(year)
      && date.getUTCMonth() === Number(month) - 1
      && date.getUTCDate() === Number(day);
  };
  const iso = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) {
    const candidate = `${iso[1]}-${iso[2]}-${iso[3]}`;
    return validParts(iso[1], iso[2], iso[3]) ? candidate : "";
  }
  const european = raw.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/);
  if (european) {
    const candidate = `${european[3]}-${european[2].padStart(2, "0")}-${european[1].padStart(2, "0")}`;
    return validParts(european[3], european[2], european[1]) ? candidate : "";
  }
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? "" : parsed.toISOString().slice(0, 10);
}

export function normalizeOutcomeStatus(input) {
  const normalized = key(input).replace(/\s+/g, "-");
  if (!normalized) return "";
  if (["applied", "application-received", "received", "pending", "under-review", "in-review", "processing"].includes(normalized)) return "applied";
  if (["documents-requested", "document-requested", "additional-documents-requested", "transcript-requested"].includes(normalized)) return "documents-requested";
  if (["documents-sent", "document-sent", "additional-documents-sent"].includes(normalized)) return "documents-sent";
  if (["interview", "interview-invitation", "interview-invited", "screening", "phone-screen"].includes(normalized)) return "interview";
  if (["offer", "job-offer", "offered", "accepted"].includes(normalized)) return "offer";
  if (["rejected", "rejection", "declined", "not-selected", "unsuccessful"].includes(normalized)) return "rejected";
  if (["withdrawn", "withdraw", "cancelled", "canceled"].includes(normalized)) return "withdrawn";
  return "";
}

function normalizeEvent(raw = {}, fallbackDate = "") {
  const sourceType = value(raw.type || raw.status || raw.eventType);
  const type = normalizeOutcomeStatus(sourceType);
  const date = normalizeImportDate(raw.date || raw.statusDate || raw.updateDate || fallbackDate);
  return {
    type,
    sourceType,
    date,
    emailSubject: value(raw.emailSubject || raw.subject),
    reasonStated: value(raw.reasonStated || raw.reason),
    notes: value(raw.notes || raw.importantNotes)
  };
}

function eventKey(event = {}) {
  return [event.type, event.date, key(event.emailSubject), key(event.reasonStated)].join("|");
}

function uniqueEvents(events = []) {
  const seen = new Set();
  return events.filter((event) => {
    if (!event.type || !event.date) return false;
    const identity = eventKey(event);
    if (seen.has(identity)) return false;
    seen.add(identity);
    return true;
  }).sort((left, right) => left.date.localeCompare(right.date));
}

export function normalizeOutcomeRecord(raw = {}, index = 0) {
  const applicationDate = normalizeImportDate(raw.applicationDate || raw.appliedDate || raw.appliedAt);
  const lastUpdateDate = normalizeImportDate(raw.lastUpdateDate || raw.statusUpdateDate || raw.updatedAt);
  const currentStatusText = value(raw.currentStatus || raw.status);
  const currentStatus = normalizeOutcomeStatus(currentStatusText);
  let events = Array.isArray(raw.events) ? raw.events.map((event) => normalizeEvent(event, lastUpdateDate)) : [];
  if (applicationDate && !events.some((event) => event.type === "applied" && event.date === applicationDate)) {
    events.push(normalizeEvent({ type: "applied", date: applicationDate }));
  }
  if (currentStatus && lastUpdateDate && !events.some((event) => event.type === currentStatus && event.date === lastUpdateDate)) {
    events.push(normalizeEvent({ type: currentStatusText, date: lastUpdateDate }));
  }
  events = uniqueEvents(events);
  const importantNotes = Array.isArray(raw.importantNotes)
    ? raw.importantNotes.map(value).filter(Boolean)
    : value(raw.importantNotes) ? [value(raw.importantNotes)] : [];
  const attachmentsSubmitted = Array.isArray(raw.attachmentsSubmitted)
    ? raw.attachmentsSubmitted.map(value).filter(Boolean)
    : value(raw.attachmentsSubmitted) ? [value(raw.attachmentsSubmitted)] : [];
  const record = {
    sourceIndex: index,
    company: value(raw.company || raw.employer),
    jobTitle: value(raw.jobTitle || raw.title || raw.position),
    jobId: value(raw.jobId || raw.requisitionId || raw.referenceNumber || raw.reference),
    location: value(raw.location),
    applicationDate,
    currentStatus,
    currentStatusText,
    lastUpdateDate,
    senderDomain: value(raw.senderDomain || raw.recruitingEmailDomain),
    recruiterName: value(raw.recruiterName || raw.contactName),
    recruiterEmail: value(raw.recruiterEmail || raw.contactEmail),
    recruiterPhone: value(raw.recruiterPhone || raw.contactPhone),
    jobUrl: value(raw.jobUrl || raw.applicationUrl || raw.portalLink),
    recruitingSystem: value(raw.recruitingSystem || raw.ats),
    applicationSource: value(raw.applicationSource || raw.source),
    attachmentsSubmitted,
    importantNotes,
    events
  };
  record.validationErrors = [];
  if (!record.company) record.validationErrors.push("Company is missing");
  if (!record.jobTitle && !record.jobId) record.validationErrors.push("Job title or Job ID is required");
  if (!record.events.length && !record.currentStatus) record.validationErrors.push("No dated status event was provided");
  return record;
}

export function parseOutcomeImport(text) {
  let source = value(text);
  const fence = source.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (fence) source = fence[1];
  if (!source) throw new Error("Paste the JSON result from your Gmail-connected ChatGPT chat first.");
  let parsed;
  try { parsed = JSON.parse(source); }
  catch { throw new Error("This is not valid JSON. Ask ChatGPT to return only one JSON array."); }
  const rows = Array.isArray(parsed)
    ? parsed
    : parsed && typeof parsed === "object"
      ? parsed.applications || parsed.records || parsed.outcomes || parsed.jobs
      : null;
  if (!Array.isArray(rows)) throw new Error("The JSON must be an array, or an object containing an applications array.");
  if (!rows.length) throw new Error("The JSON array is empty.");
  return rows.map((row, index) => normalizeOutcomeRecord(row, index));
}

function availableApplications(applications = []) {
  return applications.filter((application) => !["deleted", "returned"].includes(recordState(application)));
}

function recordEventsAlreadyStored(record, application) {
  if (!record.events.length) return false;
  const existing = new Set((application.emailEvents || []).map(eventKey));
  return record.events.every((event) => existing.has(eventKey(event)));
}

export function matchOutcomeRecord(record, applications = []) {
  if (record.validationErrors?.length) return { type: "invalid", reason: record.validationErrors.join("; "), candidates: [] };
  const pool = availableApplications(applications);
  const company = companyKey(record.company);
  const title = key(record.jobTitle);
  const location = key(record.location);
  const jobId = key(record.jobId);
  const sameCompany = pool.filter((app) => companyKey(app.company) === company);

  const decide = (matches, type, reason) => {
    if (matches.length === 1) {
      return {
        type,
        appId: matches[0].id,
        reason,
        candidates: matches,
        duplicate: recordEventsAlreadyStored(record, matches[0])
      };
    }
    if (matches.length > 1) return { type: "possible", reason: `${reason}, but more than one application matches`, candidates: matches };
    return null;
  };

  if (company && jobId) {
    const result = decide(sameCompany.filter((app) => key(app.referenceNumber || app.jobId) === jobId), "exact", "Company and Job ID match");
    if (result) return result;
  }
  if (company && title && location) {
    const result = decide(sameCompany.filter((app) => key(app.jobTitle) === title && key(app.location) === location), "exact", "Company, exact title and location match");
    if (result) return result;
  }
  if (company && title && record.applicationDate) {
    const result = decide(sameCompany.filter((app) => key(app.jobTitle) === title && app.applicationDate === record.applicationDate), "exact", "Company, exact title and application date match");
    if (result) return result;
  }
  if (company && title) {
    const result = decide(sameCompany.filter((app) => key(app.jobTitle) === title), "possible", "Company and exact title match");
    if (result) return result;
  }
  return { type: "new", reason: "No safe match was found", candidates: [] };
}

function statusHistoryEntry(event) {
  return { status: event.type, changedAt: `${event.date}T12:00:00.000Z`, source: "gmail-import" };
}

function latestDatedStatus(events = []) {
  return [...events].filter((event) => event.type && event.date).sort((a, b) => a.date.localeCompare(b.date)).at(-1) || null;
}

function mergeUniqueText(existing = [], incoming = []) {
  const result = [];
  const seen = new Set();
  for (const item of [...existing, ...incoming]) {
    const cleaned = value(item);
    const identity = key(cleaned);
    if (cleaned && !seen.has(identity)) {
      seen.add(identity);
      result.push(cleaned);
    }
  }
  return result;
}

export function mergeOutcomeIntoApplication(application, record, now = new Date().toISOString()) {
  const result = structuredClone(application);
  const existingEvents = Array.isArray(result.emailEvents) ? result.emailEvents : [];
  const seenEvents = new Set(existingEvents.map(eventKey));
  const incomingEvents = record.events
    .filter((event) => !seenEvents.has(eventKey(event)))
    .map((event) => ({ ...event, id: createId("email-event"), importedAt: now }));
  result.emailEvents = [...existingEvents, ...incomingEvents].sort((left, right) => String(left.date).localeCompare(String(right.date)));

  const history = Array.isArray(result.statusHistory) ? [...result.statusHistory] : [];
  const historyKeys = new Set(history.map((entry) => `${entry.status}|${normalizeImportDate(entry.changedAt)}`));
  for (const event of record.events) {
    const identity = `${event.type}|${event.date}`;
    if (!historyKeys.has(identity)) {
      history.push(statusHistoryEntry(event));
      historyKeys.add(identity);
    }
  }
  history.sort((left, right) => String(left.changedAt).localeCompare(String(right.changedAt)));
  result.statusHistory = history;

  const importedLatest = latestDatedStatus(record.events);
  const existingLatestDate = normalizeImportDate(history.filter((entry) => entry.source !== "gmail-import").at(-1)?.changedAt || result.updatedAt);
  if (importedLatest && (!existingLatestDate || importedLatest.date >= existingLatestDate)) result.status = importedLatest.type;

  result.company ||= record.company;
  result.jobTitle ||= record.jobTitle;
  result.location ||= record.location;
  result.applicationDate ||= record.applicationDate;
  result.referenceNumber ||= record.jobId;
  result.jobUrl ||= record.jobUrl;
  result.recruiterName ||= record.recruiterName;
  result.recruiterEmail ||= record.recruiterEmail;
  result.recruiterPhone ||= record.recruiterPhone;
  result.recruitingSystem ||= record.recruitingSystem;
  result.applicationSource ||= record.applicationSource;
  result.senderDomain ||= record.senderDomain;
  result.attachmentsSubmitted = mergeUniqueText(result.attachmentsSubmitted, record.attachmentsSubmitted);
  result.gmailImportNotes = mergeUniqueText(result.gmailImportNotes, record.importantNotes);
  result.updatedAt = now;
  return result;
}

export function createApplicationFromOutcome(record, now = new Date().toISOString()) {
  const latest = latestDatedStatus(record.events);
  const applicationDate = record.applicationDate || record.events.find((event) => event.type === "applied")?.date || "";
  const base = {
    id: createId("app"),
    company: record.company,
    jobTitle: record.jobTitle || `Job ${record.jobId}`,
    location: record.location,
    jobUrl: record.jobUrl,
    applicationDate: applicationDate || latest?.date || todayLocal(),
    applicationDateEstimated: !applicationDate,
    status: latest?.type || record.currentStatus || "applied",
    referenceNumber: record.jobId,
    recruiterName: record.recruiterName,
    recruiterEmail: record.recruiterEmail,
    recruiterPhone: record.recruiterPhone,
    recruitingSystem: record.recruitingSystem,
    applicationSource: record.applicationSource,
    senderDomain: record.senderDomain,
    attachmentsSubmitted: mergeUniqueText([], record.attachmentsSubmitted),
    gmailImportNotes: mergeUniqueText([], record.importantNotes),
    emailEvents: [],
    statusHistory: [],
    manualScore: null,
    documentRequests: [],
    hrMessages: [],
    createdAt: now,
    updatedAt: now
  };
  return mergeOutcomeIntoApplication(base, record, now);
}

function dateDays(from, to) {
  const start = normalizeImportDate(from);
  const end = normalizeImportDate(to);
  if (!start || !end) return null;
  const days = Math.round((new Date(`${end}T12:00:00Z`) - new Date(`${start}T12:00:00Z`)) / 86_400_000);
  return days >= 0 ? days : null;
}

function roundedAverage(values) {
  return values.length ? Math.round((values.reduce((sum, item) => sum + item, 0) / values.length) * 10) / 10 : null;
}

function median(values) {
  if (!values.length) return null;
  const ordered = [...values].sort((a, b) => a - b);
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2 ? ordered[middle] : Math.round(((ordered[middle - 1] + ordered[middle]) / 2) * 10) / 10;
}

function allStatusEvents(application) {
  const fromEmails = (application.emailEvents || []).map((event) => ({ status: event.type, date: normalizeImportDate(event.date), reasonStated: event.reasonStated || "" }));
  const fromHistory = (application.statusHistory || []).map((event) => ({ status: event.status, date: normalizeImportDate(event.changedAt), reasonStated: "" }));
  return [...fromEmails, ...fromHistory].filter((event) => event.status && event.date).sort((a, b) => a.date.localeCompare(b.date));
}

function earliestEvent(application, statuses) {
  return allStatusEvents(application).find((event) => statuses.has(event.status)) || null;
}

export function buildInsights(applications = [], referenceDate = new Date()) {
  const records = applications.filter((application) => !["deleted", "returned"].includes(recordState(application)));
  const rejectionDays = [];
  const interviewDays = [];
  const responseDays = [];
  const companies = new Map();
  const reasons = new Map();
  const rejectionDetails = [];
  let interviews = 0;
  let offers = 0;
  let rejections = 0;
  let responses = 0;

  for (const app of records) {
    const events = allStatusEvents(app);
    const rejection = events.find((event) => event.status === "rejected");
    const interview = events.find((event) => event.status === "interview");
    const offer = events.find((event) => event.status === "offer");
    const response = events.find((event) => !["applied", "saved"].includes(event.status));
    if (rejection || app.status === "rejected") rejections += 1;
    if (interview || ["interview", "offer"].includes(app.status)) interviews += 1;
    if (offer || app.status === "offer") offers += 1;
    if (response) responses += 1;
    const rejectedAfter = rejection ? dateDays(app.applicationDate, rejection.date) : null;
    const interviewedAfter = interview ? dateDays(app.applicationDate, interview.date) : null;
    const respondedAfter = response ? dateDays(app.applicationDate, response.date) : null;
    if (!app.applicationDateEstimated && rejectedAfter !== null) rejectionDays.push(rejectedAfter);
    if (!app.applicationDateEstimated && interviewedAfter !== null) interviewDays.push(interviewedAfter);
    if (!app.applicationDateEstimated && respondedAfter !== null) responseDays.push(respondedAfter);
    if (rejection) {
      const emailRejection = (app.emailEvents || []).find((event) => event.type === "rejected" && normalizeImportDate(event.date) === rejection.date);
      rejectionDetails.push({
        id: app.id,
        company: app.company || "Unknown company",
        jobTitle: app.jobTitle || "Untitled job",
        applicationDate: app.applicationDate || "",
        rejectionDate: rejection.date,
        days: app.applicationDateEstimated ? null : rejectedAfter,
        reasonStated: value(emailRejection?.reasonStated)
      });
    }

    const identity = companyKey(app.company) || "unknown";
    const company = companies.get(identity) || { company: app.company || "Unknown company", applications: 0, rejected: 0, interviews: 0, offers: 0 };
    company.applications += 1;
    if (rejection || app.status === "rejected") company.rejected += 1;
    if (interview || ["interview", "offer"].includes(app.status)) company.interviews += 1;
    if (offer || app.status === "offer") company.offers += 1;
    companies.set(identity, company);

    for (const event of (app.emailEvents || [])) {
      if (event.type !== "rejected" || !value(event.reasonStated)) continue;
      const reason = value(event.reasonStated);
      reasons.set(reason, (reasons.get(reason) || 0) + 1);
    }
  }

  const companyRows = [...companies.values()].map((company) => ({
    ...company,
    rejectionRate: company.applications ? Math.round((company.rejected / company.applications) * 1000) / 10 : 0
  })).sort((left, right) => right.rejected - left.rejected || right.rejectionRate - left.rejectionRate || right.applications - left.applications);

  const reference = new Date(referenceDate);
  const referenceDay = `${reference.getFullYear()}-${String(reference.getMonth() + 1).padStart(2, "0")}-${String(reference.getDate()).padStart(2, "0")}`;
  const pending = records.filter((app) => !CLOSED_STATUSES.has(app.status)).map((app) => ({
    id: app.id,
    company: app.company,
    jobTitle: app.jobTitle,
    applicationDate: app.applicationDate,
    days: dateDays(app.applicationDate, referenceDay)
  })).filter((item) => item.days !== null).sort((left, right) => right.days - left.days);

  return {
    total: records.length,
    interviews,
    offers,
    rejections,
    responses,
    responseRate: records.length ? Math.round((responses / records.length) * 1000) / 10 : 0,
    rejectionTiming: { average: roundedAverage(rejectionDays), median: median(rejectionDays), sample: rejectionDays.length },
    interviewTiming: { average: roundedAverage(interviewDays), median: median(interviewDays), sample: interviewDays.length },
    responseTiming: { average: roundedAverage(responseDays), median: median(responseDays), sample: responseDays.length },
    companies: companyRows,
    longestPending: pending.slice(0, 12),
    rejectionDetails: rejectionDetails.sort((left, right) => right.rejectionDate.localeCompare(left.rejectionDate)),
    statedReasons: [...reasons.entries()].map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count)
  };
}
