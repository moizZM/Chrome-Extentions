import { createApplication, listApplications, updateApplication } from "./db.js";
import { formatDate, recordState, statusLabel } from "./common.js";
import {
  buildInsights,
  createApplicationFromOutcome,
  matchOutcomeRecord,
  mergeOutcomeIntoApplication,
  parseOutcomeImport
} from "./insights-utils.js";

const $ = (selector) => document.querySelector(selector);
const state = { applications: [], preview: [], toastTimer: null };

function node(tag, className = "", text = "") {
  const item = document.createElement(tag);
  if (className) item.className = className;
  if (text !== "") item.textContent = text;
  return item;
}

function showToast(message, error = false) {
  clearTimeout(state.toastTimer);
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", error);
  toast.classList.add("show");
  state.toastTimer = setTimeout(() => toast.classList.remove("show"), 4500);
}

function appLabel(application) {
  return `${application.company || "Unknown company"} · ${application.jobTitle || "Untitled job"}${application.referenceNumber ? ` · ID ${application.referenceNumber}` : ""}`;
}

function defaultAction(match) {
  if (match.type === "invalid" || match.duplicate) return "ignore";
  if (match.type === "new") return "create";
  if (match.appId) return `app:${match.appId}`;
  return "ignore";
}

function renderResolution(item, index) {
  const label = node("label", "resolution");
  label.append(node("span", "", "What should happen?"));
  const select = document.createElement("select");
  select.dataset.previewIndex = String(index);
  const choices = [
    { value: "ignore", label: "Ignore this record" },
    { value: "create", label: "Create a new application" }
  ];
  const orderedApps = [...state.applications]
    .filter((app) => !["deleted", "returned"].includes(recordState(app)))
    .sort((a, b) => appLabel(a).localeCompare(appLabel(b)));
  for (const app of orderedApps) choices.push({ value: `app:${app.id}`, label: `Update: ${appLabel(app)}` });
  for (const choice of choices) {
    const option = document.createElement("option");
    option.value = choice.value;
    option.textContent = choice.label;
    option.selected = choice.value === item.action;
    select.append(option);
  }
  select.disabled = item.match.type === "invalid";
  select.addEventListener("change", () => {
    state.preview[index].action = select.value;
    renderApplySummary();
  });
  label.append(select);
  return label;
}

function renderApplySummary() {
  const updates = state.preview.filter((item) => item.action.startsWith("app:")).length;
  const creates = state.preview.filter((item) => item.action === "create").length;
  const ignores = state.preview.length - updates - creates;
  $("#apply-summary").textContent = `${updates} update${updates === 1 ? "" : "s"}, ${creates} new application${creates === 1 ? "" : "s"}, ${ignores} ignored. Nothing changes until you confirm.`;
  $("#apply-outcomes").disabled = updates + creates === 0;
}

function renderPreview() {
  const card = $("#preview-card");
  const list = $("#preview-list");
  list.replaceChildren();
  const counts = { exact: 0, possible: 0, new: 0, invalid: 0, duplicate: 0 };
  for (const item of state.preview) {
    counts[item.match.type] += 1;
    if (item.match.duplicate) counts.duplicate += 1;
  }
  const summary = $("#preview-summary");
  summary.replaceChildren();
  for (const [label, count] of [["Exact", counts.exact], ["Check", counts.possible], ["New", counts.new], ["Duplicates", counts.duplicate], ["Invalid", counts.invalid]]) {
    if (count) summary.append(node("span", "", `${count} ${label}`));
  }

  state.preview.forEach((item, index) => {
    const record = item.record;
    const row = node("article", `preview-row ${item.match.type}`);
    const job = node("div", "preview-job");
    job.append(node("strong", "", `${record.company || "Company missing"} · ${record.jobTitle || `Job ID ${record.jobId || "missing"}`}`));
    job.append(node("span", "", [record.location, record.jobId ? `ID ${record.jobId}` : "", record.applicationDate ? `Applied ${formatDate(record.applicationDate)}` : ""].filter(Boolean).join(" · ") || "No identifying details"));
    const eventSummary = record.events.map((event) => `${statusLabel(event.type)} ${formatDate(event.date)}`).join(" → ");
    job.append(node("small", "", eventSummary || "No valid dated events"));
    const match = node("div", "match-copy");
    const badgeType = item.match.duplicate ? "possible" : item.match.type;
    const badgeLabel = item.match.duplicate ? "Already imported" : item.match.type === "exact" ? "Exact match" : item.match.type === "possible" ? "Check match" : item.match.type === "new" ? "New record" : "Cannot import";
    match.append(node("span", `match-badge ${badgeType}`, badgeLabel), node("small", "", item.match.duplicate ? `${item.match.reason}. These dated events are already stored.` : item.match.reason));
    row.append(job, match, renderResolution(item, index));
    list.append(row);
  });
  card.hidden = false;
  renderApplySummary();
  card.scrollIntoView({ behavior: "smooth", block: "start" });
}

function previewImport() {
  const status = $("#import-status");
  status.textContent = "";
  status.className = "inline-status";
  try {
    const records = parseOutcomeImport($("#outcome-import-text").value);
    state.preview = records.map((record) => {
      const match = matchOutcomeRecord(record, state.applications);
      return { record, match, action: defaultAction(match) };
    });
    renderPreview();
    status.textContent = `${records.length} record${records.length === 1 ? "" : "s"} read safely. Review the matches below.`;
    status.className = "inline-status success";
  } catch (error) {
    state.preview = [];
    $("#preview-card").hidden = true;
    status.textContent = error.message || "The outcome data could not be read.";
    status.className = "inline-status error";
  }
}

async function applyImport() {
  const button = $("#apply-outcomes");
  button.disabled = true;
  button.textContent = "Applying…";
  let updated = 0;
  let created = 0;
  try {
    const appMap = new Map(state.applications.map((app) => [app.id, app]));
    for (const item of state.preview) {
      if (item.action === "ignore") continue;
      const now = new Date().toISOString();
      if (item.action === "create") {
        const application = createApplicationFromOutcome(item.record, now);
        await createApplication(application);
        appMap.set(application.id, application);
        created += 1;
        continue;
      }
      if (item.action.startsWith("app:")) {
        const id = item.action.slice(4);
        const application = appMap.get(id);
        if (!application) continue;
        const merged = mergeOutcomeIntoApplication(application, item.record, now);
        await updateApplication(merged);
        appMap.set(id, merged);
        updated += 1;
      }
    }
    state.applications = [...appMap.values()];
    state.preview = [];
    $("#preview-card").hidden = true;
    $("#outcome-import-text").value = "";
    $("#import-status").textContent = `Imported successfully: ${updated} application${updated === 1 ? "" : "s"} updated and ${created} created.`;
    $("#import-status").className = "inline-status success";
    renderInsights();
    chrome.runtime.sendMessage({ type: "refresh-task-badge" }).catch(() => {});
    showToast("Email outcomes imported. Your insights are updated.");
  } catch (error) {
    console.error(error);
    showToast(error.message || "The confirmed changes could not be applied.", true);
  } finally {
    button.disabled = false;
    button.textContent = "Apply confirmed changes";
  }
}

function timingRow(label, timing) {
  const row = node("div", "timing-row");
  row.append(node("span", "", label), node("strong", "", timing.average === null ? "Not enough data" : `${timing.average} days`));
  row.append(node("small", "", timing.average === null ? "Import dated email events to calculate this." : `Median ${timing.median} days · ${timing.sample} reliable record${timing.sample === 1 ? "" : "s"}`));
  return row;
}

function renderInsights() {
  const insights = buildInsights(state.applications);
  $("#metric-total").textContent = String(insights.total);
  $("#metric-response-rate").textContent = `${insights.responseRate}%`;
  $("#metric-response-count").textContent = `${insights.responses} application${insights.responses === 1 ? "" : "s"}`;
  $("#metric-interviews").textContent = String(insights.interviews);
  $("#metric-offers").textContent = String(insights.offers);
  $("#metric-rejections").textContent = String(insights.rejections);

  const funnel = $("#funnel");
  funnel.replaceChildren();
  const stages = [["Applications", insights.total, ""], ["Responses", insights.responses, ""], ["Interviews", insights.interviews, ""], ["Offers", insights.offers, ""], ["Rejected", insights.rejections, "rejected"]];
  for (const [label, count, className] of stages) {
    const row = node("div", `funnel-row ${className}`);
    const track = node("div", "funnel-track");
    const fill = node("div", "funnel-fill");
    fill.style.width = `${insights.total ? Math.max(1.5, (count / insights.total) * 100) : 0}%`;
    track.append(fill);
    row.append(node("span", "", label), track, node("strong", "", String(count)));
    funnel.append(row);
  }

  const timing = $("#timing-grid");
  timing.replaceChildren(timingRow("First recorded response", insights.responseTiming), timingRow("Interview invitation", insights.interviewTiming), timingRow("Rejection", insights.rejectionTiming));

  const companies = $("#company-insights");
  companies.replaceChildren();
  $("#company-empty").hidden = insights.companies.length > 0;
  for (const company of insights.companies.slice(0, 20)) {
    const row = document.createElement("tr");
    row.append(node("td", "", company.company), node("td", "", String(company.applications)), node("td", "", String(company.rejected)));
    const rate = node("td", "");
    const rateCell = node("div", "rate-cell");
    const mini = node("span", "mini-bar");
    const bar = document.createElement("i");
    bar.style.width = `${company.rejectionRate}%`;
    mini.append(bar);
    rateCell.append(node("span", "", `${company.rejectionRate}%`), mini);
    rate.append(rateCell);
    row.append(rate, node("td", "", String(company.interviews)), node("td", "", String(company.offers)));
    companies.append(row);
  }

  const pending = $("#pending-list");
  pending.replaceChildren();
  if (!insights.longestPending.length) pending.append(node("p", "empty-message", "No open applications with a saved date."));
  for (const item of insights.longestPending) {
    const row = node("div", "pending-row");
    const copy = node("div");
    copy.append(node("strong", "", `${item.company || "Unknown company"} · ${item.jobTitle || "Untitled job"}`), node("small", "", `Applied ${formatDate(item.applicationDate)}`));
    row.append(copy, node("span", "", `${item.days} day${item.days === 1 ? "" : "s"}`));
    pending.append(row);
  }

  const rejectionBody = $("#rejection-insights");
  rejectionBody.replaceChildren();
  $("#rejection-empty").hidden = insights.rejectionDetails.length > 0;
  for (const item of insights.rejectionDetails) {
    const row = document.createElement("tr");
    row.append(
      node("td", "", `${item.company} · ${item.jobTitle}`),
      node("td", "", item.applicationDate ? formatDate(item.applicationDate) : "Unknown"),
      node("td", "", formatDate(item.rejectionDate)),
      node("td", "", item.days === null ? "Not calculated" : `${item.days} day${item.days === 1 ? "" : "s"}`),
      node("td", "", item.reasonStated || "Not stated")
    );
    rejectionBody.append(row);
  }

  const reasonCard = $("#reason-card");
  reasonCard.hidden = !insights.statedReasons.length;
  const reasons = $("#reason-list");
  reasons.replaceChildren();
  for (const item of insights.statedReasons) {
    const row = node("div", "reason-row");
    row.append(node("span", "", item.reason), node("span", "", String(item.count)));
    reasons.append(row);
  }
}

const FORMAT_REQUEST = `Review the job-related emails available in this chat and return ONLY one valid JSON array. Create one record per application. Use company + jobId when available; otherwise use company + exact jobTitle + location/applicationDate. Do not invent missing information. Use YYYY-MM-DD dates. Include these exact fields for every record:\ncompany, jobTitle, jobId, location, applicationDate, currentStatus, lastUpdateDate, senderDomain, recruiterName, recruiterEmail, recruiterPhone, jobUrl, recruitingSystem, applicationSource, attachmentsSubmitted, events, importantNotes.\nEach events item must contain: type, date, emailSubject, reasonStated, notes. Allowed status/event types: applied, pending, documents-requested, documents-sent, interview, offer, rejected, withdrawn. Use empty strings or arrays when unknown.`;

async function copyFormatRequest() {
  await navigator.clipboard.writeText(FORMAT_REQUEST);
  showToast("Format request copied. Paste it into your Gmail-connected ChatGPT chat.");
}

$("#back-dashboard").addEventListener("click", () => { location.href = chrome.runtime.getURL("dashboard.html"); });
$("#open-job-finder").addEventListener("click", () => { location.href = chrome.runtime.getURL("job-finder.html"); });
$("#open-guide").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("guide.html") }));
$("#show-format").addEventListener("click", () => $("#format-dialog").showModal());
$("#close-format").addEventListener("click", () => $("#format-dialog").close());
$("#copy-format").addEventListener("click", copyFormatRequest);
$("#preview-outcomes").addEventListener("click", previewImport);
$("#apply-outcomes").addEventListener("click", applyImport);
$("#clear-import").addEventListener("click", () => {
  $("#outcome-import-text").value = "";
  $("#import-status").textContent = "";
  $("#preview-card").hidden = true;
  state.preview = [];
});
$("#format-dialog").addEventListener("cancel", (event) => { event.preventDefault(); $("#format-dialog").close(); });

async function initialize() {
  try {
    state.applications = await listApplications();
    renderInsights();
  } catch (error) {
    console.error(error);
    showToast("Email Outcomes & Insights could not load.", true);
  }
}

initialize();
