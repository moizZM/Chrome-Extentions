import {
  createApplication,
  deleteJobLead,
  getApplication,
  listApplications,
  listJobLeads,
  putJobLead,
  putJobLeads,
  updateApplication
} from "./db.js";
import { applicationScore, employmentCategory, employmentCategoryLabel, findLikelyDuplicate } from "./common.js";
import { LOCATION_SUGGESTIONS } from "./locations.js";
import {
  buildAnalysisRequest,
  leadToApplication,
  normalizeLead,
  parseStructuredResult
} from "./lead-utils.js";

const SETTINGS_KEY = "myJobManagerJobFinder";
const SOURCES = [
  "LinkedIn",
  "StepStone",
  "Indeed",
  "XING",
  "Bundesagentur für Arbeit",
  "Company career pages",
  "Glassdoor",
  "Other trusted platforms"
];

const state = {
  settings: {
    chatUrl: "",
    analysisChatUrl: "",
    targetRoles: "",
    locations: [],
    sources: [],
    allSources: true,
    notes: ""
  },
  leads: [],
  toastTimer: null
};

const $ = (selector) => document.querySelector(selector);

function node(tag, className = "", text = "") {
  const item = document.createElement(tag);
  if (className) item.className = className;
  if (text !== "") item.textContent = text;
  return item;
}

function showToast(message) {
  const toast = $("#toast");
  clearTimeout(state.toastTimer);
  toast.textContent = message;
  toast.classList.add("show");
  state.toastTimer = setTimeout(() => toast.classList.remove("show"), 4200);
}

function dateLabel(value) {
  if (!value) return "—";
  const date = new Date(`${String(value).slice(0, 10)}T12:00:00`);
  return Number.isNaN(date.getTime())
    ? String(value)
    : new Intl.DateTimeFormat(undefined, { day: "2-digit", month: "short", year: "numeric" }).format(date);
}

function chatUrl(value) {
  let url;
  try { url = new URL(String(value || "").trim()); }
  catch { return null; }
  if (url.protocol !== "https:" || !["chatgpt.com", "chat.openai.com"].includes(url.hostname)) return null;
  return url;
}

async function copyText(value) {
  try {
    await navigator.clipboard.writeText(value);
  } catch {
    const box = document.createElement("textarea");
    box.value = value;
    document.body.append(box);
    box.select();
    document.execCommand("copy");
    box.remove();
  }
}

function renderLocationOptions() {
  const list = $("#location-options");
  list.replaceChildren();
  for (const location of [...new Set(LOCATION_SUGGESTIONS)].sort()) {
    const option = document.createElement("option");
    option.value = location;
    list.append(option);
  }
}

function renderSources() {
  const wrapper = $("#source-options");
  wrapper.replaceChildren();
  for (const source of SOURCES) {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = source;
    input.checked = state.settings.sources.includes(source);
    input.disabled = state.settings.allSources;
    input.addEventListener("change", () => {
      state.settings.sources = [...wrapper.querySelectorAll("input:checked")].map((item) => item.value);
    });
    label.append(input, node("span", "", source));
    wrapper.append(label);
  }
  $("#all-sources").checked = state.settings.allSources;
}

function renderLocations() {
  const wrapper = $("#location-chips");
  wrapper.replaceChildren();
  for (const location of state.settings.locations) {
    const chip = node("span", "chip");
    const remove = node("button", "", "×");
    remove.type = "button";
    remove.setAttribute("aria-label", `Remove ${location}`);
    remove.addEventListener("click", () => {
      state.settings.locations = state.settings.locations.filter((item) => item !== location);
      renderLocations();
    });
    chip.append(document.createTextNode(location), remove);
    wrapper.append(chip);
  }
}

function addLocation() {
  const input = $("#location-input");
  const value = input.value.trim();
  if (!value) return;
  if (!state.settings.locations.some((item) => item.toLocaleLowerCase() === value.toLocaleLowerCase())) {
    state.settings.locations.push(value);
  }
  input.value = "";
  renderLocations();
}

function readSettingsForm() {
  addLocation();
  state.settings.chatUrl = $("#chat-url").value.trim();
  state.settings.analysisChatUrl = $("#analysis-chat-url").value.trim();
  state.settings.targetRoles = $("#target-roles").value.trim();
  state.settings.notes = $("#search-notes").value.trim();
  state.settings.allSources = $("#all-sources").checked;
  state.settings.sources = state.settings.allSources
    ? []
    : [...document.querySelectorAll("#source-options input:checked")].map((input) => input.value);
  return state.settings;
}

async function saveSettings(showConfirmation = true) {
  readSettingsForm();
  await chrome.storage.local.set({ [SETTINGS_KEY]: state.settings });
  renderSettingsSummary();
  if (!showConfirmation) return;
  $("#settings-status").textContent = "Saved locally";
  showToast("Search setup saved on this computer.");
  setTimeout(() => { $("#settings-status").textContent = ""; }, 2200);
}

function renderSettingsSummary() {
  const roles = state.settings.targetRoles.split(/\n|,/).map((item) => item.trim()).filter(Boolean);
  const roleLabel = roles.length ? `${roles[0]}${roles.length > 1 ? ` +${roles.length - 1}` : ""}` : "No target roles";
  const locationLabel = state.settings.locations.length ? state.settings.locations.join(", ") : "No locations";
  const sourceLabel = state.settings.allSources ? "All platforms" : `${state.settings.sources.length} platform${state.settings.sources.length === 1 ? "" : "s"}`;
  $("#settings-summary-text").textContent = `${roleLabel} · ${locationLabel} · ${sourceLabel}`;
}

function buildSearchPrompt() {
  const settings = readSettingsForm();
  const sources = settings.allSources
    ? "all suitable platforms, including LinkedIn, StepStone, Indeed, XING, Bundesagentur für Arbeit, Glassdoor and direct company career pages"
    : (settings.sources.join(", ") || "only the platforms I specify later");
  const roles = settings.targetRoles || "the target roles already agreed in this chat";
  const locations = settings.locations.join(", ") || "the preferred locations already agreed in this chat";
  const notes = `${settings.notes || "Use my saved preferences and show only live, relevant vacancies."}\nFor every result, also include employmentCategory with exactly "full-time" or "working-student".`;
  return `Find new, currently live job vacancies using the profile and search rules already saved in this ChatGPT conversation.\n\nTarget roles:\n${roles}\n\nPreferred locations: ${locations}\nPlatforms: ${sources}\nExtra instructions: ${notes}\n\nCheck that each vacancy link is real and opens the specific job. Prefer the employer's direct application page. Do not invent jobs, links, recruiters, requirements or scores. Avoid duplicates and jobs already shown in this conversation.\n\nFor every job, also apply the fit-scoring rules already saved in this chat. Return ONLY one valid JSON array. Use these exact fields for every item:\n[\n  {\n    "company": "",\n    "jobTitle": "",\n    "location": "",\n    "source": "",\n    "jobUrl": "",\n    "postedDate": "YYYY-MM-DD or empty",\n    "deadline": "YYYY-MM-DD or empty",\n    "fitScore": 0.0,\n    "decision": "",\n    "actualWork": "",\n    "strongestMatches": [""],\n    "technicalGaps": [""],\n    "seniorityGap": "",\n    "languageRequirement": "",\n    "degreeRequirement": "",\n    "mandatoryRequirements": [""],\n    "cvEffort": "",\n    "recruiterName": "only if stated",\n    "recruiterEmail": "only if stated",\n    "recruiterPhone": "only if stated",\n    "interviewQuestions": [""],\n    "notes": ""\n  }\n]\n\nUse an empty string or empty array when a field is unknown.`;
}

async function copySearchPrompt() {
  await saveSettings(false);
  const missing = [];
  if (!state.settings.targetRoles.trim()) missing.push("target job titles");
  if (!state.settings.locations.length) missing.push("preferred locations");
  if (missing.length) {
    $("#search-setup-details").open = true;
    showToast(`Add ${missing.join(" and ")} before copying the request.`);
    (missing[0] === "target job titles" ? $("#target-roles") : $("#location-input")).focus();
    return;
  }
  const prompt = buildSearchPrompt().replace(
    '    "fitScore": 0.0,',
    '    "employmentCategory": "full-time or working-student",\n    "fitScore": 0.0,'
  );
  await copyText(prompt);
  showToast("Search request copied. Paste it into your scheduled ChatGPT job-search chat.");
}

async function openSavedChat(kind) {
  await saveSettings(false);
  const field = kind === "analysis" ? "analysisChatUrl" : "chatUrl";
  const selector = kind === "analysis" ? "#analysis-chat-url" : "#chat-url";
  const url = chatUrl(state.settings[field]);
  if (!url) {
    $(selector).focus();
    showToast(`Paste a complete ChatGPT ${kind === "analysis" ? "analysis" : "job-search"} chat link first.`);
    return false;
  }
  await chrome.tabs.create({ url: url.href });
  return true;
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (char === '"') {
      if (quoted && text[index + 1] === '"') { cell += '"'; index += 1; }
      else quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell); cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[index + 1] === "\n") index += 1;
      row.push(cell);
      if (row.some((value) => value.trim())) rows.push(row);
      row = [];
      cell = "";
    } else cell += char;
  }
  row.push(cell);
  if (row.some((value) => value.trim())) rows.push(row);
  if (rows.length < 2) throw new Error("No job rows were found.");
  const headers = rows[0].map((value) => value.trim());
  return rows.slice(1).map((values) => Object.fromEntries(headers.map((header, index) => [header, values[index] || ""])));
}

function parseImported(text) {
  const clean = String(text || "").trim().replace(/^```(?:json|csv)?\s*/i, "").replace(/\s*```$/, "");
  if (!clean) throw new Error("Paste JSON or CSV job results first.");
  try {
    const parsed = JSON.parse(clean);
    if (Array.isArray(parsed)) return parsed;
    if (Array.isArray(parsed.jobs)) return parsed.jobs;
    if (Array.isArray(parsed.results)) return parsed.results;
  } catch { /* Try CSV next. */ }
  return parseCsv(clean);
}

function leadKey(lead) {
  return lead.jobUrl || `${lead.company}|${lead.jobTitle}|${lead.location}`.toLocaleLowerCase();
}

async function importJobs() {
  const status = $("#import-status");
  status.className = "";
  status.textContent = "Checking results…";
  try {
    const raw = parseImported($("#import-text").value);
    const existing = new Set(state.leads.map(leadKey));
    const leads = raw
      .map((item) => normalizeLead(item))
      .filter((lead) => lead.company && lead.jobTitle)
      .filter((lead) => {
        const key = leadKey(lead);
        if (existing.has(key)) return false;
        existing.add(key);
        return true;
      });
    if (!leads.length) throw new Error("No new valid jobs were found. Each row needs a company and job title.");
    await putJobLeads(leads);
    state.leads.push(...leads);
    $("#import-text").value = "";
    renderLeads();
    status.textContent = `Imported ${leads.length} new job${leads.length === 1 ? "" : "s"}. Duplicate results were skipped.`;
    showToast("Jobs added to the Job Finder sheet.");
  } catch (error) {
    status.textContent = error.message || "The results could not be imported.";
    status.className = "error";
  }
}

async function updateLeadScore(lead, input) {
  if (input.value !== "" && (Number(input.value) < 0 || Number(input.value) > 10)) {
    input.setCustomValidity("Enter a number from 0 to 10.");
    input.reportValidity();
    return;
  }
  input.setCustomValidity("");
  const next = normalizeLead({ manualScore: input.value }, lead);
  if (input.value === "") next.manualScore = null;
  await putJobLead(next);
  state.leads = state.leads.map((item) => item.id === next.id ? next : item);
  renderLeads();
  showToast("Your job score was saved.");
}

async function toggleToApply(lead) {
  const next = { ...lead, toApply: !lead.toApply, updatedAt: new Date().toISOString() };
  await putJobLead(next);
  state.leads = state.leads.map((item) => item.id === next.id ? next : item);
  renderLeads();
  showToast(next.toApply ? "Saved to your To Apply list." : "Removed from your To Apply list.");
}

async function markApplied(lead) {
  if (!confirm(`Mark ${lead.company} · ${lead.jobTitle} as applied and move it to your application tracker?`)) return;
  const applications = await listApplications();
  if (lead.sourceApplicationId) {
    const held = await getApplication(lead.sourceApplicationId);
    if (held) {
      const now = new Date().toISOString();
      const restored = {
        ...held,
        returnedToFinderAt: "",
        applicationDate: new Date().toISOString().slice(0, 10),
        status: "applied",
        statusHistory: [...(held.statusHistory || []), { status: "applied", changedAt: now }],
        updatedAt: now
      };
      await updateApplication(restored);
      await deleteJobLead(lead.id);
      location.href = `${chrome.runtime.getURL("dashboard.html")}?edit=${encodeURIComponent(restored.id)}`;
      return;
    }
  }
  const duplicate = findLikelyDuplicate(applications.filter((app) => !app.deletedAt && !app.archivedAt && !app.returnedToFinderAt), lead);
  if (duplicate) {
    location.href = `${chrome.runtime.getURL("dashboard.html")}?edit=${encodeURIComponent(duplicate.id)}`;
    return;
  }
  const application = leadToApplication(lead);
  await createApplication(application);
  await deleteJobLead(lead.id);
  location.href = `${chrome.runtime.getURL("dashboard.html")}?edit=${encodeURIComponent(application.id)}`;
}

async function removeLead(lead) {
  if (!confirm(`Delete ${lead.company} · ${lead.jobTitle} from Job Finder?`)) return;
  await deleteJobLead(lead.id);
  if (lead.sourceApplicationId) {
    const held = await getApplication(lead.sourceApplicationId);
    if (held) {
      const now = new Date().toISOString();
      await updateApplication({ ...held, returnedToFinderAt: "", deletedAt: now, updatedAt: now });
    }
  }
  state.leads = state.leads.filter((item) => item.id !== lead.id);
  renderLeads();
  showToast("Job lead deleted.");
}

async function analyzeLead(lead) {
  await saveSettings(false);
  const url = chatUrl(state.settings.analysisChatUrl);
  if (!url) {
    $("#analysis-chat-url").focus();
    showToast("Paste your separate ChatGPT job-analysis chat link first.");
    return;
  }
  await copyText(buildAnalysisRequest(lead));
  showToast("Analysis request copied. Paste it into your ChatGPT analysis chat, then return and use Paste result.");
  setTimeout(() => chrome.tabs.create({ url: url.href }), 650);
}

function openLeadAnalysisImport(lead) {
  $("#analysis-lead-id").value = lead.id;
  $("#lead-analysis-text").value = "";
  $("#lead-analysis-status").textContent = "";
  $("#lead-analysis-status").className = "";
  $("#lead-analysis-dialog").showModal();
  $("#lead-analysis-text").focus();
}

async function importLeadAnalysis() {
  const status = $("#lead-analysis-status");
  try {
    const lead = state.leads.find((item) => item.id === $("#analysis-lead-id").value);
    if (!lead) throw new Error("This job is no longer in the sheet.");
    const result = parseStructuredResult($("#lead-analysis-text").value);
    const updated = normalizeLead(result, lead);
    await putJobLead(updated);
    state.leads = state.leads.map((item) => item.id === updated.id ? updated : item);
    $("#lead-analysis-dialog").close();
    renderLeads();
    showToast("ChatGPT analysis imported into this job.");
  } catch (error) {
    status.textContent = error.message || "The analysis could not be imported.";
    status.className = "error";
  }
}

function detailRow(label, value) {
  if (!value) return null;
  const row = node("div", "lead-detail-row");
  row.append(node("strong", "", label), node("p", "", String(value)));
  return row;
}

function showLeadDetails(lead) {
  $("#details-job-title").textContent = `${lead.company || "Unknown company"} · ${lead.jobTitle || "Untitled job"}`;
  const content = $("#lead-details-content");
  content.replaceChildren();
  const score = applicationScore(lead);
  const rows = [
    detailRow("Category", employmentCategoryLabel(lead)),
    detailRow("Your score", score === null ? "Not scored" : `${score.toFixed(1)}/10`),
    detailRow("Decision", lead.decision),
    detailRow("What the work involves", lead.actualWork),
    detailRow("Strongest matches", lead.strongestMatches),
    detailRow("Technical gaps", lead.technicalGaps),
    detailRow("Seniority", lead.seniorityGap),
    detailRow("Language", lead.languageRequirement),
    detailRow("Degree", lead.degreeRequirement),
    detailRow("Mandatory requirements", lead.mandatoryRequirements),
    detailRow("CV effort", lead.cvEffort),
    detailRow("Recruiter", [lead.recruiterName, lead.recruiterEmail, lead.recruiterPhone].filter(Boolean).join(" · ")),
    detailRow("Interview questions", lead.interviewQuestions),
    detailRow("Notes", lead.notes)
  ].filter(Boolean);
  if (lead.jobUrl) {
    const open = node("button", "primary-button details-open-job", "Open original job posting");
    open.type = "button";
    open.addEventListener("click", () => chrome.tabs.create({ url: lead.jobUrl }));
    content.append(open);
  }
  if (rows.length) content.append(...rows);
  else content.append(node("p", "lead-details-empty", "No extra analysis has been imported for this job yet."));
  $("#lead-details-dialog").showModal();
}

function filteredLeads() {
  const query = $("#lead-search").value.trim().toLocaleLowerCase();
  const filter = $("#lead-filter").value;
  const categoryFilter = $("#lead-category-filter").value;
  return [...state.leads]
    .filter((lead) => {
      if (categoryFilter !== "all" && employmentCategory(lead) !== categoryFilter) return false;
      if (filter === "to-apply" && !lead.toApply) return false;
      if (filter === "analyzed" && !lead.analysisUpdatedAt) return false;
      if (filter === "not-analyzed" && lead.analysisUpdatedAt) return false;
      if (!query) return true;
      return [
        lead.company, lead.jobTitle, lead.location, lead.source, lead.notes,
        lead.decision, lead.actualWork, lead.strongestMatches, lead.technicalGaps
      ].join(" ").toLocaleLowerCase().includes(query);
    })
    .sort((left, right) => {
      const scoreDifference = (applicationScore(right) ?? -1) - (applicationScore(left) ?? -1);
      if (scoreDifference) return scoreDifference;
      return String(right.postedDate || right.createdAt).localeCompare(String(left.postedDate || left.createdAt));
    });
}

function renderLeads() {
  const leads = filteredLeads();
  const body = $("#lead-body");
  body.replaceChildren();
  leads.forEach((lead, index) => {
    const row = document.createElement("tr");
    if (lead.toApply) row.classList.add("to-apply-row");
    row.append(node("td", "lead-number", String(index + 1)));

    const jobCell = document.createElement("td");
    const job = node("div", "lead-job");
    job.append(node("strong", "", lead.company || "Unknown company"), node("span", "lead-title", lead.jobTitle || "Untitled job"));
    if (lead.jobUrl) job.append(node("small", "link-available", "✓ Original job link available"));
    else job.append(node("small", "link-missing", "No job link was included"));
    jobCell.append(job);

    const sourceCell = document.createElement("td");
    sourceCell.append(node("span", "source-pill", lead.source || "Imported"));
    const categoryCell = document.createElement("td");
    categoryCell.append(node("span", `type-pill ${employmentCategory(lead)}`, employmentCategoryLabel(lead)));
    const scoreCell = document.createElement("td");
    const scoreInput = node("input", "score-input");
    scoreInput.type = "number";
    scoreInput.min = "0";
    scoreInput.max = "10";
    scoreInput.step = "0.1";
    scoreInput.placeholder = "—";
    scoreInput.value = applicationScore(lead) ?? "";
    scoreInput.title = "Enter your own score from 0 to 10, including decimals such as 8.3";
    scoreInput.addEventListener("change", () => updateLeadScore(lead, scoreInput));
    scoreCell.append(scoreInput);

    const decisionCell = document.createElement("td");
    decisionCell.append(node("span", lead.decision ? "decision-pill" : "decision-empty", lead.decision || "Not analyzed"));

    const actionCell = document.createElement("td");
    const actions = node("div", "row-actions");
    const open = node("button", `row-button${lead.jobUrl ? "" : " disabled"}`, lead.jobUrl ? "Open job" : "No link");
    open.type = "button";
    open.disabled = !lead.jobUrl;
    if (lead.jobUrl) open.addEventListener("click", () => chrome.tabs.create({ url: lead.jobUrl }));
    const toApply = node("button", `row-button to-apply-button${lead.toApply ? " active" : ""}`, lead.toApply ? "✓ To Apply" : "Save to To Apply");
    toApply.type = "button";
    toApply.addEventListener("click", () => toggleToApply(lead));
    const analyze = node("button", "row-button analyze-button", "Analyze in ChatGPT");
    analyze.type = "button";
    analyze.addEventListener("click", () => analyzeLead(lead));
    const paste = node("button", "row-button", "Paste result");
    paste.type = "button";
    paste.addEventListener("click", () => openLeadAnalysisImport(lead));
    const details = node("button", "row-button", "Details");
    details.type = "button";
    details.addEventListener("click", () => showLeadDetails(lead));
    const applied = node("button", "row-button applied-button", "Mark applied");
    applied.type = "button";
    applied.addEventListener("click", () => markApplied(lead));
    const remove = node("button", "row-button danger", "Delete");
    remove.type = "button";
    remove.addEventListener("click", () => removeLead(lead));
    actions.append(open, toApply, analyze, paste, details, applied, remove);
    actionCell.append(actions);

    row.append(
      jobCell,
      categoryCell,
      sourceCell,
      node("td", "", lead.location || "—"),
      node("td", "", dateLabel(lead.postedDate)),
      scoreCell,
      decisionCell,
      actionCell
    );
    body.append(row);
  });
  $("#lead-empty").hidden = leads.length > 0;
  $("#lead-count").textContent = `${leads.length} job${leads.length === 1 ? "" : "s"}`;
}

async function initialize() {
  renderLocationOptions();
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  state.settings = { ...state.settings, ...(stored[SETTINGS_KEY] || {}) };
  state.settings.locations = Array.isArray(state.settings.locations) ? state.settings.locations : [];
  state.settings.sources = Array.isArray(state.settings.sources) ? state.settings.sources : [];
  state.leads = (await listJobLeads()).map((lead) => normalizeLead({}, lead));
  $("#chat-url").value = state.settings.chatUrl || "";
  $("#analysis-chat-url").value = state.settings.analysisChatUrl || "";
  $("#target-roles").value = state.settings.targetRoles || "";
  $("#search-notes").value = state.settings.notes || "";
  renderLocations();
  renderSources();
  renderSettingsSummary();
  renderLeads();
}

$("#add-location").addEventListener("click", addLocation);
$("#location-input").addEventListener("keydown", (event) => {
  if (event.key === "Enter") { event.preventDefault(); addLocation(); }
});
$("#all-sources").addEventListener("change", (event) => {
  state.settings.allSources = event.target.checked;
  renderSources();
});
$("#save-settings").addEventListener("click", () => saveSettings());
$("#copy-prompt").addEventListener("click", copySearchPrompt);
$("#open-chat").addEventListener("click", () => openSavedChat("search"));
$("#back-dashboard").addEventListener("click", () => { location.href = chrome.runtime.getURL("dashboard.html"); });
$("#open-insights").addEventListener("click", () => { location.href = chrome.runtime.getURL("insights.html"); });
$("#import-jobs").addEventListener("click", importJobs);
$("#lead-search").addEventListener("input", renderLeads);
$("#lead-filter").addEventListener("change", renderLeads);
$("#lead-category-filter").addEventListener("change", renderLeads);
$("#show-format").addEventListener("click", () => $("#format-dialog").showModal());
$("#close-format").addEventListener("click", () => $("#format-dialog").close());
$("#close-lead-analysis").addEventListener("click", () => $("#lead-analysis-dialog").close());
$("#save-lead-analysis").addEventListener("click", importLeadAnalysis);
$("#close-lead-details").addEventListener("click", () => $("#lead-details-dialog").close());
$("#open-guide").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("guide.html") }));

const header = document.querySelector(".app-header");
function updateCompactHeader() {
  header.classList.toggle("compact", window.scrollY > 70);
}
window.addEventListener("scroll", updateCompactHeader, { passive: true });
updateCompactHeader();

for (const selector of ["#format-dialog", "#lead-analysis-dialog", "#lead-details-dialog"]) {
  $(selector).addEventListener("cancel", (event) => { event.preventDefault(); $(selector).close(); });
}

initialize().catch((error) => {
  console.error(error);
  showToast("The Job Finder sheet could not be loaded.");
});
