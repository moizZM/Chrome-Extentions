import { applicationScore, createId, employmentCategory, normalizeManualScore, normalizeUrl, todayLocal } from "./common.js";

export const ANALYSIS_FIELDS = [
  "fitScore", "decision", "actualWork", "strongestMatches", "technicalGaps",
  "seniorityGap", "languageRequirement", "degreeRequirement",
  "mandatoryRequirements", "cvEffort", "interviewQuestions"
];

export function valueFrom(item, names) {
  if (!item || typeof item !== "object") return "";
  for (const name of names) {
    if (item[name] !== undefined && item[name] !== null) return item[name];
    const compactName = name.toLocaleLowerCase().replace(/[^a-z0-9]/g, "");
    const key = Object.keys(item).find((candidate) => (
      candidate.toLocaleLowerCase().replace(/[^a-z0-9]/g, "") === compactName
    ));
    if (key) return item[key];
  }
  return "";
}

export function textValue(value) {
  if (Array.isArray(value)) return value.map((item) => String(item || "").trim()).filter(Boolean).join("\n");
  if (value && typeof value === "object") return JSON.stringify(value);
  return String(value || "").trim();
}

export function linkValue(value) {
  const text = textValue(value);
  if (!text) return "";
  const markdown = text.match(/\[[^\]]*\]\((https?:\/\/[^)\s]+)\)/i);
  const plain = text.match(/https?:\/\/[^\s<>"]+/i);
  const candidate = (markdown?.[1] || plain?.[0] || text).replace(/[),.;\]]+$/, "");
  return normalizeUrl(candidate);
}

export function parseStructuredResult(text) {
  const cleaned = String(text || "")
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "");
  if (!cleaned) throw new Error("Paste the JSON result from ChatGPT first.");
  let result;
  try {
    result = JSON.parse(cleaned);
  } catch {
    const first = cleaned.indexOf("{");
    const last = cleaned.lastIndexOf("}");
    if (first < 0 || last <= first) throw new Error("The ChatGPT result is not valid JSON.");
    try { result = JSON.parse(cleaned.slice(first, last + 1)); }
    catch { throw new Error("The ChatGPT result is not valid JSON."); }
  }
  if (Array.isArray(result)) result = result[0];
  if (result?.analysis && typeof result.analysis === "object") result = { ...result, ...result.analysis };
  if (!result || typeof result !== "object") throw new Error("The ChatGPT result is incomplete.");
  return result;
}

export function normalizeLead(item, existing = {}) {
  const now = new Date().toISOString();
  const directScore = valueFrom(item, ["fitScore", "fit score", "manualScore", "score", "rating"]);
  const toApplyValue = valueFrom(item, ["toApply", "to apply"]);
  const explicitlyToApply = toApplyValue === true
    || ["true", "yes", "1", "to apply"].includes(String(toApplyValue).trim().toLocaleLowerCase());
  const normalized = {
    ...existing,
    id: existing.id || textValue(valueFrom(item, ["id"])) || createId("lead"),
    company: textValue(valueFrom(item, ["company", "employer", "organization"])) || existing.company || "",
    jobTitle: textValue(valueFrom(item, ["jobTitle", "job title", "title", "position"])) || existing.jobTitle || "",
    location: textValue(valueFrom(item, ["location", "city"])) || existing.location || "",
    source: textValue(valueFrom(item, ["source", "platform", "job board"])) || existing.source || "Imported",
    jobUrl: linkValue(valueFrom(item, ["jobUrl", "job link", "directApplicationLink", "direct application link", "applicationLink", "application link", "url", "link"])) || existing.jobUrl || "",
    postedDate: textValue(valueFrom(item, ["postedDate", "posted date", "datePosted", "postingDate"])) || existing.postedDate || "",
    deadline: textValue(valueFrom(item, ["deadline", "applicationDeadline", "application deadline"])) || existing.deadline || "",
    notes: textValue(valueFrom(item, ["notes", "jobNotes"])) || existing.notes || "",
    jobDescription: textValue(valueFrom(item, ["jobDescription", "job description", "description", "fullDescription"])) || existing.jobDescription || "",
    employmentCategory: textValue(valueFrom(item, ["employmentCategory", "employment category", "employmentType", "employment type", "jobType", "job type", "contractType", "contract type"])) || existing.employmentCategory || "",
    recruiterName: textValue(valueFrom(item, ["recruiterName", "recruiter name", "contactName", "contact person"])) || existing.recruiterName || "",
    recruiterEmail: textValue(valueFrom(item, ["recruiterEmail", "recruiter email", "contactEmail", "contact email"])) || existing.recruiterEmail || "",
    recruiterPhone: textValue(valueFrom(item, ["recruiterPhone", "recruiter phone", "contactPhone", "contact phone"])) || existing.recruiterPhone || "",
    recruiterLinkedIn: linkValue(valueFrom(item, ["recruiterLinkedIn", "recruiter linkedin", "contactLink", "contact link"])) || existing.recruiterLinkedIn || "",
    sourceApplicationId: textValue(valueFrom(item, ["sourceApplicationId", "source application id"])) || existing.sourceApplicationId || "",
    manualScore: directScore === "" ? (applicationScore(existing) ?? null) : normalizeManualScore(directScore),
    decision: textValue(valueFrom(item, ["decision", "priority", "recommendation"])) || existing.decision || "",
    actualWork: textValue(valueFrom(item, ["actualWork", "actual work", "whatTheJobIsAbout", "job summary", "summary"])) || existing.actualWork || "",
    strongestMatches: textValue(valueFrom(item, ["strongestMatches", "strongest matches", "matches", "strengths"])) || existing.strongestMatches || "",
    technicalGaps: textValue(valueFrom(item, ["technicalGaps", "technical gaps", "gaps", "missing skills"])) || existing.technicalGaps || "",
    seniorityGap: textValue(valueFrom(item, ["seniorityGap", "seniority gap", "experienceGap", "experience gap"])) || existing.seniorityGap || "",
    languageRequirement: textValue(valueFrom(item, ["languageRequirement", "language requirement", "germanRequirement", "German requirement"])) || existing.languageRequirement || "",
    degreeRequirement: textValue(valueFrom(item, ["degreeRequirement", "degree requirement"])) || existing.degreeRequirement || "",
    mandatoryRequirements: textValue(valueFrom(item, ["mandatoryRequirements", "mandatory requirements", "mustHaves", "must haves"])) || existing.mandatoryRequirements || "",
    cvEffort: textValue(valueFrom(item, ["cvEffort", "cv effort", "applicationEffort", "application effort"])) || existing.cvEffort || "",
    interviewQuestions: textValue(valueFrom(item, ["interviewQuestions", "interview questions", "questionsToPrepare", "questions to prepare"])) || existing.interviewQuestions || "",
    toApply: Boolean(explicitlyToApply || existing.toApply),
    analysisUpdatedAt: ANALYSIS_FIELDS.some((field) => valueFrom(item, [field]) !== "") ? now : (existing.analysisUpdatedAt || ""),
    createdAt: existing.createdAt || now,
    updatedAt: now
  };
  normalized.employmentCategory = employmentCategory(normalized);
  return normalized;
}

export function leadToApplication(lead) {
  const now = new Date().toISOString();
  return {
    id: createId("app"),
    company: lead.company || "",
    jobTitle: lead.jobTitle || "",
    location: lead.location || "",
    jobUrl: lead.jobUrl || "",
    applicationDate: todayLocal(),
    applicationDeadline: lead.deadline || "",
    status: "applied",
    manualScore: applicationScore(lead),
    notes: [lead.notes, lead.source ? `Found on ${lead.source}` : ""].filter(Boolean).join("\n"),
    jobDescription: lead.jobDescription || "",
    employmentCategory: employmentCategory(lead),
    referenceNumber: "",
    recruiterName: lead.recruiterName || "",
    recruiterEmail: lead.recruiterEmail || "",
    recruiterPhone: lead.recruiterPhone || "",
    recruiterLinkedIn: lead.recruiterLinkedIn || "",
    interviewQuestions: lead.interviewQuestions || "",
    decision: lead.decision || "",
    actualWork: lead.actualWork || "",
    strongestMatches: lead.strongestMatches || "",
    technicalGaps: lead.technicalGaps || "",
    seniorityGap: lead.seniorityGap || "",
    languageRequirement: lead.languageRequirement || "",
    degreeRequirement: lead.degreeRequirement || "",
    mandatoryRequirements: lead.mandatoryRequirements || "",
    cvEffort: lead.cvEffort || "",
    analysisUpdatedAt: lead.analysisUpdatedAt || "",
    statusHistory: [{ status: "applied", changedAt: now }],
    createdAt: now,
    updatedAt: now
  };
}

export function applicationToLead(application) {
  const now = new Date().toISOString();
  return normalizeLead({}, {
    id: createId("lead"),
    sourceApplicationId: application.id,
    company: application.company || "",
    jobTitle: application.jobTitle || "",
    location: application.location || "",
    source: "Returned from applications",
    jobUrl: application.jobUrl || "",
    postedDate: "",
    deadline: application.applicationDeadline || "",
    notes: application.notes || "",
    jobDescription: application.jobDescription || "",
    employmentCategory: employmentCategory(application),
    recruiterName: application.recruiterName || "",
    recruiterEmail: application.recruiterEmail || "",
    recruiterPhone: application.recruiterPhone || "",
    recruiterLinkedIn: application.recruiterLinkedIn || "",
    manualScore: applicationScore(application),
    decision: application.decision || "",
    actualWork: application.actualWork || "",
    strongestMatches: application.strongestMatches || "",
    technicalGaps: application.technicalGaps || "",
    seniorityGap: application.seniorityGap || "",
    languageRequirement: application.languageRequirement || "",
    degreeRequirement: application.degreeRequirement || "",
    mandatoryRequirements: application.mandatoryRequirements || "",
    cvEffort: application.cvEffort || "",
    interviewQuestions: application.interviewQuestions || "",
    toApply: true,
    analysisUpdatedAt: application.analysisUpdatedAt || "",
    createdAt: now,
    updatedAt: now
  });
}

export function buildAnalysisRequest(job) {
  return `Analyze this job using the full profile and scoring rules already saved in this ChatGPT conversation. Be realistic and never invent experience.\n\nJOB\nCompany: ${job.company || "Unknown"}\nTitle: ${job.jobTitle || "Unknown"}\nLocation: ${job.location || "Unknown"}\nSource: ${job.source || "Unknown"}\nLink: ${job.jobUrl || "Not available"}\n\nJOB DESCRIPTION\n${job.jobDescription || job.notes || "Open the job link and use the live posting."}\n\nReturn ONLY one valid JSON object with these exact fields:\n{\n  "company": "",\n  "jobTitle": "",\n  "location": "",\n  "jobUrl": "",\n  "fitScore": 0.0,\n  "decision": "🔥 High Priority Apply | ✅ Apply | 🟡 Stretch / Apply if quick | ⚠️ Low Priority | ❌ Skip",\n  "actualWork": "simple explanation of the real work flow",\n  "strongestMatches": [""],\n  "technicalGaps": [""],\n  "seniorityGap": "",\n  "languageRequirement": "mandatory, preferred, or not mentioned, with the stated level",\n  "degreeRequirement": "",\n  "mandatoryRequirements": [""],\n  "cvEffort": "serious tailoring or quick application",\n  "recruiterName": "only if stated",\n  "recruiterEmail": "only if stated",\n  "recruiterPhone": "only if stated",\n  "interviewQuestions": ["five useful questions to prepare"]\n}`;
}
