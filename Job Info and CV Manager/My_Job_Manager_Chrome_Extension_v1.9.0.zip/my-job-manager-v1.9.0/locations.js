export const LOCATION_SUGGESTIONS = [
  "Remote", "Germany", "Baden-Württemberg", "Bavaria", "Berlin", "Brandenburg",
  "Bremen", "Hamburg", "Hesse", "Lower Saxony", "Mecklenburg-Vorpommern",
  "North Rhine-Westphalia", "Rhineland-Palatinate", "Saarland", "Saxony",
  "Saxony-Anhalt", "Schleswig-Holstein", "Thuringia", "Aachen", "Augsburg",
  "Berlin", "Bielefeld", "Bochum", "Bonn", "Braunschweig", "Bremen",
  "Chemnitz", "Cologne", "Darmstadt", "Dortmund", "Dresden", "Duisburg",
  "Düsseldorf", "Erlangen", "Essen", "Frankfurt am Main", "Freiburg im Breisgau",
  "Gelsenkirchen", "Göttingen", "Hamburg", "Hannover", "Heidelberg", "Heilbronn",
  "Ingolstadt", "Jena", "Karlsruhe", "Kassel", "Kiel", "Koblenz", "Leipzig",
  "Leverkusen", "Lübeck", "Magdeburg", "Mainz", "Mannheim", "Munich", "Münster",
  "Nuremberg", "Oldenburg", "Osnabrück", "Paderborn", "Potsdam", "Regensburg",
  "Rostock", "Saarbrücken", "Stuttgart", "Ulm", "Wiesbaden", "Wolfsburg",
  "Wuppertal", "Würzburg", "Austria", "Vienna", "Switzerland", "Zurich",
  "European Union", "Europe", "Worldwide remote"
];
